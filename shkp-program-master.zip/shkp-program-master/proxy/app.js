const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

// Create Express Server
const app = express();

// Configuration
const PORT = 6007;
const HOST = 'localhost';
const PROD_SERVICE_URL = 'https://www.smartone.com/';
const WS_7A_SERVICE_URL = 'http://webstage7a.smartone.com/';
// Proxy endpoints
app.use(
	'/.resources/common/webresources/css/fonts/*.*',
	createProxyMiddleware({
		target: PROD_SERVICE_URL,
		secure: false,
		changeOrigin: true,
		onProxyRes: function (proxyRes, req, res) {
			proxyRes.headers['Access-Control-Allow-Origin'] = '*';
		},
	}),
);

app.use(
	'/IMG_V4/web_style_guideline/*.*',
	createProxyMiddleware({
		target: WS_7A_SERVICE_URL,
		secure: false,
		changeOrigin: true,
		onProxyRes: function (proxyRes, req, res) {
			proxyRes.headers['Access-Control-Allow-Origin'] = '*';
		},
	}),
);

// Start Proxy
app.listen(PORT, HOST, () => {
	console.log(`Starting Proxy at ${HOST}:${PORT}`);
});

/**
 * 
			'/.resources/common/webresources/css/fonts/': {
				target: 'https://www.smartone.com/',
				secure: false,
				changeOrigin: true,
			},
 */
