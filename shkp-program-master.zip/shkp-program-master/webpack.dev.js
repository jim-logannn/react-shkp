const { merge } = require('webpack-merge');
const common = require('./webpack.common.js');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const apiMocker = require('mocker-api');

module.exports = function (env, arg) {
	return merge(common(env, arg), {
		mode: 'development',
		devtool: 'inline-source-map',
		devServer: {
			hot: true,
			setupMiddlewares: (middlewares, devServer) => {
				apiMocker(devServer.app, path.resolve(__dirname, './mock/index.js'), {
					changeHost: true,
				});
				return middlewares;
			},
			static: {
				directory: path.join(__dirname, 'build'),
			},
			compress: true,
			historyApiFallback: true,
			port: process.env.PORT,
			proxy: {
				'/.resources/common/webresources/css/fonts/': {
					target: 'https://www.smartone.com/',
					secure: false,
					changeOrigin: true,
				},
				'/.resources/common/webresources/assets/images/common/': {
					target: 'https://www.smartone.com/',
					secure: false,
					changeOrigin: true,
				},
				'/SHKP/Silicon_Hill/images/': {
					target: 'https://webstage7a.smartone.com/',
					secure: false,
					changeOrigin: true,
				},
				'/IMG_V4/Best_Router_Placement_Tips/top_banner/': {
					target: 'https://webstage7a.smartone.com/',
					secure: false,
					changeOrigin: true,
				},
			},
		},
		plugins: [
			new HtmlWebpackPlugin({
				filename: 'index.html',
				template: path.resolve(__dirname, './template/index.html'),
				chunks: ['main'],
			}),
		],
	});
};
