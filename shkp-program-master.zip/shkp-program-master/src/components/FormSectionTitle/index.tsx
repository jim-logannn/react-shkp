// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';

// intl
import styled from 'styled-components';
import { Palette } from '@mui/material';

const StyledSectionTitle = styled.div(({ theme }) => ({
	display: 'flex',
	justifyContent: 'flex-start',
	alignItems: 'center',
	width: '100%',
	gap: theme.spacing(1),
	marginBottom: theme.spacing(2),

	'&:after': {
		content: '""',
		display: 'block',
		marginLeft: theme.spacing(3),
		backgroundColor: theme.palette.grey[50],
		height: '2px',
		flex: '1 1 auto',
	},
}));

export const StyledSectionTitleIcon = styled.div<{ color?: Palette }>(({ theme, color }) => ({
	width: 30,
	height: 30,
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center',
	color: theme.palette.white.main,
	borderRadius: '100%',
	...theme.typography.p2,
	backgroundColor: `${color ? color : theme.palette.primary.main}`,
}));

const StyledSectionTitleText = styled.div(({ theme }) => ({
	...theme.typography.h4,
}));

interface SectionTitleProp {
	sectionIcon?: React.ReactNode;
	title: string;
}

function SectionTitle({ sectionIcon, title }: SectionTitleProp) {
	return (
		<StyledSectionTitle>
			{sectionIcon ? sectionIcon : ''}
			<StyledSectionTitleText>{title}</StyledSectionTitleText>
		</StyledSectionTitle>
	);
}

export default SectionTitle;
