// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';

// intl
import styled from 'styled-components';

const StyledImg = styled.img`
	display: block;
	margin: 0 auto;
	box-sizing: border-box;
`;
function Img(props: any) {
	return <StyledImg {...props} />;
}

export default Img;
