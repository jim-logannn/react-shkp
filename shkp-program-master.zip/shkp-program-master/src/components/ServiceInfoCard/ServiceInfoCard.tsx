// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';
import Img from '../img/Img';
import { styled } from '@mui/material';

const StyledServiceInfoCard = styled('div', {
	shouldForwardProp: (props) => {
		return props !== 'isDisable';
	},
})<ServiceInfoCardProp>(({ theme, isDisable = false, ...props }) => ({
	padding: theme.spacing(3),
	background: theme.palette.white.main,
	boxShadow: '0px 0px 20px 0px rgba(0,0,0,0.26)',
	display: 'flex',
	justifyContent: 'flex-start',
	alignItems: 'flex-start',
	flexDirection: 'column',
	borderRadius: '20px',
	height: '100%',
	position: 'relative',
	overflow: 'hidden',
	width: '100%',

	'&:after': isDisable
		? {
				content: "''",
				width: '100%',
				height: '100%',
				position: 'absolute',
				top: 0,
				left: 0,
				zIndex: 1,
				background: theme.palette.grey[50],
				opacity: 0.5,
		  }
		: {},
}));

const StyledServiceInfoCardIcon = styled('div')(({ theme, ...props }) => ({
	width: '100%',
	marginBottom: theme.spacing(2),
}));

const StyledServiceInfoCardContent = styled('div')(({ theme, ...props }) => ({
	width: '100%',
	display: 'flex',
	flexDirection: 'column',
	justifyContent: 'flex-start',
	alignItems: 'flex-start',
}));

// intl
interface ServiceInfoCardProp {
	icon?: React.ReactNode;
	children?: React.ReactNode;
	isDisable?: boolean;
}

function ServiceInfoCard({ icon, isDisable, children }: ServiceInfoCardProp) {
	return (
		<StyledServiceInfoCard isDisable={isDisable}>
			<StyledServiceInfoCardIcon>{icon}</StyledServiceInfoCardIcon>
			<StyledServiceInfoCardContent>{children}</StyledServiceInfoCardContent>
		</StyledServiceInfoCard>
	);
}

export default ServiceInfoCard;
