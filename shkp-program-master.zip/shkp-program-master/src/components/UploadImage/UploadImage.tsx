// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useContext, useRef, useState } from 'react';

// intl
import styled from 'styled-components';
import Img from '@/components/img/Img';
import { useIntl } from 'react-intl';
import Button from '@smt/formElement/Button';
import UploadRoundedIcon from '@mui/icons-material/UploadRounded';
import { Typography, useTheme } from '@mui/material';
import { useEffect } from 'react';

const StyledUploadInputField = styled.input(({ theme }) => ({
	display: 'none',
}));

const StyledImageWrapper = styled.div(({ theme }) => ({
	width: '100%',
	background: theme.palette.grey[20],
	borderRadius: '1.5rem',
	border: '2px solid transparent',
	borderColor: theme.palette.grey[20],
	display: 'flex',
	flexDirection: 'column',
	justifyContent: 'center',
	alignItems: 'center',
	padding: theme.spacing(3),
	marginBottom: theme.spacing(2),
}));

const StyledUploadImg = styled(Img)(({ theme }) => ({
	maxWidth: '250px',
	width: '100%',
	marginBottom: theme.spacing(1),
}));

const StyledReupload = styled.a(({ theme }) => ({
	textDecoration: 'underline',
	color: theme.palette.black.main,
	...theme.typography.p5,
}));

const StyledErrorMsg = styled.div(({ theme }) => ({
	marginTop: theme.spacing(1),
	color: theme.palette.primary.main,
	...theme.typography.p5,
}));

export interface UploadImageSetting {
	maxFileSize?: number;
	allowedExtension?: string[];
}

interface UploadImageProp {
	value: string;
	onUploadSuccess?: (imageUrl: string) => void;
	onUploadFail?: (errMsg: string) => void;
	setting?: UploadImageSetting;
}

function UploadImage({ value, onUploadSuccess, onUploadFail, setting }: UploadImageProp) {
	const intl = useIntl();
	const inputFileRef = useRef<HTMLInputElement>(null);
	const maxfileSize = (setting?.maxFileSize ? setting.maxFileSize : 5) * 1000000; //MB
	const allowedExtension = setting?.allowedExtension ? setting.allowedExtension : ['image/jpeg', 'image/jpg', 'image/png'];
	const reader = new FileReader();
	const [uploadedImage, setUploadedImage] = useState<string>(value);
	const [uploadErrorMsg, setUploadErrorMsg] = useState<string>('');

	const onClickUpload = () => {
		inputFileRef?.current?.click();
	};

	const setErrorMsg = (errMsg: string) => {
		setUploadedImage('');
		setUploadErrorMsg(errMsg);
		if (onUploadFail) {
			onUploadFail(errMsg);
		}
	};

	const onFileSelected = () => {
		//validate file
		if (!inputFileRef?.current?.files) {
			//no files
			setErrorMsg('No File');
			return;
		}
		const files = inputFileRef?.current?.files;
		if (files.length > 1) {
			//not support multi
			setErrorMsg('Only one file allowed');
			return;
		}
		for (let i = 0; files.length > i; i++) {
			if (allowedExtension.indexOf(files[i].type) == -1) {
				//not support format
				setErrorMsg('This format is not support');
				return;
			}
			if (files[i].size > maxfileSize) {
				//too big
				setErrorMsg('File size is bigger than ' + maxfileSize / 1000000 + 'MB');
				return;
			}

			reader.readAsDataURL(files[i]);
		}
	};

	reader.onloadend = () => {
		if (reader.result) {
			const imgBase64 = reader.result.toString();
			setUploadErrorMsg('');
			setUploadedImage(imgBase64);

			if (onUploadSuccess) {
				onUploadSuccess(imgBase64);
			}
		}
	};

	reader.onerror = () => {
		//file got something wrong
		setErrorMsg('Upload fail, please try again');
	};

	useEffect(() => {
		setUploadedImage(value ? value : '');
	}, [value]);

	return (
		<>
			<StyledUploadInputField type="file" accept="image/jpeg,image/jpg,image/png" ref={inputFileRef} onChange={onFileSelected} />
			{uploadedImage == '' && (
				<Button size="medium" startIcon={<UploadRoundedIcon />} fixedWidth={200} onClick={onClickUpload}>
					上傳
				</Button>
			)}
			{uploadErrorMsg !== '' && <StyledErrorMsg>{uploadErrorMsg}</StyledErrorMsg>}

			{uploadedImage !== '' && (
				<StyledImageWrapper>
					<StyledUploadImg src={uploadedImage} />
					<StyledReupload href="javascript:void()" onClick={onClickUpload}>
						重新上傳
					</StyledReupload>
				</StyledImageWrapper>
			)}
		</>
	);
}

export default UploadImage;
