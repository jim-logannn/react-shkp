// These must be the first lines
import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";

import React, {  } from "react";

// intl
import { useIntl } from "react-intl";

import { useEffect } from 'react';
import { styled } from 'styled-components';
import { Theme } from "@mui/material";
import { useTheme } from 'styled-components';

interface plancardProps{
    children: React.ReactNode;
}
const StyledPlanCardContainer = styled.div(({ theme }) => ({
	borderRadius: theme.spacing(3),
    background: theme.palette.white.main,    
    boxShadow: '0px 0px 20px 0px rgba(0, 0, 0, 0.15)',
    width: '100%',
    height: '100%',
    position: 'relative'
}));
const StyledChildContainer = styled.div(({ theme }) => ({
    padding: theme.spacing(3)
}));


function Plancard({children} : plancardProps) {

    return ( 
        <StyledPlanCardContainer>
            <StyledChildContainer>
                {children}
            </StyledChildContainer>
        </StyledPlanCardContainer>
    )
}

export default Plancard;