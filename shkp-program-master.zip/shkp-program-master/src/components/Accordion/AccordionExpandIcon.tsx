import React, { useState } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DoDisturbOnIcon from '@mui/icons-material/DoDisturbOn';
import styled, { useTheme } from 'styled-components';
import { createTheme, responsiveFontSizes  } from '@mui/material/styles';
import { ResponsiveFontSizesOptions } from '@mui/material/styles/responsiveFontSizes';
import { md } from 'node-forge';

interface AccordionExpandIconProps {
  index?: number;
  title?: string;  
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const StyledAccordion = styled(Accordion)(({ theme, expanded }) => ({
	borderBottom: `1px solid ${theme.palette.grey[60]}`,
  padding: `${theme.spacing(6)} 0`,
  '& .MuiAccordionSummary-expandIconWrapper':{
    marginLeft: theme.spacing(1),
  },
  '& .MuiAccordionSummary-root': {
    minHeight: 'inherit',
    padding: 0,
    color: expanded?theme.palette.black.main:theme.palette.grey[80],
    alignItems: 'flex-start'
  },
  '& .MuiAccordionSummary-content':{
    margin: 0,
  },
  '& .MuiAccordionSummary-content.Mui-expanded ':{
    margin: 0,
    minHeight: 'inherit'
  },
  '& .MuiAccordionSummary-root.Mui-expanded ':{
    minHeight: 'inherit'
  },
  '& .MuiAccordionDetails-root':{
    padding: `${theme.spacing(2)} 0 0`,
  },
  [theme.breakpoints.down('md')]: {
    padding: `${theme.spacing(2)} 0`,
  },
}));

const StyledTitle = styled.div(({ theme }) => ({
	...theme.typography.h6,
	[theme.breakpoints.down('md')]: {
		...theme.typography.h8,
	},
}));
const StyledContent = styled.div(({ theme }) => ({
	...theme.typography.p3,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
export default function AccordionExpandIcon({ index=0 , title = "", children, defaultOpen = true }: AccordionExpandIconProps) {
  const theme = useTheme();
  
  const [expanded, setExpanded] = React.useState<string | false>(false);

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };
  return (
    <div>
      <StyledAccordion expanded={expanded === '`panel${index}-content`'} onChange={handleChange('`panel${index}-content`')} defaultExpanded={defaultOpen} square={true} elevation={0}>
        <AccordionSummary
          expandIcon={expanded?<DoDisturbOnIcon sx={{ color: theme.palette.primary.main, width: '3rem', height: '3rem'  }} />:<AddCircleIcon sx={{ color: theme.palette.primary.main, width: '3rem', height: '3rem'  }} />}
          aria-controls={`panel${index}-content`}
          id={`panel${index}-header`}
        >
          <StyledTitle>{title}</StyledTitle>
        </AccordionSummary>
        <AccordionDetails>
          <StyledContent>{children}</StyledContent>
        </AccordionDetails>
      </StyledAccordion>
    </div>
  );
}
