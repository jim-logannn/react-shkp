import React, { useState } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import DoDisturbOnIcon from '@mui/icons-material/DoDisturbOn';
import styled, { useTheme } from 'styled-components';

interface SimpleAccordionExpandProps {
  index?: number;
  title?: string;  
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const StyledAccordion = styled(Accordion)(({ theme, expanded }) => ({
  padding: `${theme.spacing(2)} 0`,
  '& .MuiAccordionSummary-root': {
    minHeight: 'inherit',
    padding: 0,
  },
  '& .MuiAccordionSummary-content':{
    margin: 0,
  },
  '& .MuiAccordionSummary-content.Mui-expanded ':{
    margin: 0,
    minHeight: 'inherit'
  },
  '& .MuiAccordionSummary-root.Mui-expanded ':{
    minHeight: 'inherit'
  },
  '& .MuiAccordionDetails-root':{
    padding: `${theme.spacing(2)} 0 0`,
  }
}));

const StyledTitle = styled.div(({ theme }) => ({
  display:'flex',
  alignItems:'center',
	...theme.typography.p4,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
const StyledContent = styled.div(({ theme }) => ({
	...theme.typography.p5,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p6,
	},
}));

export default function SimpleAccordionExpand({ index=0 , title = "", children, defaultOpen = true }: SimpleAccordionExpandProps) {
  const theme = useTheme();
  const [expanded, setExpanded] = React.useState<string | false>(false);

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };
  return (
    <div>
      <StyledAccordion expanded={expanded === '`panel${index}-content`'} onChange={handleChange('`panel${index}-content`')} defaultExpanded={defaultOpen} square={true} elevation={0}>
        <AccordionSummary
          aria-controls={`panel${index}-content`}
          id={`panel${index}-header`}
        >
          <StyledTitle>
            {title}
            {expanded?
            <DoDisturbOnIcon sx={{ color: theme.palette.primary.main}} />
            :<AddCircleIcon sx={{ color: theme.palette.primary.main}} />
            }
          </StyledTitle>
        </AccordionSummary>
        <AccordionDetails>
          <StyledContent>
            {children}
          </StyledContent>
        </AccordionDetails>
      </StyledAccordion>
    </div>
  );
}
