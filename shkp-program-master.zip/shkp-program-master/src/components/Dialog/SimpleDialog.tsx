import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Typography from '@mui/material/Typography';

const StyledDialog = styled(Dialog)(({ theme }) => ({
 
  '& .MuiDialog-paper': {
    borderRadius: '30px',
  },
  '& .MuiDialogContent-root': {
    padding: `${theme.spacing(2)} ${theme.spacing(5)}`,
    [theme.breakpoints.down('md')]: {
      padding: theme.spacing(2),
    },
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));
const StyledDialogContent = styled(DialogContent)(({ theme }) => ({
  
}));

interface SimpleDialogProps {
    isOpen: boolean;
    onClose: ()=>void;
    children: React.ReactNode;
  }

export default function SimpleDialog({children, onClose, isOpen=false}:SimpleDialogProps) {
  return (
    <React.Fragment>
      <StyledDialog
        onClose={onClose}
        aria-labelledby="customized-dialog-title"
        open={isOpen}
      >
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title" />
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[60],
          }}
        >
          <CloseIcon />
        </IconButton>
        <StyledDialogContent >
         {children}
        </StyledDialogContent>        
      </StyledDialog>
    </React.Fragment>
  );
}