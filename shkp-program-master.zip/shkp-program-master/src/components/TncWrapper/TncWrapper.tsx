// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { AnchorHTMLAttributes, LinkHTMLAttributes } from 'react';

// intl
import styled from 'styled-components';
import { useIntl } from 'react-intl';

const StyledTncWrapper = styled.div(({ theme }) => ({
	...theme.typography.p5,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p6,
	},

	h1: {
		...theme.typography.h1,
		margin: 0,
		marginTop: theme.spacing(3),
		marginBottom: theme.spacing(3),
	},
	h2: {
		...theme.typography.h2,
		margin: 0,
		marginTop: theme.spacing(3),
		marginBottom: theme.spacing(3),
	},
	h3: {
		...theme.typography.h3,
		margin: 0,
		marginTop: theme.spacing(3),
		marginBottom: theme.spacing(3),
	},
	h4: {
		...theme.typography.h4,
		margin: 0,
		marginTop: theme.spacing(3),
		marginBottom: theme.spacing(3),
	},
	h5: {
		...theme.typography.h5,
		margin: 0,
		marginTop: theme.spacing(3),
		marginBottom: theme.spacing(3),
	},
	h6: {
		...theme.typography.h6,
		margin: 0,
		marginTop: theme.spacing(3),
		marginBottom: theme.spacing(3),
	},
	'p,td': {
		...theme.typography.p5,
		margin: 0,
		marginBottom: theme.spacing(2),
		[theme.breakpoints.down('md')]: {
			...theme.typography.p6,
		},
	},
	li: {
		...theme.typography.p5,
		margin: 0,
		marginBottom: theme.spacing(1),
		wordBreak: 'break-all',
		[theme.breakpoints.down('md')]: {
			...theme.typography.p6,
		},
	},
	'p,li': {
		'&:last-child': {
			marginBottom: 0,
		},
	},
	'ul,ol': {
		margin: 0,
		marginTop: theme.spacing(2),
		marginBottom: theme.spacing(2),
		paddingLeft: theme.spacing(2),

		'&:last-child': {
			marginBottom: 0,
		},
	},
	table: {
		marginBottom: theme.spacing(2),
		border: '1px solid' + theme.palette.grey[50],

		'&:last-child': {
			marginBottom: 0,
		},
	},
	'th,td': {
		padding: theme.spacing(1),
		borderBottom: '1px solid' + theme.palette.grey[50],
		borderRight: '1px solid' + theme.palette.grey[50],

		'&:last-child': {
			borderRight: 'none',
		},
	},
	tr: {
		'&:last-child': {
			td: { borderBottom: 0 },
		},
	},
	a: {
		color: theme.palette.primary.main,
	},
}));

interface TncWrapperProps {
	children?: React.ReactNode;
}

function TncWrapper({ children }: TncWrapperProps) {
	const intl = useIntl();

	return <StyledTncWrapper>{children}</StyledTncWrapper>;
}

export default TncWrapper;
