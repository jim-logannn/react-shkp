import { useCallback, useEffect, useRef, useState } from "react";

import { BarcodeReader, CodeDetection, Configuration, StrichSDK } from "@pixelverse/strichjs-sdk";
import React from "react";


/**
 * Create BarcodeReader configuration
 *
 * @param hostElem The host element hosting the BarcodeReader
 */
function createBarcodeReaderConfig(hostElem: HTMLElement): Configuration {
    return {
        selector: hostElem,
        engine: {
			symbologies: [
                'databar', 'databar-exp', 'code128', 'code39', 'code93', 'i25', 'codabar',
                'ean13', 'ean8', 'upca', 'upce', 'i25'
            ],
            duplicateInterval: 2000,
            numScanlines: 20,
            minScanlinesNeeded: 3
		},
		locator: {
			regionOfInterest: {
                left: 0.05, 
                right: 0.05,
                top: 0.4,
                bottom: 0.4
            }
		},
		frameSource: {
			resolution: 'full-hd'
		},
		feedback: {
			// get audio and vibration feedback for scans
			audio: true,
			vibration: true
		}
    };
}

function StrichScannerHeader() {
    return (
        <section className="scannerHeader">
            <h1>SCANNER</h1>
        </section>
    );
}

function StrichScannerActions() {
    return (
        <section className="scannerActions">
            <button>FINISH SCANNING</button>
        </section>
    );
}

// @ts-ignore
function StrichScannerHost({addDetection}: {addDetection: (CodeDetection) => void}) {

    // a reference to the BarcodeReader host element
    const hostElemRef = useRef<HTMLDivElement | null>(null);

    // the SDK initialization state
    const [sdkState, setSdkState] = useState(StrichSDK.isInitialized() ? 'initialized' : undefined);

    // a reference to a BarcodeReader
    const barcodeReaderRef = useRef<BarcodeReader | null>(null);

    // this effect has no dependencies, so it should run only once (except if React StrictMode is on)
    useEffect(() => {
        const initializeSDK = async () => {
            if (StrichSDK.isInitialized()) {
                setSdkState('initialized');
            } else {
                try {
                    await StrichSDK.initialize('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4Y2QwOGFmNi1lYzI5LTQ3NWQtOGFiMS1iZmFjZTFkYWQ0ZmIiLCJpc3MiOiJzdHJpY2guaW8iLCJhdWQiOlsiaHR0cHM6Ly93ZWJzdGFnZTdhLnNtYXJ0b25lLmNvbSJdLCJpYXQiOjE3MDg0OTAxMDMsIm5iZiI6MTcwODQ5MDEwMywiY2FwYWJpbGl0aWVzIjp7fSwidmVyc2lvbiI6MX0.Z546tnL4qSPxR-sV9F4bIqFhhC8YybYZ5WuDQiLzsZg');
                    console.log(`STRICH SDK initialized successfully`);
                    setSdkState('initialized');
                } catch (e) {
                    console.error(`Failed to initialize STRICH SDK: ${e}`);
                    setSdkState('initialization-error');
                }
            }
        };

        // run async initialization
        if (sdkState === undefined) {
            setSdkState('initializing');
            initializeSDK();
        }
    }, []);

    // BarcodeReader creation, once SDK is initialized
    useEffect(() => {
        if (sdkState === 'initialized' && barcodeReaderRef.current === null) {
            const barcodeReaderInitialization = async () => {

                console.log(`Initializing BarcodeReader...`);

                // @ts-ignore
                const barcodeReader = new BarcodeReader(createBarcodeReaderConfig(hostElemRef.current));
                barcodeReaderRef.current = barcodeReader;
                await barcodeReader.initialize();

                // when a barcode is detected, propagate it up the component tree
                barcodeReader.detected = ((detections) => {
                    detections.map(d => addDetection(d));
                });
                await barcodeReader.start();
            };
            barcodeReaderInitialization();

            // destroy the BarcodeReader in the cleanup function
            return () => {
                if (barcodeReaderRef.current !== null) {
                    console.log(`Destroying BarcodeReader`);
                    barcodeReaderRef.current.destroy();
                    barcodeReaderRef.current = null;
                }
            };
        }
    }, [sdkState]);

    // the component acts as the STRICH BarcodeReader host element
    return (
        <div className="barcodeReader" ref={hostElemRef} style={{ position: 'relative', height:'400px' }}/>
    );
}

/**
 * Component for displaying code detections.
 */
function StrichScannerResults({detections}: { detections: CodeDetection[] }) {
    return (
        <div className="scannerResults">
            {detections.map((detection) => (
                <span key={detection.time}>{detection.data}</span>
            ))}
        </div>
    )
}

/**
 * Parent component hosting the scanner, results and a button bar for actions.
 */
export function StrichScanner() {
    const [detections, setDetections] = useState([] as CodeDetection[]);
    const addDetection = useCallback((detection: CodeDetection) => {
        // add detection to list
        setDetections((prevDetections) => [...prevDetections, detection])
    }, [setDetections]);
    return (
        <main className="scannerWrapper">
            <StrichScannerHeader/>
            <StrichScannerHost addDetection={addDetection}/>
            <StrichScannerResults detections={detections}/>
            <StrichScannerActions/>
        </main>
    );
}

export default StrichScanner