/*
com/smartone/hook/otp/OtpHook
*/
import React, { useCallback, useContext, useState, useReducer, useEffect, useRef } from 'react';
import { BrowserMultiFormatOneDReader, BrowserMultiFormatReader, BrowserQRCodeReader, IScannerControls } from '@zxing/browser';
import { StrichSDK, BarcodeReader, Configuration, CodeDetection } from '@pixelverse/strichjs-sdk';
import { CodeReaderType } from './CodeReaderType';
import deepmerge from 'deepmerge';
import { styled } from 'styled-components';
import ApplicationContext from '@smt/context/ApplicationContext';
//https://zxing-js.github.io/library/

const StyledCodeReader = styled.div(({ theme }) => ({
	width: '100%',
	height: '100%',
	position: 'relative',
}));

export interface ScanResult {
	status: 'ok' | 'fail';
	result?: string;
	error?: string;
}

//TODO: merge setting
const defaultCodeReaderConfig = (selector: HTMLElement): Configuration => {
	return {
		selector: selector,
		engine: {
			symbologies: ['databar', 'databar-exp', 'code128', 'code39', 'code93', 'i25', 'codabar', 'ean13', 'ean8', 'upca', 'upce', 'i25'],
			duplicateInterval: 2000,
			numScanlines: 20,
			minScanlinesNeeded: 3,
		},
		locator: {
			regionOfInterest: {
				left: 0.05,
				right: 0.05,
				top: 0.4,
				bottom: 0.4,
			},
		},
		frameSource: {
			resolution: 'full-hd',
		},
		feedback: {
			// get audio and vibration feedback for scans
			audio: true,
			vibration: true,
		},
	};
};

export function useCodeReader() {
	const applicationContext = useContext(ApplicationContext);
	const [scanerStatus, SetScanerStatus] = useState<string | undefined>(undefined);
	const [scanResult, SetScanResult] = useState<ScanResult>({ status: 'ok' });
	const barcodeReaderRef = useRef<BarcodeReader | null>(null);
	const hostElemRef = useRef<HTMLDivElement | null>(null);

	const startScan = useCallback(async () => {
		try {
			if (scanerStatus === 'initialized' && hostElemRef.current != null) {
				const barcodeReader = new BarcodeReader(defaultCodeReaderConfig(hostElemRef.current));
				barcodeReaderRef.current = barcodeReader;
				await barcodeReader.initialize();

				// when a barcode is detected, propagate it up the component tree
				barcodeReader.detected = (detections) => {
					detections.map((detection) => {
						const result: ScanResult = {
							status: 'ok',
							result: detection.data,
						};
						SetScanResult(result);
					});
				};
				await barcodeReader.start();
			} else {
				const result: ScanResult = {
					status: 'fail',
					error: 'SDK not initialized',
				};
				SetScanResult(result);
			}
		} catch (e) {
			const result: ScanResult = {
				status: 'fail',
				error: e,
			};
			SetScanResult(result);
			SetScanerStatus('initialization-error');
		}
	}, [SetScanResult, scanerStatus]);

	const stopScan = useCallback(() => {
		if (barcodeReaderRef.current !== null) {
			barcodeReaderRef.current.destroy();
			barcodeReaderRef.current = null;
		}
	}, [barcodeReaderRef]);

	useEffect(() => {
		const initializeSDK = async () => {
			if (StrichSDK.isInitialized()) {
				SetScanerStatus('initialized');
			} else {
				try {
					await StrichSDK.initialize(applicationContext?.StrichSDK?.key || '');
					console.log(`STRICH SDK initialized successfully`);
					SetScanerStatus('initialized');
				} catch (e) {
					console.error(`Failed to initialize STRICH SDK: ${e}`);
					SetScanerStatus('initialization-error');
				}
			}
		};

		if (scanerStatus === undefined) {
			SetScanerStatus('initializing');
			initializeSDK();
		}
	}, []);

	return { startScan, stopScan, scanResult, scanerStatus, Screen: <StyledCodeReader ref={hostElemRef}></StyledCodeReader> };
}
