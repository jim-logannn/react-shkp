/*
com/smartone/hook/otp/OtpHook
*/
import React, { useCallback, useContext, useLayoutEffect, useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import ApplicationContext, { getUrlValue, ApplicationContextValue } from '@smt/context/ApplicationContext';
import { CONTENT_TYPE_JSON, CONTENT_TYPE_X_WWW_FORM_URLENCODED, REQUEST_METHOD_POST } from '@smt/hook/xhr/XMLHttpRequestHook';
import { ResponseProcessor, useAjax } from '@smt/hook/xhr/AjaxHook';
import { convertLanguage, convertLocale } from '@smt/type/common';
import { Channel } from '@smt/context/ApplicationContext';
import { Step } from '@/type/Step';
import { ApplyService } from '@/type/Form';

export interface PreValidationSim {
	sim: string;
	service: keyof ApplyService;
}
export interface PreValidationSimResponse extends PreValidationSim {
	status: 'fail' | 'ok';
	error?: string;
}
export interface PreValidationIMEI {
	IMEI: string;
	service: keyof ApplyService;
}
export interface PreValidationIMEIResponse extends PreValidationIMEI {
	status: 'fail' | 'ok';
	error?: string;
}
export interface PreValidationSerial {
	serial: string;
}
export interface PreValidationSerialResponse extends PreValidationSerial {
	status: 'fail' | 'ok';
	error?: string;
}
export interface PreValidationAddressQuota {
	quota: {
		warning_lower_limit: number;
		lower_limit: number;
		quota: number;
		quota_balance: number;
	};
	total_submit: number;
}

export interface PreValidationProps {
	channel: Channel;
	staff_ID: string;
	step: 'isCheckingAddress' | 'isCheckingFullform';
	sim_list?: PreValidationSim[];
	IMEI_list?: PreValidationIMEI[];
	serial_list?: PreValidationSerial[];
	address?: {
		flat: string;
		floor: string;
		block: string;
	};
}
interface PreValidationRequestData {}
export interface PreValidationResponse {
	status: 'fail' | 'ok';
	err_code?: string;
	address?: {
		flat: string;
		floor: string;
		block: string;
		address_quota?: {
			[key in keyof ApplyService]: PreValidationAddressQuota;
		};
	};
	sim_list?: PreValidationSimResponse[];
	serial_list?: PreValidationSerialResponse[];
	IMEI_list?: PreValidationIMEIResponse[];
}
export interface PreValidationResult {
	status: 'fail' | 'ok';
	result?: PreValidationResponse;
	requestData?: PreValidationProps;
	err_code?: string;
	err_msg?: string;
	error?: string;
}

export function usePreValidation() {
	const responseProcessor: ResponseProcessor<PreValidationProps, PreValidationResult> = useCallback((response, requestData) => {
		const result: PreValidationResult = {
			status: 'fail',
		};
		if (response == undefined) {
			result.error = 'response text undefined'; // not likely
		} else {
			try {
				const json: PreValidationResponse = JSON.parse(response);
				if (json) {
					if (json.status == 'ok') {
						result.status = 'ok';
						result.result = json;

						if (requestData) {
							result.requestData = requestData;
						}
					} else {
						result.err_code = json.err_code as string;
					}
				} else {
					result.error = 'JSON.parse response text returned null';
				}
			} catch (exception) {
				console.log(exception);
				result.error = exception as string;
			}
		}
		return result;
	}, []);

	const { ajaxResult, runAjax, abortAjax } = useAjax(responseProcessor);
	const intl = useIntl();
	const lang = convertLanguage(intl.locale);
	const applicationContext = useContext(ApplicationContext);

	const preValidation = useCallback(
		(props: PreValidationProps) => {
			if (applicationContext?.api?.preValidation) {
				const url = getUrlValue(applicationContext.api.preValidation, lang);
				const method = REQUEST_METHOD_POST;
				const contentType = CONTENT_TYPE_JSON;
				const data = { ...props };
				const requestData: PreValidationProps = { ...props };
				runAjax({
					url,
					method,
					contentType,
					data,
					requestData,
				});
			}
		},
		[applicationContext?.api?.preValidation, lang, responseProcessor],
	);

	return { preValidation, result: ajaxResult };
}
