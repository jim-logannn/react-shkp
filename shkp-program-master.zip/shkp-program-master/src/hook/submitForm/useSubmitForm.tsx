/*
com/smartone/hook/otp/OtpHook
*/
import React, { useCallback, useContext, useLayoutEffect, useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import ApplicationContext, { getUrlValue, ApplicationContextValue } from '@smt/context/ApplicationContext';
import { CONTENT_TYPE_JSON, CONTENT_TYPE_X_WWW_FORM_URLENCODED, REQUEST_METHOD_POST } from '@smt/hook/xhr/XMLHttpRequestHook';
import { ResponseProcessor, useAjax } from '@smt/hook/xhr/AjaxHook';
import { convertLanguage, convertLocale } from '@smt/type/common';

export interface SubmitFormProps {}
export interface SubmitFormResponse {
	status: 'fail' | 'ok';
	ref?: string;
	err_code?: string;
	err_msg?: string;
}
export interface SubmitFormResult {
	status: 'fail' | 'ok';
	result?: SubmitFormResponse;
	ref?: string;
	requestData?: SubmitFormProps;
	err_code?: string;
	error?: string;
}

export function useSubmitForm() {
	const responseProcessor: ResponseProcessor<SubmitFormProps, SubmitFormResult> = useCallback((response, requestData) => {
		const result: SubmitFormResult = {
			status: 'fail',
		};
		if (response == undefined) {
			result.error = 'response text undefined'; // not likely
		} else {
			try {
				const json: SubmitFormResponse = JSON.parse(response);
				if (json) {
					if (json.status == 'ok') {
						result.status = 'ok';

						if (requestData) {
							result.requestData = requestData;
						}
						if (json.ref) {
							result.ref = json.ref;
						}
						if (json.err_msg){
							result.error = json.err_msg;
						}
					} else {
						result.err_code = json.err_code as string;
						result.error = json.err_msg;
					}
				} else {
					result.error = 'JSON.parse response text returned null';
				}
			} catch (exception) {
				console.log(exception);
				result.error = exception as string;
			}
		}
		return result;
	}, []);

	const { ajaxResult, runAjax, abortAjax } = useAjax(responseProcessor);
	const intl = useIntl();
	const lang = convertLanguage(intl.locale);
	const applicationContext = useContext(ApplicationContext);

	const submitForm = useCallback(
		(props: SubmitFormProps) => {
			if (applicationContext?.api?.submitForm) {
				const url = getUrlValue(applicationContext.api.submitForm, lang);
				const method = REQUEST_METHOD_POST;
				const contentType = CONTENT_TYPE_JSON;
				const data = { ...props };
				const requestData: SubmitFormProps = { ...props };
				runAjax({
					url,
					method,
					contentType,
					data,
					requestData,
				});
			}
		},
		[applicationContext?.api?.submitForm, lang, responseProcessor],
	);

	return { submitForm, result: ajaxResult };
}
