/*
com/smartone/hook/otp/OtpHook
*/
import React, { useCallback, useContext, useLayoutEffect, useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import { convertLanguage, convertLocale } from '@smt/type/common';
import { Backdrop, CircularProgress, styled } from '@mui/material';

const StyledLoader = styled(CircularProgress, {
	shouldForwardProp: (props) => {
		return props !== 'isShowloader';
	},
})<{ isShowloader: boolean }>(({ theme, isShowloader, ...props }) => ({
	color: theme.palette.grey[50],
	display: isShowloader ? 'inline-block' : 'none',
}));

interface UseLoadingProps {
	fullScreen?: boolean;
}

export function useLoading({ fullScreen }: UseLoadingProps) {
	const [isShowloader, setIsShowloader] = useState(false);

	const showLoading = () => {
		setIsShowloader(true);
	};
	const hideLoading = () => {
		setIsShowloader(false);
	};
	function LoadingScreen() {
		return (
			<>
				{fullScreen && (
					<Backdrop open={isShowloader}>
						<StyledLoader isShowloader={isShowloader} color="inherit" />
					</Backdrop>
				)}
				{!fullScreen && <StyledLoader isShowloader={isShowloader} color="inherit" />}
			</>
		);
	}

	return { showLoading, hideLoading, LoadingScreen };
}
