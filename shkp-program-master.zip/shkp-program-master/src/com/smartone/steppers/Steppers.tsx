/**
 * com/smartone/steppers/Steppers
 **/
import React from 'react';
import { Step, Stepper, StepLabel, StepIconProps, StepConnector, Theme, styled } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import { DefaultTheme } from 'styled-components';
//
const QontoConnector = styled(StepConnector)(({ theme }) => ({
	'&.MuiStepConnector-alternativeLabel': {
		left: `calc(-50% + ${theme.spacing(2)})`,
		right: `calc(50% + ${theme.spacing(2)})`,
	},
	'&.MuiStepConnector-active': {
		'& .MuiStepConnector-line': {
			borderColor: theme.palette.primary.main,
		},
	},
	'&.MuiStepConnector-completed': {
		'& .MuiStepConnector-line': {
			borderColor: theme.palette.primary.main,
		},
	},
	'& .MuiStepConnector-line': {
		borderColor: theme.palette.grey[50],
		borderTopWidth: 3,
		borderRadius: 1,
	},
}));
const QontoStepIconRoot = styled('div')<{ ownerState: { active?: boolean; completed?: boolean } }>(({ theme, ownerState }) => ({
	color: theme.palette.grey[80],
	display: 'flex',
	width: 30,
	height: 30,
	justifyContent: 'center',
	borderRadius: '100%',
	border: '2px solid transparent',
	borderColor: theme.palette.grey[50],
	alignItems: 'center',
	...(ownerState.active && {
		color: theme.palette.white.main,
		background: theme.palette.primary.main,
		border: 'none',
	}),
	...(ownerState.completed && {
		color: theme.palette.white.main,
		background: theme.palette.primary.main,
		border: 'none',
	}),
	'& .QontoStepIcon-completedIcon': {
		color: theme.palette.white.main,
		zIndex: 1,
		...theme.typography.p5,
	},
	'& .QontoStepIcon-circle': {
		width: 8,
		height: 8,
		borderRadius: '50%',
		backgroundColor: 'currentColor',
	},
}));
const StyledStepLabel = styled(StepLabel)(({ theme }) => ({
	'& .MuiStepLabel-label': {
		color: theme.palette.grey[80],
		marginTop: theme.spacing(0.5),
		...theme.typography.p5,
	},
	// '& .MuiStepLabel-label.MuiStepLabel-active': {
	// 	fontWeight: 300,
	// },
	'& .MuiStepLabel-label.MuiStepLabel-alternativeLabel': {
		marginTop: theme.spacing(0.5),
	},
}));
const StyledStepper = styled(Stepper)`
	&.MuiStepper-root {
		padding: 0;
		width: 100%;
		max-width: 305px;
	}
`;
//
function QontoStepIcon(props: StepIconProps) {
	const { active, completed, className } = props;

	return (
		<QontoStepIconRoot ownerState={{ active, completed }} className={className}>
			{completed ? <CheckIcon className="QontoStepIcon-completedIcon" /> : <div className="QontoStepIcon-circle" />}
		</QontoStepIconRoot>
	);
}

//
export interface SteppersProps {
	activeStep: number;
	steps: string[];
}

function Steppers({ activeStep = 0, steps }: SteppersProps) {
	return (
		<StyledStepper alternativeLabel activeStep={activeStep} connector={<QontoConnector />}>
			{steps.map((label) => (
				<Step key={label}>
					<StyledStepLabel StepIconComponent={QontoStepIcon}>{label}</StyledStepLabel>
				</Step>
			))}
		</StyledStepper>
	);
}
export default Steppers;
