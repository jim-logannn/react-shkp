import { ThemeOptions } from '@mui/material/styles';

declare module '@mui/material' {
	interface Color {
		20: string;
		40: string;
		50: string;
		60: string;
		80: string;
		90: string;
	}
}
declare module '@mui/material/styles' {
	interface TypographyVariants {
		h7: React.CSSProperties;
		h8: React.CSSProperties;
		h9: React.CSSProperties;
		p1: React.CSSProperties;
		p2: React.CSSProperties;
		p3: React.CSSProperties;
		p4: React.CSSProperties;
		p5: React.CSSProperties;
		p6: React.CSSProperties;
		p7: React.CSSProperties;
		p8: React.CSSProperties;
	}
	interface TypographyVariantsOptions {
		h7: React.CSSProperties;
		h8: React.CSSProperties;
		h9: React.CSSProperties;
		p1: React.CSSProperties;
		p2: React.CSSProperties;
		p3: React.CSSProperties;
		p4: React.CSSProperties;
		p5: React.CSSProperties;
		p6: React.CSSProperties;
		p7: React.CSSProperties;
		p8: React.CSSProperties;
	}
	interface Palette {
		black: Palette['primary'];
		white: Palette['primary'];
		green: Palette['primary'];
		blue: Palette['primary'];
		orange: Palette['primary'];
		yellow: Palette['primary'];
		purple: Palette['primary'];
		gold: Palette['primary'];
	}
	interface PaletteOptions {
		black: PaletteOptions['primary'];
		white: PaletteOptions['primary'];
		green: PaletteOptions['primary'];
		blue: PaletteOptions['primary'];
		orange: PaletteOptions['primary'];
		yellow: PaletteOptions['primary'];
		purple: PaletteOptions['primary'];
		gold: PaletteOptions['primary'];
	}
}
declare module '@mui/material/Typography' {
	interface TypographyPropsVariantOverrides {
		h7: true;
		h8: true;
		h9: true;
		p1: true;
		p2: true;
		p3: true;
		p4: true;
		p5: true;
		p6: true;
		p7: true;
		p8: true;
	}
}

declare module '@mui/material/Button' {
	interface ButtonPropsColorOverrides {
		black: true;
		white: true;
		green: true;
		blue: true;
		orange: true;
		yellow: true;
		purple: true;
		gold: true;
	}
}
