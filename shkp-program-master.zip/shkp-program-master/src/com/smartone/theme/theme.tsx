import { ThemeOptions } from '@mui/material/styles';
import './theme_common';

export const themeOptionsCommon: ThemeOptions = {
	palette: {
		mode: 'light',
		primary: {
			main: '#FF0000',
			light: '#FD4433',
			dark: '#CA1100',
		},
		secondary: {
			main: '#FF0000',
			light: '#FD4433',
			dark: '#FF0000',
		},
		black: {
			main: '#333333',
		},
		grey: {
			20: '#F6F6F6',
			40: '#EBECEE',
			50: '#D3D3D3',
			60: '#C7C7C7',
			80: '#9C9C9C',
			90: '#666666',
		},
		white: {
			main: '#ffffff',
		},
		green: {
			main: '#3E9B3C',
			light: '#74d073',
			dark: '#2b702a',
		},
		blue: {
			main: '#009FDC',
		},
		orange: {
			main: '#F48F4A',
		},
		yellow: {
			main: '#FFB100',
		},
		purple: {
			main: '#E73074',
		},
		gold: {
			main: '#CCA13E',
		},
	},
	shape: {
		borderRadius: 10,
	},
	spacing: 8,
	components: {
		MuiSvgIcon: {
			styleOverrides: {
				root: {
					width: '2rem',
					height: '2rem',
					fontSize: '2rem',
				},
			},
		},
	},
};

export const themeOptionsTc: ThemeOptions = {
	typography: {
		h1: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '4.8rem',
			lineHeight: '7.8rem',
			fontWeight: 700,
		},
		h2: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'san s-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '4.2rem',
			lineHeight: '6.3rem',
			fontWeight: 700,
		},
		h3: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '3.8rem',
			lineHeight: '5.7rem',
			fontWeight: 700,
		},
		h4: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '3.2rem',
			lineHeight: '4.8rem',
			fontWeight: 700,
		},
		h5: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.8rem',
			lineHeight: '4.2rem',
			fontWeight: 700,
		},
		h6: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.4rem',
			lineHeight: '3.6rem',
			fontWeight: 700,
		},
		h7: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.0rem',
			lineHeight: '3.0rem',
			fontWeight: 700,
		},
		h8: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.6rem',
			lineHeight: '2.4rem',
			fontWeight: 700,
		},
		h9: {
			fontFamily: ['titling-gothic-fb-condensed', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.4rem',
			lineHeight: '2.1rem',
			fontWeight: 700,
		},
		p1: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.8rem',
			lineHeight: '4.2rem',
			fontWeight: 400,
		},
		p2: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.4rem',
			lineHeight: '3.6rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p3: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.0rem',
			lineHeight: '3.0rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p4: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.6rem',
			lineHeight: '2.4rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p5: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.4rem',
			lineHeight: '2.1rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p6: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.2rem',
			lineHeight: '1.8rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p7: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.1rem',
			lineHeight: '1.7rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p8: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.0rem',
			lineHeight: '1.5rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		body1: {
			fontFamily: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.6rem',
			lineHeight: '2.4rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
	},
};

export const themeOptionsEn: ThemeOptions = {
	typography: {
		h1: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '4.8rem',
			lineHeight: '7.8rem',
			fontWeight: 500,
		},
		h2: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '4.2rem',
			lineHeight: '6.3rem',
			fontWeight: 500,
		},
		h3: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '3.8rem',
			lineHeight: '5.7rem',
			fontWeight: 500,
		},
		h4: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '3.2rem',
			lineHeight: '4.8rem',
			fontWeight: 500,
		},
		h5: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.8rem',
			lineHeight: '4.2rem',
			fontWeight: 500,
		},
		h6: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.4rem',
			lineHeight: '3.6rem',
			fontWeight: 500,
		},
		h7: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.0rem',
			lineHeight: '3.0rem',
			fontWeight: 500,
		},
		h8: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.6rem',
			lineHeight: '2.4rem',
			fontWeight: 500,
		},
		h9: {
			fontFamily: ['titling-gothic-fb-condensed', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.4rem',
			lineHeight: '2.1rem',
			fontWeight: 500,
		},
		p1: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.8rem',
			lineHeight: '4.2rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p2: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.4rem',
			lineHeight: '3.6rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p3: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '2.0rem',
			lineHeight: '3.0rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p4: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.6rem',
			lineHeight: '2.4rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p5: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.4rem',
			lineHeight: '2.1rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p6: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.2rem',
			lineHeight: '1.8rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p7: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.1rem',
			lineHeight: '1.7rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		p8: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.0rem',
			lineHeight: '1.5rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
		body1: {
			fontFamily: ['titling-gothic-fb-narrow', 'sans-serif', '"Helvetica Neue"', 'Arial', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"'].join(','),
			fontSize: '1.6rem',
			lineHeight: '2.4rem',
			fontWeight: 400,
			letterSpacing: 'normal',
		},
	},
};
