import React from 'react';
import styled from 'styled-components';

interface StyledWrapper extends React.HTMLAttributes<HTMLDivElement> {
	interactive: boolean;
}
const StyledWrapper = styled(({interactive, ...props }: StyledWrapper)=><div {...props}/>)`
	${props=>props.interactive ? "" : "pointer-events:none;"}
`;
export interface InteractiveDivProps extends React.ClassAttributes<HTMLDivElement>, React.HTMLAttributes<HTMLDivElement>{
	interactive?: boolean;
}
const InteractiveDiv = React.forwardRef<HTMLDivElement, InteractiveDivProps>(({interactive=true, children, ...props }, ref) => {
	return <StyledWrapper ref={ref} interactive={interactive} {...props}>{children}</StyledWrapper>;
});
export default InteractiveDiv;