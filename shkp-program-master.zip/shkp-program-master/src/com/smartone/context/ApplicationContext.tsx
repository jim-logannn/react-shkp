import React, { useState, useEffect, useCallback } from 'react';
import deepmerge from 'deepmerge';
import { Language } from '@smt/type/common';

export function getDefaultApplicationContext(): ApplicationContextValue {
	return {
		domain: '',
		api: {
			requestOtp: '/jsp/otp/ajax/otp_send.jsp',
			verifyOtp: '/jsp/otp/ajax/otp_verify.jsp',
			preValidation: '/jsp/SHK_SiliconHill/SHKPnewpropertyoffer/Internal/API_pre_validation.jsp',
			submitForm: '/jsp/SHK_SiliconHill/SHKPnewpropertyoffer/Internal/API_submit_action.jsp',
		},
		channel: 'self-help',
		addressEstate: '',
		addressStreet: '',
		addressDistrict: '',
		mobileWorkingDay: [],
		h5gbbWorkingDay: [],
		fbbWorkingDay: [],
		fbbWorkingTime: [],
		fbbInstallWorkingDay: [],
		meshRouterAddress: { floor_group: [], block_group: [], flat_group: [], list: [] },
		callback: () => {},
	};
}
export function extendDefaultApplicationContext(value: Partial<ApplicationContextValue>): ApplicationContextValue {
	return deepmerge(getDefaultApplicationContext(), value);
}
export function getUrlValue(url: URL_GETTER | undefined, lang: Language): string {
	if (url == undefined) {
		return '';
	}
	return typeof url == 'string' ? url : url(lang);
}

type URL_GETTER = string | ((lang: Language) => string);

interface API {
	[key: string]: URL_GETTER;
}

interface GoogleProps {
	maps?: {
		apiKey?: string;
	};
	recaptcha?: {
		v2?: {
			siteKey?: string;
			enable: boolean;
		};
	};
}

interface HcaptchaProps {
	siteKey?: string;
}

interface StrichSDKProps {
	key?: string;
}

interface MeshRouterAddressList {
	total: number;
	flat: string;
	floor: string;
	block: string;
}
interface MeshRouterAddress {
	floor_group: string[];
	block_group: string[];
	flat_group: string[];
	list: MeshRouterAddressList[];
}

export type Channel = typeof CHANNEL_CLUBHOUSE | typeof CHANNEL_SELF_HELP;
export const CHANNEL_CLUBHOUSE = 'clubhouse';
export const CHANNEL_SELF_HELP = 'self-help';

export interface ApplicationContextValue {
	domain?: String;
	google?: GoogleProps;
	hcaptcha?: HcaptchaProps;
	StrichSDK?: StrichSDKProps;
	api?: API;
	channel?: Channel;
	addressEstate?: string;
	addressStreet?: string;
	addressDistrict?: string;
	mobileWorkingDay?: string[];
	h5gbbWorkingDay?: string[];
	fbbWorkingDay?: string[];
	fbbWorkingTime?: string[];
	fbbInstallWorkingDay?: string[];
	meshRouterAddress?: MeshRouterAddress;
	callback?: (data: any) => void;
}
export default React.createContext<ApplicationContextValue>(getDefaultApplicationContext());
