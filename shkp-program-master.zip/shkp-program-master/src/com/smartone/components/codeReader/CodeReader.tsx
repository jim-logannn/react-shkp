// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useRef } from 'react';
import ReactDOM, { render } from 'react-dom';

// intl
import styled from 'styled-components';
import { useCodeReader } from '@/hook/codeReader/useCodeReader';
import { useEffect } from 'react';
import { CodeReaderType } from '@/hook/codeReader/CodeReaderType';

const StyledVideoContainer = styled.div`
	display: block;
	margin: 0 auto;
	box-sizing: border-box;
	position: fixed;
	top: 0px;
	left: 0;
	width: 100vw;
	height: 100vh;
	opacity: 1;
	z-index: 10;
	transition: all 0.3s ease-in-out;
	background: #000;

	&.hide {
		opacity: 0;
		top: 0px;
		z-index: -10;
	}
`;

const StyledVideo = styled.div`
	display: block;
	margin: 0 auto;
	box-sizing: border-box;
	width: 100%;
	height: 100vh;
	position: relative;
	top: 0;
	left: 0;
`;

const StyledBtnClose = styled.div`
	pointer-events: auto;
	position: absolute;
	width: 30px;
	height: 30px;
	background: #fff;
	border-radius: 20px;
	border: 1px solid #d1d1d1;
	box-shadow: 1px 1px 4px 0px #777;
	top: 20px;
	right: 20px;
	z-index: 1;

	&:before,
	&:after {
		content: '';
		background: #000;
		width: 60%;
		height: 3px;
		position: absolute;
		top: 48%;
		left: 20%;
	}
	&:before {
		transform: rotate(45deg);
	}
	&:after {
		transform: rotate(-45deg);
	}
`;

export interface CodeReaderProp {
	isStartScan: boolean;
	onScanDone: (result: string) => void;
	onScanCancel: () => void;
	onScanFail: (error: string, scanerStatus?: string) => void;
}

const CodeReader = React.forwardRef(({ isStartScan, onScanDone, onScanCancel, onScanFail }: CodeReaderProp, ref) => {
	const { startScan, stopScan, scanerStatus, Screen, scanResult } = useCodeReader();

	useEffect(() => {
		if (isStartScan) {
			startScan();
		}
	}, [isStartScan]);

	const onClose = () => {
		if (onScanCancel) {
			stopScan();
			onScanCancel();
		}
	};

	useEffect(() => {
		if (scanResult.status == 'ok') {
			if (scanResult.result) {
				onScanDone(scanResult.result);
			}
			stopScan();
		} else {
			if (onScanFail) {
				if (scanResult.error) {
					onScanFail(scanResult.error, scanerStatus);
				}
			}
			stopScan();
		}
	}, [scanResult]);

	return (
		<StyledVideoContainer className={isStartScan ? '' : 'hide'}>
			<StyledBtnClose onClick={onClose} />
			<StyledVideo>{Screen}</StyledVideo>
		</StyledVideoContainer>
	);
});

export default CodeReader;
