// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { styled } from '@mui/material';

const StyledTickIconWrap = styled('div')<TickIconProps>(({ theme, ...props }) => ({
	userSelect: 'none',
	display: 'inline-block',
	flexShrink: 0,
	pointerEvents: 'none',
	position: 'relative',
	width: props.size == 'small' ? '12px' : '14px',
	height: props.size == 'small' ? '8px' : '10px',

	svg: {
		position: 'absolute',
		top: 0,
		left: 0,
		width: props.size == 'small' ? '12px' : '14px',
		height: props.size == 'small' ? '8px' : '10px',
	},

	'svg path': {
		fill: 'currentColor',
	},
}));

export interface TickIconProps {
	size?: string;
}

export const TickIcon = ({ size, ...props }: TickIconProps) => {
	return (
		<StyledTickIconWrap size={size} {...props}>
			<svg viewBox="0 0 14 10" xmlns="http://www.w3.org/2000/svg">
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M13.3839 2.07696C13.7745 1.68643 13.7745 1.05327 13.3839 0.662745L13.2731 0.551955C12.8826 0.16143 12.2495 0.161429 11.8589 0.551953L5.70365 6.70724L2.59911 3.6027C2.20859 3.21218 1.57542 3.21218 1.1849 3.6027L1.0741 3.71349C0.683581 4.10402 0.683581 4.73718 1.07411 5.12771L4.87226 8.92586C4.87666 8.93043 4.88112 8.93497 4.88562 8.93948L4.99641 9.05027C5.03089 9.08474 5.06725 9.11617 5.10517 9.14456C5.49688 9.43855 6.05527 9.40736 6.41162 9.05101L6.52241 8.94022C6.53426 8.92837 6.54575 8.91629 6.55689 8.90401L13.3839 2.07696Z"
				/>
			</svg>
		</StyledTickIconWrap>
	);
};

export default TickIcon;
