// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';
import { styled } from '@mui/material';

const StyledDropdownIconWrap = styled('div')<DropdownIconProps>(({ theme, ...props }) => ({
	userSelect: 'none',
	display: 'inline-block',
	flexShrink: 0,
	pointerEvents: 'none',
	color: 'rgba(0, 0, 0, 0.54)',
	position: 'relative',
	width: props.size == 'small' ? '12px' : '12px',
	height: props.size == 'small' ? '7px' : '7px',

	svg: {
		position: 'absolute',
		top: 0,
		left: 0,
		width: props.size == 'small' ? '12px' : '12px',
		height: props.size == 'small' ? '7px' : '7px',
	},

	'svg path': {
		fill: 'currentColor',
	},
}));

export interface DropdownIconProps {
	size?: string;
}

export const DropdownIcon = ({ size, ...props }: DropdownIconProps) => {
	return (
		<StyledDropdownIconWrap size={size} {...props}>
			<svg xmlns="http://www.w3.org/2000/svg">
				<path d="M6.03516 0.0341661L10.5335 0.034166C11.4244 0.034166 11.8706 1.11131 11.2406 1.74127L6.74226 6.23964C6.35174 6.63017 5.71857 6.63017 5.32805 6.23964L0.829678 1.74127C0.199714 1.11131 0.645881 0.0341662 1.53679 0.0341662L6.03516 0.0341661Z" />
			</svg>
		</StyledDropdownIconWrap>
	);
};

export default DropdownIcon;
