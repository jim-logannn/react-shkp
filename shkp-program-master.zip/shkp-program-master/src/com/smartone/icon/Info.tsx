// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';
import { styled } from '@mui/material';

const StyledInfoIconWrap = styled('div')<InfoIconProps>(({ theme, ...props }) => ({
	userSelect: 'none',
	display: 'inline-block',
	flexShrink: 0,
	pointerEvents: 'none',
	position: 'relative',
	width: '2.4rem',
	height: '2.4rem',

	svg: {
		position: 'absolute',
		top: 0,
		left: 0,
		width: '2.4rem',
		height: '2.4rem',
		fill: theme.palette.grey[60],
	},

	'svg path': {
		fill: theme.palette.white.main,
	},
}));

export interface InfoIconProps {}

export const InfoIcon = ({ ...props }: InfoIconProps) => {
	return (
		<StyledInfoIconWrap {...props}>
			<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
				<circle cx="12" cy="12" r="12" />
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M15.5198 7.77404C15.5378 8.22636 15.5327 8.67932 15.5045 9.13113C15.4327 10.1654 14.7921 10.806 14.1295 11.4687C13.353 12.2452 12.5461 13.0521 12.5885 14.5584H10.5769C10.49 12.3825 11.4196 11.3777 12.1623 10.575C12.6226 10.0774 13.0112 9.6574 13.0412 9.08422C13.057 8.81427 13.057 8.54362 13.0412 8.27367C12.9791 7.71294 12.6823 7.40094 11.8718 7.40094C11.1856 7.40094 10.7951 7.71294 10.7329 8.21149C10.7176 8.35113 10.686 9.05258 10.686 9.19331H8.47143C8.465 8.67663 8.50149 8.16031 8.58052 7.64967C8.7987 6.32422 9.90597 5.51367 12.0889 5.51367C14.3351 5.51367 15.3638 6.30894 15.5198 7.77404ZM12.7905 15.2915V18.0362H10.4199V15.2915H12.7905Z"
				/>
			</svg>
		</StyledInfoIconWrap>
	);
};

export default InfoIcon;
