import zh_HK from "com/smartone/locale/zh-HK.json";
import zh_CN from "com/smartone/locale/zh-CN.json";
import en_US from "com/smartone/locale/en-US.json";

export default {
  "en-US": en_US,
  "zh-HK": zh_HK,
  "zh-CN": zh_CN,
};
