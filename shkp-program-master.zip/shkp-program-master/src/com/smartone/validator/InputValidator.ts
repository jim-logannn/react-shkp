/**
 * com/smartone/validator/InputValidator
 **/
export function isValidEmail(sEmail: any): boolean {
	var sEmailCheA = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	return sEmailCheA.test(sEmail);
}
export function isPhoneNumber(sNumber: any): boolean {
	//console.log("isMobileNumber " + sNumber);
	// starts with 5 6 7 9
	var pattern = new RegExp('^(2|3|4|5|6|7|8|9)([0-9]{7})$');
	return sNumber != null && typeof sNumber === 'string' && pattern.test(sNumber);
}
export function isMobileNumber(sNumber: any): boolean {
	//console.log("isMobileNumber " + sNumber);
	// starts with 5 6 7 9
	var pattern = new RegExp('^(4|5|6|7|8|9)([0-9]{7})$');
	return sNumber != null && typeof sNumber === 'string' && pattern.test(sNumber);
}
export function isChinaMobileNumber(sNumber: any): boolean {
	//console.log("isMobileNumber " + sNumber);
	// starts with 1 4 5 6 7 9
	var pattern = new RegExp('^(1|4|5|6|7|8|9)([0-9]{10})$');
	return sNumber != null && typeof sNumber === 'string' && pattern.test(sNumber);
}
export function isValidHkid(hkid: any): boolean {
	let cleanHkid = hkid;
	//clean hkid
	if (hkid.search(/[()]/g) > -1) {
		const hkidArr = hkid.split(/[()]/);
		cleanHkid = hkidArr[0] + hkidArr[1];
	}

	var strValidChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	if (cleanHkid.length < 8) {
		return false;
	}
	cleanHkid = cleanHkid.toUpperCase();
	var hkidPat = /^([A-Z]{1,2})([0-9]{6})([A0-9])$/;
	var matchArray = cleanHkid.match(hkidPat);

	if (matchArray == null) {
		return false;
	}
	var charPart = matchArray[1];
	var numPart = matchArray[2];
	var checkDigit = matchArray[3];
	var checkSum = 0;
	if (charPart.length == 2) {
		checkSum += 9 * (10 + strValidChars.indexOf(charPart.charAt(0)));
		checkSum += 8 * (10 + strValidChars.indexOf(charPart.charAt(1)));
	} else {
		checkSum += 9 * 36;
		checkSum += 8 * (10 + strValidChars.indexOf(charPart));
	}

	for (var i = 0, j = 7; i < numPart.length; i++, j--) {
		checkSum += j * numPart.charAt(i);
	}
	var remaining = checkSum % 11;
	var verify = remaining == 0 ? 0 : 11 - remaining;

	return verify == checkDigit || (verify == 10 && checkDigit == 'A');
}
export function isValidPassport(passport: any): boolean {
	return passport != '' && passport != null && typeof passport === 'string';
}

export function isChineseAddress(sName: string): boolean {
	var pattern = /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff66-\uff9f]/g;
	return sName != null && typeof sName === 'string' && sName != '' && pattern.test(sName);
}

export function isEnglishAddress(sName: string): boolean {
	return !isChineseAddress(sName);
}

export default {
	isValidEmail,
	isPhoneNumber,
	isMobileNumber,
	isChinaMobileNumber,
	isValidHkid,
	isValidPassport,
	isChineseAddress,
	isEnglishAddress,
};
