/*
com/smartone/hook/xhr/AjaxHook
*/
import { useCallback, useContext, useEffect, useLayoutEffect, useState } from 'react';
import { useXHR, FETCH_STATUS_IDLE, FETCH_STATUS_FETCHING, FETCH_STATUS_FAILED, FETCH_STATUS_FETCHED, FETCH_STATUS_ABORTED, XMLHttpRequestProps } from './XMLHttpRequestHook';

export const AJAX_RESULT_STATUS_OK = 'ok';
export const AJAX_RESULT_STATUS_FAILED = 'failed';
export const AJAX_RESULT_STATUS_FETCHING = 'fetching';
export const AJAX_RESULT_STATUS_ABORTED = 'aborted';

export type AjaxResultStatus = typeof AJAX_RESULT_STATUS_OK | typeof AJAX_RESULT_STATUS_FAILED | typeof AJAX_RESULT_STATUS_FETCHING | typeof AJAX_RESULT_STATUS_ABORTED;
export interface AjaxResult<T> {
	status: AjaxResultStatus;
	result?: T;
	error?: string;
}
export type ResponseProcessor<R, T> = (response: string | undefined, requestData: R | undefined) => T;
export function useAjax<R, T>(responseProcessor: ResponseProcessor<R, T>) {
	const { fetchResponse, runFetch, abortFetch } = useXHR<R>();

	const [ajaxResult, setAjaxResult] = useState<AjaxResult<T> | undefined>(undefined);

	useLayoutEffect(() => {
		if (!fetchResponse) {
			return;
		}

		if (fetchResponse.status != FETCH_STATUS_IDLE) {
			console.log('fetchResponse.status = ' + fetchResponse.status);
		}

		if (fetchResponse.status == FETCH_STATUS_IDLE) {
		} else if (fetchResponse.status == FETCH_STATUS_FETCHING) {
			setAjaxResult({ status: AJAX_RESULT_STATUS_FETCHING });
		} else if (fetchResponse.status == FETCH_STATUS_FAILED) {
			setAjaxResult({
				status: AJAX_RESULT_STATUS_FAILED,
				error: fetchResponse.error,
			});
		} else if (fetchResponse.status == FETCH_STATUS_FETCHED) {
			setAjaxResult({
				status: AJAX_RESULT_STATUS_OK,
				result: responseProcessor ? responseProcessor(fetchResponse.responseText, fetchResponse.requestData) : undefined,
			});
		} else if (fetchResponse.status == FETCH_STATUS_ABORTED) {
			setAjaxResult({ status: AJAX_RESULT_STATUS_ABORTED });
		} else {
			console.log('unknown fetchResponse = ' + fetchResponse.status);
		}
	}, [fetchResponse, responseProcessor]);

	return { ajaxResult, runAjax: runFetch, abortAjax: abortFetch };
}
