/**
 * com/smartone/hook/XMLHttpRequestHook
 **/
import ApplicationContext from '@smt/context/ApplicationContext';
import { useCallback, useContext, useEffect, useLayoutEffect, useState } from 'react';

export const FETCH_STATUS_IDLE = 'idle';
export const FETCH_STATUS_FETCHING = 'fetching';
export const FETCH_STATUS_FETCHED = 'fetched';
export const FETCH_STATUS_FAILED = 'failed';
export const FETCH_STATUS_ABORTED = 'aborted';

export const CONTENT_TYPE_X_WWW_FORM_URLENCODED = 'application/x-www-form-urlencoded; charset=UTF-8';
export const CONTENT_TYPE_JSON = 'application/json; charset=UTF-8';
const DEFAULT_CONTENT_TYPE = CONTENT_TYPE_JSON;
export const REQUEST_METHOD_GET = 'GET';
export const REQUEST_METHOD_POST = 'POST';

export type RequestMethod = typeof REQUEST_METHOD_GET | typeof REQUEST_METHOD_POST;

export type FETCH_STATUS = typeof FETCH_STATUS_IDLE | typeof FETCH_STATUS_FETCHING | typeof FETCH_STATUS_FETCHED | typeof FETCH_STATUS_FAILED | typeof FETCH_STATUS_ABORTED;
// pass requestData when calling runFetch, to make it accessible from the response
export interface XMLHttpRequestProps<R> {
	url: string;
	method: RequestMethod;
	contentType?: string;

	// data will be ignored if method is GET
	data?: any;
	searchParams?: URLSearchParams;
	requestData: R;
}
export interface FetchResponse<R> {
	status: FETCH_STATUS;
	responseText?: string;
	requestData?: R;
	error?: string;
}
// when fetchStatus = "fetched", the fetchResponseText should have something
export function useXHR<R>() {
	const [request, setRequest] = useState<XMLHttpRequestProps<R> | undefined>(undefined);
	const [fetchResponse, setFetchResponse] = useState<FetchResponse<R>>({ status: FETCH_STATUS_IDLE });

	useLayoutEffect(() => {
		let isCancelled = false;
		let isLoading = false;

		const abortController = new AbortController();

		//////////////////////////////////////////////////////////////////////////////
		const fetchData = async (url: string, requestInit: RequestInit) => {
			//console.log("start fetchData");
			let fetchStatus: FETCH_STATUS | undefined = undefined;
			let fetchResponseText: string | undefined = undefined;
			let fetchError: string | undefined = undefined;

			isLoading = true;
			setFetchResponse({
				status: FETCH_STATUS_FETCHING,
				requestData: request?.requestData,
			});

			try {
				const response = await fetch(url, requestInit);
				//console.log(response);
				isLoading = false;
				if (response.ok) {
					const result = await response.text();
					fetchStatus = FETCH_STATUS_FETCHED;
					fetchResponseText = result;
				} else {
					fetchError = response.statusText + '(' + response.status + ')';
					fetchStatus = FETCH_STATUS_FAILED;
				}
			} catch (error) {
				console.log('fetch error');
				console.error(error);
				fetchError = error;
				fetchStatus = FETCH_STATUS_FAILED;
			}

			if (isCancelled) {
				console.log('isCancelled');
				if (abortController.signal.aborted) {
					setFetchResponse({
						status: FETCH_STATUS_ABORTED,
						requestData: request?.requestData,
					});
				} else {
					console.log('isCancelled but not aborted');
				}
			} else {
				setFetchResponse({
					status: fetchStatus,
					responseText: fetchResponseText,
					error: fetchError,
					requestData: request?.requestData,
				});
			}
			//console.log("finish fetchData");
		};
		function getHeaders(request: XMLHttpRequestProps<R>) {
			const headers = new Headers();
			// only set Content-Type for POST and PUT
			if (request.method == REQUEST_METHOD_POST) {
				const contentType = request.contentType && request.contentType != null && request.contentType != '' ? request.contentType : DEFAULT_CONTENT_TYPE;
				headers.append('Content-Type', contentType);
			}

			headers.append('X-Requested-With', 'XMLHttpRequest');
			return headers;
		}
		function getMethod(request: XMLHttpRequestProps<R>) {
			return request.method ? request.method : 'POST';
		}
		function getBody(request: XMLHttpRequestProps<R>): Blob | BufferSource | FormData | URLSearchParams | ReadableStream<Uint8Array> | string | undefined {
			if (request.method == 'GET') {
				return undefined;
			}
			// POST
			if (!request.data) {
				return undefined;
			}
			if (request.contentType == CONTENT_TYPE_X_WWW_FORM_URLENCODED) {
				return new URLSearchParams(request.data);
			}
			// otherwise JSON
			return JSON.stringify(request.data);
		}
		function getUrl(request: XMLHttpRequestProps<R>) {
			if (getMethod(request) == 'POST') {
				return request.url;
			}
			// append searchParams
			const url = new URL(request.url, window.location.href);
			if (request.searchParams) {
				const searchParams = request.searchParams;
				searchParams.forEach(function (value, key) {
					url.searchParams.append(key, value);
				});
			}
			return url.toString();
		}
		//////////////////////////////////////////////////////////////////////////////

		if (request == undefined) {
			return;
		}

		const url = getUrl(request);
		const headers = getHeaders(request);
		const method = getMethod(request);
		const body = getBody(request);
		const signal = abortController.signal;
		const requestInit: RequestInit = {
			headers,
			method,
			body,
			signal,
		};
		fetchData(url, requestInit);

		return () => {
			isCancelled = true;

			if (isLoading) {
				console.log('abort fetch');
				abortController.abort();
			}
		};
	}, [request]);

	useEffect(() => {
		if (fetchResponse.status === 'fetched' && typeof fetchResponse.responseText === 'string') {
			const statusCode = JSON.parse(fetchResponse.responseText).statusCode;
			if (statusCode === 401) {
				console.warn('epc: session expired.');
				//TODO: show alert
			}
		}
	}, [fetchResponse]);

	const runFetch = useCallback((req: XMLHttpRequestProps<R>) => {
		setRequest(req);
	}, []);

	const abortFetch = useCallback(() => {
		console.log('abortFetch');
		setRequest(undefined);
	}, []);

	// combine the response in 1 object makes consumer useEffect easier
	return { fetchResponse, runFetch, abortFetch };
}
