/*
com/smartone/hook/otp/OtpHook
*/
import React, { useCallback, useContext, useLayoutEffect, useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import ApplicationContext, { getUrlValue, ApplicationContextValue } from '@smt/context/ApplicationContext';
import { useAjax, ResponseProcessor, AjaxResult } from '../xhr/AjaxHook';
import { REQUEST_METHOD_POST, CONTENT_TYPE_X_WWW_FORM_URLENCODED } from '../xhr/XMLHttpRequestHook';
import { Language, convertLocale } from '@smt/type/common';

/*
const RES_ERROR_NOT_SMC = "NOT_SMC";
*/
interface VerifyOtpResponse {
	status: 'ok' | 'fail';
	redirect?: string;
	cust_num?: string;
	is_smc?: boolean;
	err_code?: string;
}
export interface VerifyOtpProps {
	mobile: string;
	profile: string;
	lang: Language;
	passcode: string;
}
interface VerifyOtpRequestData {
	mobile: string;
}
export interface RequestOtpProps {
	mobile: string;
	profile: string;
	lang: Language;
	recaptcha?: string;
	hcaptcha?: string;
}
interface VerifyOtpResult {
	status: 'fail' | 'ok';
	mobile?: string;
	err_code?: string;
	error?: string;
	redirect?: string;
	cust_num?: string;
	is_smc?: boolean;
}
interface RequestOtpResult {
	status: 'fail' | 'ok';
	error?: string;
}
/*
function getInit(appContext: ApplicationContextValue|undefined) {
	const x: Record<string, OtpVerifiedData> = {};
	if(appContext?.otp) {
		const otp = appContext.otp;
		for(const profile in otp) {
			const profileContext = otp[profile];
			if(profileContext) {
				const data = profileContext.verifiedData;
				if(data) {
					x[profile] = data;
				}
			}
		}
	}
	return x;
}
export function useOtpVerifiedData() {

	
	const appContext = useContext(ApplicationContext);
	const [ data, setData ] = useState<Record<string, OtpVerifiedData>>(getInit(appContext));

	const getOtpVerifiedData = useCallback((profile: string)=>{
		const x = data[profile];
		return x ? x : undefined;
	}, [ data ]);

	return { getOtpVerifiedData };
}
*/
export function useVerifyOtp() {
	// in
	const responseProcessor: ResponseProcessor<VerifyOtpRequestData, VerifyOtpResult> = useCallback((response, requestData) => {
		const result: VerifyOtpResult = {
			status: 'fail',
		};
		if (response == undefined) {
			result.error = 'response text undefined'; // not likely
		} else {
			try {
				const json: VerifyOtpResponse = JSON.parse(response);
				if (json) {
					if (json.status == 'ok') {
						result.status = 'ok';
						result.redirect = json.redirect;
						result.cust_num = json.cust_num;
						result.is_smc = json.is_smc;
						if (requestData) {
							result.mobile = requestData.mobile;
						}
					} else {
						result.err_code = json.err_code as string;
					}
				} else {
					result.error = 'JSON.parse response text returned null';
				}
			} catch (exception) {
				console.log(exception);
				result.error = exception as string;
			}
		}
		return result;
	}, []);

	const { ajaxResult, runAjax, abortAjax } = useAjax(responseProcessor);

	const intl = useIntl();
	const lang = convertLocale(intl.locale);
	const applicationContext = useContext(ApplicationContext);

	const verifyOtp = useCallback(
		({ mobile, profile, lang, passcode }: VerifyOtpProps) => {
			if (applicationContext?.api?.verifyOtp) {
				const url = getUrlValue(applicationContext.api.verifyOtp, lang);
				//console.log("call runFetch " + url);
				const method = REQUEST_METHOD_POST;
				const contentType = CONTENT_TYPE_X_WWW_FORM_URLENCODED;
				const data = {
					m: mobile,
					p: profile,
					lang: lang,
					pass: passcode,
				};
				const requestData: VerifyOtpRequestData = {
					mobile: mobile,
				};
				runAjax({
					url,
					method,
					contentType,
					data,
					requestData,
				});
			} else {
				console.log('Missing api.verifyOtp');
			}
		},
		[applicationContext?.api?.verifyOtp, lang, responseProcessor],
	);

	const abortVerifyOtp = useCallback(() => {
		console.log('abortVerifyOtp');
		abortAjax();
	}, []);

	return { abortVerifyOtp, verifyOtp, verifyOtpResult: ajaxResult };
}
export function useRequestOtp() {
	// in
	const responseProcessor: ResponseProcessor<undefined, RequestOtpResult> = useCallback((response, requestData) => {
		const result: RequestOtpResult = {
			status: 'fail',
		};
		if (response == undefined) {
			result.error = 'response text undefined'; // not likely
		} else {
			try {
				const json = JSON.parse(response);
				if (json) {
					if (json.status == 'ok') {
						result.status = 'ok';
					} else {
						result.error = json.err_code as string;
					}
				} else {
					result.error = 'JSON.parse response text returned null';
				}
			} catch (exception) {
				console.log(exception);
				result.error = exception as string;
			}
		}
		return result;
	}, []);
	const { ajaxResult, runAjax, abortAjax } = useAjax(responseProcessor);

	const intl = useIntl();
	const lang = convertLocale(intl.locale);
	const applicationContext = useContext(ApplicationContext);

	const abortRequestOtp = useCallback(() => {
		console.log('abortRequestOtp');
		abortAjax();
	}, []);

	const requestOtp = useCallback(
		({ mobile, profile, lang, recaptcha, hcaptcha }: RequestOtpProps) => {
			if (applicationContext?.api?.requestOtp) {
				const url = getUrlValue(applicationContext.api.requestOtp, lang);
				console.log('call runFetch ' + url);
				const method = REQUEST_METHOD_POST;
				const contentType = CONTENT_TYPE_X_WWW_FORM_URLENCODED;
				const data = {
					m: mobile,
					p: profile,
					lang: lang,
					'g-recaptcha-response': recaptcha || '',
					'h-captcha-response': hcaptcha || '',
				};
				runAjax({
					url,
					method,
					contentType,
					data,
					requestData: undefined,
				});
			} else {
				console.log('Missing api.requestOtp');
			}
		},
		[applicationContext?.api?.requestOtp, lang, responseProcessor],
	);

	return { abortRequestOtp, requestOtp, requestOtpResult: ajaxResult };
}
