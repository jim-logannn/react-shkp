/**
 * com/smartone/lang/Lang
 **/

import { LocaleTC, LocaleEN, LocaleSC, SLangEN, SLangTC, SLangSC } from '@smt/type/common';

// export type Language = typeof SLangTC | typeof SLangEN | typeof SLangSC;
// export type Locale = typeof LocaleTC | typeof LocaleEN | typeof LocaleSC;

// export const getLangFromLocale = function (locale: string): Language {
// 	switch (locale) {
// 		case LocaleTC:
// 			return SLangTC;
// 		case LocaleEN:
// 			return SLangEN;
// 		case LocaleSC:
// 			return SLangSC;

// 		default:
// 			return SLangEN;
// 	}
// };
