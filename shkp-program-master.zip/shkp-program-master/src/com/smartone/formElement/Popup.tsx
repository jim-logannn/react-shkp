// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { Backdrop, Dialog, DialogActions, DialogContent, DialogContentText, DialogProps, DialogTitle, IconButton, ModalProps, styled } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const StyledTitle = styled(DialogTitle)(({ theme, ...props }) => ({
	display: 'flex',
	justifyContent: 'flex-start',
	alignItems: 'center',
	gap: theme.spacing(3),
}));
const StyledTitleContent = styled('div')(({ theme, ...props }) => ({
	...theme.typography.h5,
}));
const StyledCloseButton = styled('div')(({ theme, ...props }) => ({
	justifySelf: 'flex-end',
	marginLeft: 'auto',
}));
const StyledDialogAction = styled(DialogActions)(({ theme, ...props }) => ({
	padding: theme.spacing(2),
	gap: theme.spacing(3),
}));

interface PopupProps extends DialogProps {
	dialogTitle?: string | React.ReactNode;
	dialogAction?: React.ReactNode;
}

function Popup({ dialogTitle, children, dialogAction, open, onClose, maxWidth = 'lg', ...props }: PopupProps) {
	return (
		<Dialog open={open} onClose={onClose} maxWidth={maxWidth}>
			<StyledTitle>
				<StyledTitleContent>{dialogTitle}</StyledTitleContent>
				{onClose != undefined && (
					<StyledCloseButton>
						<IconButton
							onClick={() => {
								onClose({}, 'escapeKeyDown');
							}}
						>
							<CloseIcon />
						</IconButton>
					</StyledCloseButton>
				)}
			</StyledTitle>
			<DialogContent>{children}</DialogContent>
			<StyledDialogAction>{dialogAction}</StyledDialogAction>
		</Dialog>
	);
}

export default Popup;
