// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { InputLabel, InputLabelProps, styled } from '@mui/material';

const StyledInputLabel = styled(InputLabel)<InputLabelProps>(({ theme, ...props }) => ({
	'&': {
		position: 'relative',
		maxWidth: '100%',
		top: 0,
		left: 0,
		transform: 'none',
		marginBottom: theme.spacing(0.5),
		color: theme.palette.black.main,
		...theme.typography.p5,
	},

	'&.Mui-focused': {
		color: theme.palette.black.main,
	},

	'&.Mui-error': {
		color: theme.palette.black.main,
	},
}));

function Label({ ...props }: InputLabelProps) {
	return <StyledInputLabel {...props}>{props.children}</StyledInputLabel>;
}

export default Label;
