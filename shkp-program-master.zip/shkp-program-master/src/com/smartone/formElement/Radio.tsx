// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { Radio as MuiRadio, styled, RadioProps } from '@mui/material';
import TickIcon, { TickIconProps } from '@smt/icon/Tick';

const StyledRadioIcon = styled('span')<CustomRadioProps>(({ theme, ...props }) => ({
	borderRadius: '100%',
	width: props.size === 'small' ? '2.4rem' : '3.8rem',
	height: props.size === 'small' ? '2.4rem' : '3.8rem',
	border: '2px solid transparent',
	borderColor: theme.palette.grey[50],
	position: 'relative',

	'.Mui-disabled &': {
		borderColor: theme.palette.grey[40],
		background: theme.palette.grey[40],
	},
}));

const StyledRadioCheckedIcon = styled(StyledRadioIcon)<CustomRadioProps>(({ theme, ...props }) => ({
	'&:before': {
		content: "''",
		width: '70%',
		height: '70%',
		display: 'block',
		background: theme.palette.primary.main,
		borderRadius: '100%',
		top: '15%',
		left: '15%',
		position: 'absolute',
	},

	'.MuiSvgIcon-root': {
		position: 'absolute',
		color: theme.palette.white.main,
		width: '70%',
		height: '70%',
		top: '15%',
		left: '15%',
	},

	'.Mui-disabled &': {
		background: theme.palette.white.main,
	},
	'.Mui-disabled &:before': {
		background: theme.palette.grey[80],
	},
}));

const StyledRadio = styled(MuiRadio)<CustomRadioProps>(({ theme, ...props }) => ({
	alignSelf: 'flex-start',
}));

const StyledTickIcon = styled(TickIcon)<TickIconProps>(({ theme, ...props }) => ({
	color: theme.palette.white.main,
	position: 'absolute',
	top: `calc(50% - ${props.size === 'small' ? '4px' : '4px'})`,
	left: `calc(50% - ${props.size === 'small' ? '6px' : '7px'})`,
}));

type CustomRadioProps = {} & RadioProps;

function Checkbox({ icon, checkedIcon, size, ...props }: CustomRadioProps) {
	return (
		<StyledRadio
			icon={<StyledRadioIcon size={size} />}
			checkedIcon={
				<StyledRadioCheckedIcon size={size}>
					<StyledTickIcon size={size} />
				</StyledRadioCheckedIcon>
			}
			size={size}
			{...props}
		/>
	);
}
export default Checkbox;
