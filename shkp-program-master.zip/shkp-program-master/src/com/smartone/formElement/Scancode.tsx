// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useRef, useState } from 'react';
import DropdownIcon, { DropdownIconProps } from '@smt/icon/DropdownArrow';
import CodeReader from '@smt/components/codeReader/CodeReader';
import TextField, { CustomTextFieldProps } from './TextField';
import { InputAdornment, Typography, styled } from '@mui/material';
import DocumentScannerIcon from '@mui/icons-material/DocumentScanner';

const StyledIcon = styled(DocumentScannerIcon)(({ theme }) => ({
	cursor: 'pointer',
}));

type ScancodeProp = {
	value?: string;
	onScanStart?: () => void;
	onScanDone?: (value: string) => void;
	onScanFail?: (error: string) => void;
	onScanCancel?: () => void;
} & CustomTextFieldProps;

const Scancode = React.forwardRef(({ onScanStart, onScanDone, onScanFail, onScanCancel, ...props }: ScancodeProp, ref) => {
	const [isStartScan, setIsStartScan] = useState<boolean>(false);
	const [scanerStatus, setScanerStatus] = useState<boolean>(true);

	const onScanCodeStart = () => {
		setIsStartScan(true);
		if (onScanStart) {
			onScanStart();
		}
	};
	const onScanCodeDone = (result: string) => {
		setIsStartScan(false);
		if (onScanDone) {
			onScanDone(result);
		}
	};
	const onScanCodeFail = (error: string, scanerStatus?: string) => {
		setIsStartScan(false);
		if (onScanFail) {
			onScanFail(error);
		}

		if (scanerStatus == 'initialization-error') {
			setScanerStatus(false);
		}
	};
	const onScanCodeCancel = () => {
		setIsStartScan(false);
		if (onScanCancel) {
			onScanCancel();
		}
	};

	return (
		<>
			<TextField
				InputProps={
					scanerStatus
						? {
								endAdornment: (
									<InputAdornment position="end">
										<StyledIcon onClick={onScanCodeStart}></StyledIcon>
									</InputAdornment>
								),
						  }
						: {}
				}
				{...props}
			/>
			{scanerStatus && <CodeReader isStartScan={isStartScan} onScanCancel={onScanCodeCancel} onScanDone={onScanCodeDone} onScanFail={onScanCodeFail} />}
		</>
	);
});

export default Scancode;
