// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useEffect, useRef, useState } from 'react';
import { TextField as MuiTextField, TextFieldProps, styled } from '@mui/material';
import { useMemo } from 'react';

const StyledTextField = styled(MuiTextField)<CustomTextFieldProps>(({ theme, labelPos, ...props }) => ({
	'&.MuiTextField-root + .MuiTextField-root': {
		marginTop: theme.spacing(1),
	},

	/*field root*/
	'&.MuiTextField-root':
		labelPos == 'left'
			? {
					'flex-direction': 'row',
					'align-items': 'center',
					'column-gap': theme.spacing(1),
			  }
			: '',
	'.MuiInputLabel-root': {
		position: 'relative',
		maxWidth: '100%',
		top: 0,
		left: 0,
		transform: 'none',
		marginBottom: theme.spacing(0.5),
		color: theme.palette.black.main,
		...theme.typography.p5,

		overflow: labelPos == 'left' ? 'unset' : '',
	},
	legend: {
		display: 'none',
	},
	'.MuiOutlinedInput-notchedOutline': {
		border: '2px solid' + theme.palette.grey[50],
		top: 0,
	},
	/*input*/
	'.MuiOutlinedInput-root': {
		padding: 0,

		'&.MuiInputBase-adornedStart': {
			paddingLeft: theme.spacing(2),
		},
		'&.MuiInputBase-adornedEnd': {
			paddingRight: theme.spacing(2),
		},
	},
	'.MuiOutlinedInput-input': {
		borderRadius: theme.shape.borderRadius,
		border: '2px solid' + theme.palette.grey[50],
		...theme.typography.p4,
		padding: theme.spacing(2),
	},
	'&.MuiTextField-root .MuiOutlinedInput-root .MuiOutlinedInput-input::-webkit-input-placeholder': {
		opacity: ' 0.42!important',
		color: 'currentColor',
	},
	/*hover*/
	'&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.grey[50],
	},
	/*focused*/
	'.Mui-focused.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.primary.main,
	},
	'.Mui-focused.MuiInputLabel-root': {
		color: theme.palette.black.main,
	},
	/*disabled*/
	'.Mui-disabled.MuiOutlinedInput-input': {
		background: theme.palette.grey[50],
	},
	'.Mui-disabled.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.grey[50],
	},
	/*helper text*/
	'.MuiFormHelperText-root': {
		...theme.typography.p6,
		marginLeft: 0,
	},

	/*error*/
	'.Mui-error.MuiInputLabel-root': {
		color: theme.palette.black.main,
	},
	'.Mui-error .MuiOutlinedInput-input': {
		borderColor: theme.palette.primary.main,
	},
	'.Mui-error.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.primary.main,
	},
	'.Mui-error.MuiFormHelperText-root': {
		color: theme.palette.primary.main,
	},

	/*prefix suffix*/
	'.MuiInputAdornment-root': {
		...theme.typography.p5,
	},
	'.MuiOutlinedInput-input.MuiInputBase-inputAdornedStart': {
		border: 'none',
		paddingLeft: theme.spacing(1),
	},
	'.MuiOutlinedInput-input.MuiInputBase-inputAdornedEnd': {
		border: 'none',
		paddingRight: theme.spacing(1),
	},
}));

export type CustomTextFieldProps = {
	labelPos?: 'left' | 'top';
	errMsg?: string;
} & TextFieldProps;

//TODO: convert to input field comp and Regroup to new TextField comp
const TextField = React.forwardRef(({ errMsg, error, ...props }: CustomTextFieldProps, ref) => {
	const helperText = errMsg ? errMsg : props.helperText ? props.helperText : '';
	return <StyledTextField {...props} error={error ? error : errMsg ? true : false} helperText={helperText} />;
});

export default React.memo(TextField);
