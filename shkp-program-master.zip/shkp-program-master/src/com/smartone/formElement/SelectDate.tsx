// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { FormControl, styled, useTheme } from '@mui/material';
import Label from './Label';
import { DatePicker, DatePickerProps, DateValidationError, PickerChangeHandlerContext, PickersCalendarHeader, PickersDay } from '@mui/x-date-pickers';
import dayjs, { Dayjs } from 'dayjs';

const StyledCalendarHeader = styled(PickersCalendarHeader<Dayjs>)(({ theme, ...props }) => ({
	justifyContent: 'center',
	paddingLeft: theme.spacing(1),
	paddingRight: theme.spacing(1),

	'.MuiPickersCalendarHeader-labelContainer': {
		marginLeft: '7%',
		marginRight: 0,
		zIndex: 1,
	},

	'.MuiPickersArrowSwitcher-root': {
		width: '100%',
		position: 'absolute',
		justifyContent: 'space-between',
	},
}));

const StyledPickerDay = styled(PickersDay<Dayjs>)(({ theme, ...props }) => ({
	...theme.typography.p4,

	'&.Mui-selected': {
		backgroundColor: theme.palette.primary.main,
	},

	'&.MuiPickersDay-today': {
		border: 'none',
	},
	'&.MuiPickersDay-today:before': {
		content: "''",
		width: '60%',
		height: '2px',
		backgroundColor: theme.palette.primary.main,
		position: 'absolute',
		left: '20%',
		bottom: theme.spacing(1),
	},
}));

type SelectDateProps<T> = {
	label: string;
	labelId: string;
	errMsg?: string;
	fullWidth?: boolean;
	children?: React.ReactNode;
} & DatePickerProps<T>;

const SelectDate = React.forwardRef(({ label, labelId, errMsg, children, fullWidth, ...props }: SelectDateProps<Dayjs>, ref) => {
	const theme = useTheme();

	return (
		<FormControl fullWidth>
			<Label id={labelId}>{label}</Label>
			<DatePicker<Dayjs>
				{...props}
				value={props.value ? dayjs(props.value) : null}
				slots={{
					calendarHeader: StyledCalendarHeader,
					day: StyledPickerDay,
				}}
				slotProps={{
					desktopPaper: {
						sx: {
							'& .MuiDayCalendar-weekDayLabel': {
								...theme.typography.p4,
							},
							'& .MuiPickersYear-yearButton': {
								...theme.typography.p4,
							},
						},
					},
					mobilePaper: {
						sx: {
							'& .MuiPickersToolbar-root .MuiTypography-root': {
								...theme.typography.p5,
							},
							'& .MuiPickersToolbar-root .MuiPickersToolbar-content .MuiTypography-root': {
								...theme.typography.h5,
							},
							'& .MuiDayCalendar-weekDayLabel': {
								...theme.typography.p4,
							},
							'& .MuiPickersYear-yearButton': {
								...theme.typography.p4,
							},
							'& .MuiPickersLayout-actionBar .MuiButton-root': {
								...theme.typography.p5,
							},
						},
					},
					field: {
						readOnly: true,
					},
				}}
				format={'YYYY/MM/DD'}
			/>
		</FormControl>
	);
});

export default SelectDate;
