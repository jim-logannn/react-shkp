// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { FormControl, InputLabel, InputLabelProps, SelectProps, styled } from '@mui/material';
import { useMemo } from 'react';
import Select from './Select';
import Label from './Label';

type CustomSelectboxProps = {
	label: string;
	labelId: string;
} & SelectProps;

const Selectbox = React.forwardRef(({ label, labelId, children, ...props }: CustomSelectboxProps, ref) => {
	return (
		<FormControl fullWidth={props.fullWidth}>
			<Label id={labelId}>{label}</Label>
			<Select labelId={labelId} label={label} {...props}>
				{children}
			</Select>
		</FormControl>
	);
});

export default Selectbox;
