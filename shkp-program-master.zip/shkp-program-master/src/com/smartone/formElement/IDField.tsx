// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { FormControl, Input, Typography, styled, useTheme } from '@mui/material';
import TextField from './TextField';
import { useRef } from 'react';
import Label from './Label';
import { useEffect } from 'react';
import { useMemo } from 'react';
import FormHelperText from './FormHelperText';

const StyledHKIDWrapper = styled('div')(({ theme }) => ({
	display: 'flex',
	justifyContent: 'flex-start',
	alignItems: 'center',

	'.MuiTextField-root': {
		marginTop: '0 !important',
	},
}));

const StyledHKIDFirst = styled(TextField)(({ theme }) => ({
	width: '75px',
	marginRight: theme.spacing(1),
}));

export type IDType = 'HKID' | 'Other Passport' | 'Macau Passport' | 'Exit-Entry Permit' | 'Chinese Passport';

export const idFieldName = (type: IDType) => {
	switch (type) {
		case 'HKID':
			return '香港身份證號碼';
		case 'Other Passport':
			return '非中國/澳門護照';
		case 'Macau Passport':
			return '澳門身份證 / 護照';
		case 'Exit-Entry Permit':
			return '往來港澳通行證';
		case 'Chinese Passport':
			return '中國護照';
		default:
			return '';
	}
};

interface IDFieldProps {
	value?: string;
	type?: IDType;
	fullWidth?: boolean;
	errMsg?: string;
	onChange?: (value: any) => void;
}

const IDField = React.forwardRef(({ type = 'HKID', value = '', fullWidth, errMsg, onChange, ...props }: IDFieldProps, ref) => {
	const theme = useTheme();
	const hkidPart1 = useRef<HTMLInputElement>(null);
	const hkidPart2 = useRef<HTMLInputElement>(null);
	const hkidPart3 = useRef<HTMLInputElement>(null);
	const prevData = useRef(type);

	const splitHkid = (value?: string) => {
		if (value) {
			const result = value.match(/([A-Za-z]{0,2})(\d{0,6})(\([A\d]\){0,1})?/) || undefined;
			if (result) {
				let result3 = '';
				if (result[3]) {
					result3 = result[3].split(/[\(\)]/)[1];
				}
				return [result[1], result[2], result3];
			}
		}
		return undefined;
	};

	const onChangeHkid = () => {
		const hkidFull = `${hkidPart1.current?.value}${hkidPart2.current?.value}(${hkidPart3.current?.value})`;
		if (onChange) {
			onChange(hkidFull);
		}
	};

	useEffect(() => {
		if (prevData.current !== type) {
			if (onChange) {
				onChange('');
			}
			prevData.current = type;
		}
	}, [type]);

	return (
		<>
			{type == 'HKID' && (
				<FormControl fullWidth={fullWidth} error={errMsg ? true : false} {...props}>
					<Label>{idFieldName(type)}</Label>
					<StyledHKIDWrapper>
						<StyledHKIDFirst error={errMsg ? true : false} inputProps={{ maxLength: 2 }} inputRef={hkidPart1} onChange={onChangeHkid} value={splitHkid(value)?.[0] || ''} />

						<TextField fullWidth={true} error={errMsg ? true : false} inputProps={{ maxLength: 6 }} inputRef={hkidPart2} onChange={onChangeHkid} value={splitHkid(value)?.[1] || ''} />
						<Typography marginLeft={theme.spacing(0.5)} marginRight={theme.spacing(0.5)}>
							(
						</Typography>
						<TextField style={{ width: '65px' }} error={errMsg ? true : false} inputProps={{ maxLength: 1 }} inputRef={hkidPart3} onChange={onChangeHkid} value={splitHkid(value)?.[2] || ''} />
						<Typography marginLeft={theme.spacing(0.5)} marginRight={theme.spacing(0.5)}>
							)
						</Typography>
					</StyledHKIDWrapper>
					<FormHelperText>{errMsg}</FormHelperText>
				</FormControl>
			)}
			{type !== 'HKID' && (
				<FormControl fullWidth={fullWidth}>
					<TextField label={idFieldName(type)} fullWidth={true} errMsg={errMsg} inputProps={{ maxLength: 11 }} onChange={onChange} value={value} {...props} />
				</FormControl>
			)}
		</>
	);
});

export default IDField;
