// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { FormHelperTextProps, FormHelperText as MuiFormHelperText, styled, useTheme } from '@mui/material';

const StyledFormHelperText = styled(MuiFormHelperText)(({ theme }) => ({
	...theme.typography.p6,
	marginLeft: 0,

	'&.Mui-error': {
		color: theme.palette.primary.main,
	},
}));

const FormHelperText = React.forwardRef(({ ...props }: FormHelperTextProps, ref) => {
	return <StyledFormHelperText {...props}></StyledFormHelperText>;
});

export default FormHelperText;
