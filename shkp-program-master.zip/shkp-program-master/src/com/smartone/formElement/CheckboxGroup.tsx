// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';
import { FormControl, FormGroupProps, FormGroup as MuiFormGroup, styled } from '@mui/material';
import Label from './Label';
import FormHelperText from './FormHelperText';

const StyledCheckboxGroup = styled(MuiFormGroup)<FormGroupProps>(({ theme, ...props }) => ({}));

type CustomCheckboxGroupProps = {
	label: string;
	labelId: string;
	errMsg?: string;
} & FormGroupProps;

const CheckboxGroup = React.forwardRef(({ label, labelId, errMsg, children, ...props }: CustomCheckboxGroupProps, ref) => {
	return (
		<FormControl error={errMsg ? true : false}>
			<Label id={labelId}>{label}</Label>
			<StyledCheckboxGroup {...props}>{children}</StyledCheckboxGroup>
			{errMsg && <FormHelperText>{errMsg}</FormHelperText>}
		</FormControl>
	);
});

export default CheckboxGroup;
