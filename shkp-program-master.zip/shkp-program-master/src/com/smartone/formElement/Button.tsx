// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { Button as MuiButton, ButtonProps, InputLabel, InputLabelProps, styled, ThemeProvider, PaletteOptions, Theme } from '@mui/material';

const handleButtonSize = (theme: Theme, size: ButtonProps['size']) => {
	if (size == 'small') {
		return {
			paddingTop: theme.spacing(1),
			paddingBottom: theme.spacing(1),
			paddingLeft: theme.spacing(2),
			paddingRight: theme.spacing(2),
			...theme.typography.p5,
		};
	} else if (size == 'large') {
		return {
			paddingTop: theme.spacing(3),
			paddingBottom: theme.spacing(3),
			paddingLeft: theme.spacing(4),
			paddingRight: theme.spacing(4),
			...theme.typography.p3,
		};
	} else {
		return {
			paddingTop: theme.spacing(2),
			paddingBottom: theme.spacing(2),
			paddingLeft: theme.spacing(3),
			paddingRight: theme.spacing(3),
			...theme.typography.p4,
		};
	}
};
const handleButtonVariant = (theme: Theme, variant: ButtonProps['variant'], mainColor: string) => {
	if (variant == 'contained') {
		return {
			color: theme.palette.white.main,
			backgroundColor: mainColor,
			borderColor: mainColor,
		};
	} else if (variant == 'outlined') {
		return {
			color: theme.palette.black.main,
			backgroundColor: theme.palette.white.main,
		};
	} else {
		return {
			color: theme.palette.white.main,
			backgroundColor: mainColor,
		};
	}
};

const StyledButton = styled(MuiButton, {
	shouldForwardProp: (props) => {
		return props !== 'fixedWidth';
	},
})<CustomButtonProps>(({ theme, color = 'primary', ...props }) => ({
	borderRadius: '100px',
	borderWidth: 1,
	borderStyle: 'solid',
	boxShadow: 'none',
	borderColor: theme.palette[color].main,

	'&': {
		...handleButtonVariant(theme, props.variant, theme.palette[color].main),
		...handleButtonSize(theme, props.size),
		width: props.fixedWidth === 'full' ? '100%' : '',
		minWidth: props.fixedWidth ? props.fixedWidth : '',
	},

	'&:hover': {
		boxShadow: 'none',
		backgroundColor: theme.palette[color].dark,
		borderColor: theme.palette[color].dark,
		color: theme.palette.white.main,
	},

	'&.Mui-disabled': {
		backgroundColor: theme.palette.grey[50],
		borderColor: theme.palette.grey[50],
	},
}));

type CustomButtonProps = {
	fixedWidth?: 200 | 250 | 400 | 'full';
	color?: keyof PaletteOptions;
} & ButtonProps;

function Button({ children, color, ...props }: CustomButtonProps) {
	return (
		<StyledButton color={color} {...props}>
			{children}
		</StyledButton>
	);
}

export default Button;
