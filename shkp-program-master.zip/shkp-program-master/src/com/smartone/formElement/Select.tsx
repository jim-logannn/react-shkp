// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { Select as MuiSelect, SelectProps, styled } from '@mui/material';
import { useMemo } from 'react';
import DropdownIcon, { DropdownIconProps } from '@smt/icon/DropdownArrow';

const StyledSelect = styled(MuiSelect)<SelectProps>(({ theme, ...props }) => ({
	'.notranslate::after': props.placeholder
		? {
				content: `"${props.placeholder}"`,
				opacity: 0.42,
		  }
		: {},
	legend: {
		display: 'none',
	},
	'.MuiOutlinedInput-notchedOutline': {
		border: '2px solid' + theme.palette.grey[20],
		//TODO: no idea how to override .Mui-disabled .MuiOutlinedInput-notchedOutline
		borderColor: (props.disabled ? theme.palette.grey[50] : theme.palette.grey[20]) + '!important',
		borderRadius: '100px',
		top: 0,
	},

	/*input*/
	'.MuiOutlinedInput-input': {
		borderRadius: '100px',
		border: '2px solid' + theme.palette.grey[20],
		borderColor: props.disabled ? theme.palette.grey[50] : theme.palette.grey[20],
		...theme.typography.p4,
		padding: theme.spacing(2),
		background: theme.palette.grey[20],
	},
	'.MuiOutlinedInput-input:focus': {
		borderRadius: '100px',
	},

	/*hover*/
	'&:hover .MuiOutlinedInput-notchedOutline': {
		borderColor: props.disabled ? theme.palette.grey[50] : theme.palette.grey[20],
	},
	/*focused*/
	'.Mui-focused .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.primary.main,
		borderRadius: '100px',
	},
	'.Mui-focused.MuiInputLabel-root': {
		color: theme.palette.black.main,
	},

	/*disabled*/
	'.Mui-disabled.MuiOutlinedInput-input': {
		background: theme.palette.grey[50],
	},
	'.Mui-disabled .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.grey[50],
	},

	/*helper text*/
	'.MuiFormHelperText-root': {
		...theme.typography.p6,
		marginLeft: 0,
	},

	/*error*/
	'.Mui-error.MuiInputLabel-root': {
		color: theme.palette.black.main,
	},
	'.Mui-error .MuiOutlinedInput-input': {
		borderColor: theme.palette.primary.main,
	},
	'.Mui-error.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
		borderColor: theme.palette.primary.main,
	},
	'.Mui-error.MuiFormHelperText-root': {
		color: theme.palette.primary.main,
	},
}));

const StyledDropdownIcon = styled(DropdownIcon)<DropdownIconProps>(({ theme, ...props }) => ({
	'&': {
		right: theme.spacing(2),
		top: `calc(50% - ${props.size === 'small' ? '4px' : '4px'})`,
	},
}));

function Select({ IconComponent, ...props }: SelectProps) {
	return (
		<StyledSelect IconComponent={(_props) => <StyledDropdownIcon size={props.size} {..._props} />} {...props}>
			{props.children}
		</StyledSelect>
	);
}

export default Select;
