// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useState } from 'react';
import { FormControl, FormControlLabel, InputLabel, InputLabelProps, RadioGroup as MuiRadioGroup, RadioGroupProps, SelectProps, styled } from '@mui/material';
import { useMemo } from 'react';
import Radio from './Radio';
import Label from './Label';
import { Typography } from '@mui/material';

type ReviewFieldProps = {
	label: string;
	value?: string;
	children?: React.ReactNode;
};

const ReviewField = React.forwardRef(({ label, value, children, ...props }: ReviewFieldProps, ref) => {
	return (
		<FormControl>
			<Label>{label}</Label>
			{value && !children && <Typography variant="p4">{value}</Typography>}
			{children && children}
		</FormControl>
	);
});

export default ReviewField;
