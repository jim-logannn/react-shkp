export const SLangTC = 'tchinese';
export const SLangSC = 'schinese';
export const SLangEN = 'english';

export const LocaleTC = 'zh-HK';
export const LocaleEN = 'en-US';
export const LocaleSC = 'zh-CN';

export type Language = typeof SLangTC | typeof SLangEN | typeof SLangSC;
export type Locale = typeof LocaleTC | typeof LocaleEN | typeof LocaleSC;

export const convertLocale = (lang: Locale | Language | string) => {
	switch (lang) {
		case LocaleEN:
		case LocaleTC:
		case LocaleSC:
			return lang;
		case SLangEN:
			return LocaleEN;
		case SLangTC:
			return LocaleTC;
		case SLangSC:
			return LocaleSC;
		default:
			return LocaleEN;
	}
};

export const convertLanguage = (lang: Locale | Language | string) => {
	switch (lang) {
		case SLangEN:
		case SLangTC:
		case SLangSC:
			return lang;
		case LocaleEN:
			return SLangEN;
		case LocaleTC:
			return SLangTC;
		case LocaleSC:
			return SLangSC;
		default:
			return SLangEN;
	}
};
