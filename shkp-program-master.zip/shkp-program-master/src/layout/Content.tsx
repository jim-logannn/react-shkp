// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';

// intl
import styled from 'styled-components';

const StyledContent = styled.div(({ theme }) => ({
	width: '100%',
	background: theme.palette.white.main,
	flex: '1 1 auto',
}));

interface ContentProps {
	children?: React.ReactNode;
}

function Content({ children, ...props }: ContentProps) {
	return <StyledContent {...props}>{children}</StyledContent>;
}

export default Content;
