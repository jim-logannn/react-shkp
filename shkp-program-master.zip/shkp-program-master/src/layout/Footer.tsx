// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';

// intl
import styled from 'styled-components';
import Container from './Container';
import { Typography } from '@mui/material';

const StyledFooter = styled.div(({ theme }) => ({
	display: 'block',
	width: '100%',
	margin: '0 auto',
	paddingTop: theme.spacing(4),
	paddingBottom: theme.spacing(4),
	paddingLeft: theme.spacing(2),
	paddingRight: theme.spacing(2),
	background: theme.palette.grey[20],
}));

const StyledFooterContent = styled.div(({ theme }) => ({
	position: 'sticky',
	bottom: '0',
	width: '100%',
	zIndex: 1,
}));

interface FooterProp {
	id?: string;
	children?: React.ReactNode;
}

function Footer({ children, ...props }: FooterProp) {
	return (
		<>
			<StyledFooter {...props}>
				<Container>
					<Typography variant="p5">©2024 SmarTone Mobile Communications Limited.</Typography>
				</Container>
			</StyledFooter>
			{children ? <StyledFooterContent>{children}</StyledFooterContent> : ''}
		</>
	);
}

export default Footer;
