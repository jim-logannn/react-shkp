// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useContext, useMemo } from 'react';

// intl
import styled from 'styled-components';
import Container from './Container';
import { Typography } from '@mui/material';
import { useTheme } from '@mui/material';
import InfoIcon from './../com/smartone/icon/Info';
import Button from '@smt/formElement/Button';
import { STEP_HOMEPAGE, STEP_SUBMIT, STEP_THANKYOU, Step } from '@/type/Step';
import { STEP_FORM, STEP_REVIEW } from '@/type/Step';
import { ApplyService } from '@/type/Form';
import ApplicationContext, { CHANNEL_CLUBHOUSE, CHANNEL_SELF_HELP, Channel } from '@smt/context/ApplicationContext';

const StyledReviewFooter = styled.div(({ theme }) => ({
	display: 'block',
	width: '100%',
	margin: '0 auto',
	paddingTop: theme.spacing(2),
	paddingBottom: theme.spacing(2),
	paddingLeft: theme.spacing(2),
	paddingRight: theme.spacing(2),
	background: theme.palette.white.main,
	boxShadow: '0px -3px 6px 0px rgba(0,0,0,0.26)',
}));

const StyledReviewFooterContent = styled.div(({ theme }) => ({
	display: 'flex',
	justifyContent: 'flex-end',
	alignItems: 'center',
	gap: theme.spacing(1),
}));

const StyledExtraInfo = styled('div')(({ theme }) => ({
	cursor: 'pointer',
	marginRight: theme.spacing(1),
}));

interface ReviewFooterProp {
	id?: string;
	currentStep: Step;
	buttonStatus: boolean;
	appliedService: ApplyService;
	onChangeStep: (step: Step, currentStep: Step) => void;
	children?: React.ReactNode;
}

function ReviewFooter({ currentStep, buttonStatus, appliedService, onChangeStep, children, ...props }: ReviewFooterProp) {
	const theme = useTheme();
	const applicationContext = useContext(ApplicationContext);
	const channel: Channel = applicationContext?.channel == CHANNEL_CLUBHOUSE ? CHANNEL_CLUBHOUSE : CHANNEL_SELF_HELP;

	const appliedCount = useMemo(() => {
		let count = 0;
		for (const [key, value] of Object.entries(appliedService)) {
			if (value === true) {
				count++;
			}
		}
		return count;
	}, [appliedService]);

	const onClickNextStep = () => {
		if (currentStep == STEP_HOMEPAGE) {
			onChangeStep(STEP_FORM, currentStep);
		}
		if (currentStep == STEP_FORM) {
			onChangeStep(STEP_REVIEW, currentStep);
		}
		if (currentStep == STEP_REVIEW) {
			onChangeStep(STEP_SUBMIT, currentStep);
		}
	};

	const onClickBackStep = () => {
		if (currentStep == STEP_FORM) {
			onChangeStep(STEP_HOMEPAGE, currentStep);
		}
		if (currentStep == STEP_REVIEW) {
			onChangeStep(STEP_FORM, currentStep);
		}
	};

	return (channel == CHANNEL_SELF_HELP && currentStep == STEP_HOMEPAGE) || currentStep == STEP_THANKYOU ? null : (
		<>
			<StyledReviewFooter {...props}>
				<Container>
					<StyledReviewFooterContent>
						{currentStep == STEP_HOMEPAGE && (
							<>
								<Typography variant="h7">已選擇禮遇</Typography>
								<Typography variant="h7" color={theme.palette.primary.main} marginLeft={theme.spacing(1)}>
									{appliedCount} 項
								</Typography>
							</>
						)}
						{currentStep == STEP_FORM && (
							<>
								{channel == CHANNEL_CLUBHOUSE ? null : (
									<>
										<Button fixedWidth={200} onClick={onClickBackStep}>
											back
										</Button>
										<Typography variant="h7">已選擇服務</Typography>
										<Typography variant="h7" color={theme.palette.primary.main} marginLeft={theme.spacing(1)}>
											{appliedCount} 項
										</Typography>
										<StyledExtraInfo>
											<InfoIcon />
										</StyledExtraInfo>
									</>
								)}
							</>
						)}
						{currentStep == STEP_REVIEW && (
							<>
								<Typography variant="p3" onClick={onClickBackStep} marginRight={theme.spacing(2)} style={{ cursor: 'pointer' }}>
									上一頁
								</Typography>
								{/*
								<Button fixedWidth={200} onClick={onClickBackStep}>
									上一頁
								</Button>
								<Typography variant="h7">繳付額</Typography>
								<Typography variant="h7" color={theme.palette.primary.main} marginLeft={theme.spacing(1)}>
									HK$ 0
								</Typography>
								*/}
							</>
						)}

						<Button fixedWidth={200} disabled={!buttonStatus} variant="contained" color="primary" onClick={onClickNextStep}>
							{currentStep == STEP_HOMEPAGE && '領取禮遇'}
							{currentStep == STEP_FORM && '下一步'}
							{currentStep == STEP_REVIEW && '確認'}
						</Button>
					</StyledReviewFooterContent>
				</Container>
			</StyledReviewFooter>
		</>
	);
}

export default ReviewFooter;
