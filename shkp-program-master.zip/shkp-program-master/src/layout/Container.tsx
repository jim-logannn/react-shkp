// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';

// intl
import styled from 'styled-components';

export const StyledContainer = styled.div`
	display: block;
	width: 100%;
	margin: 0 auto;
	max-width: ${(props) => props.theme.breakpoints.values.lg}px;
`;
interface ContainerProp {
	children?: React.ReactNode;
}

function Container({ children, ...props }: ContainerProp) {
	return <StyledContainer {...props}>{children}</StyledContainer>;
}

export default Container;
