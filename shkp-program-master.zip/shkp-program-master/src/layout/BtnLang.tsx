// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { AnchorHTMLAttributes, LinkHTMLAttributes } from 'react';

// intl
import styled from 'styled-components';
import { useIntl } from 'react-intl';

const StyledBtnLang = styled.a(({ theme }) => ({
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center',
	width: 30,
	height: 30,
	color: theme.palette.grey[90],
	borderRadius: '100%',
	border: '1px solid transparent',
	borderColor: theme.palette.grey[60],
	backgroundColor: theme.palette.grey[20],
	textDecoration: 'none',
	...theme.typography.p5,
}));
interface BtnLangProp extends AnchorHTMLAttributes<HTMLAnchorElement> {}

function BtnLang({ ...props }: BtnLangProp) {
	const intl = useIntl();

	return <StyledBtnLang {...props}>{intl.formatMessage({ id: 'btnLang' })}</StyledBtnLang>;
}

export default BtnLang;
