// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useContext } from 'react';

// intl
import styled from 'styled-components';
import Img from '@/components/img/Img';
import { useCallback } from 'react';
import Steppers from '@smt/steppers/Steppers';
import BtnLang from './BtnLang';
import Container from './Container';
import { useIntl } from 'react-intl';
import { Link } from '@mui/material';
import { STEP_FORM, STEP_HOMEPAGE, STEP_REVIEW, STEP_THANKYOU, Step } from '@/type/Step';
import { SLangEN, convertLanguage } from '@smt/type/common';
import ApplicationContext, { CHANNEL_CLUBHOUSE, CHANNEL_SELF_HELP, Channel } from '@smt/context/ApplicationContext';

const StyledHeaderWrapper = styled.header(({ theme, ...props }) => ({
	width: '100%',
	background: '#fff',
	paddingTop: theme.spacing(2),
	paddingBottom: theme.spacing(2),
	paddingLeft: theme.spacing(2),
	paddingRight: theme.spacing(2),
	borderBottom: '1px solid transparent',
	borderColor: theme.palette.grey[60],
}));

const StyledHeader = styled.header(({ theme, ...props }) => ({
	display: 'flex',
	width: '100%',
	'justify-content': 'space-between',
	'align-items': 'center',
	gap: '20px',
}));

const StyledImg = styled(Img)`
	max-width: 135px;
	width: 100%;
`;

interface HeaderProps {
	currentStep: Step;
}

function Header({ currentStep }: HeaderProps) {
	// const applicationContext = useContext(ApplicationContext);
	// const imgPath = applicationContext?.imgPath;
	const intl = useIntl();
	const lang = convertLanguage(intl.locale);
	const langSEO = lang == SLangEN ? 'tc' : 'en';

	const applicationContext = useContext(ApplicationContext);
	const channel: Channel = applicationContext?.channel == CHANNEL_CLUBHOUSE ? CHANNEL_CLUBHOUSE: CHANNEL_SELF_HELP;

	const steps: string[] = [intl.formatMessage({ id: 'header.form' }), intl.formatMessage({ id: 'header.review' })];

	const activeStep = useCallback(
		(step: Step) => {
			if (step == STEP_HOMEPAGE || step == STEP_FORM) {
				return 0;
			} else if (step == STEP_REVIEW) {
				return 1;
			}
			return 0;
		},
		[currentStep],
	);
	const isNeedShowStep = currentStep !== STEP_HOMEPAGE && currentStep !== STEP_THANKYOU;

	return (
		<StyledHeaderWrapper>
			<Container>
				<StyledHeader>
					<Link href="https://www.smartone.com" target="_blank">
						<StyledImg src={'/.resources/common/webresources/assets/images/common/logo_d.svg'} alt="smartone" />
					</Link>
					{isNeedShowStep && <Steppers activeStep={activeStep(currentStep)} steps={steps} />}
					{channel == CHANNEL_CLUBHOUSE ? null : <BtnLang href={"/"+langSEO+"/SHK_SiliconHill/SHKPnewpropertyoffer/"} /> }
				</StyledHeader>
			</Container>
		</StyledHeaderWrapper>
	);
}

export default Header;
