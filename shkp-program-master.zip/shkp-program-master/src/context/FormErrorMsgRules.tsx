import { FormValues } from '@/type/Form';
import { isPhoneNumber, isValidEmail, isValidHkid, isValidPassport } from '@smt/validator/InputValidator';
import { RegisterOptions } from 'react-hook-form';
import { useIntl } from 'react-intl';

function getFormErrorMsg() {
	const intl = useIntl();
	const formErrorMsg = {
		english_last_name: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
			maxLength: {
				value: 40,
				message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 40 }),
			},
		},
		english_first_name: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
			maxLength: {
				value: 40,
				message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 40 }),
			},
		},
		chinese_last_name: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
			maxLength: {
				value: 20,
				message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
			},
		},
		chinese_first_name: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
			maxLength: {
				value: 20,
				message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
			},
		},
		agree_tnc: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		ID_type: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		ID_number: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
			maxLength: {
				value: 20,
				message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
			},
		},
		HKID: {
			validate: {
				isHkid: (value: string) => {
					return isValidHkid(value) || intl.formatMessage({ id: 'form.error.hkid' });
				},
			},
		},
		'Other Passport': {
			validate: {
				isPassport: (value: string) => {
					return isValidPassport(value) || intl.formatMessage({ id: 'form.error.required' });
				},
			},
		},
		'Macau Passport': {
			validate: {
				isPassport: (value: string) => {
					return isValidPassport(value) || intl.formatMessage({ id: 'form.error.required' });
				},
			},
		},
		'Exit-Entry Permit': {
			validate: {
				isPassport: (value: string) => {
					return isValidPassport(value) || intl.formatMessage({ id: 'form.error.required' });
				},
			},
		},
		'Chinese Passport': {
			validate: {
				isPassport: (value: string) => {
					return isValidPassport(value) || intl.formatMessage({ id: 'form.error.required' });
				},
			},
		},
		date_of_birth: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		title: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		contact_number: {
			validate: {
				isPhoneNumber: (value: string) => {
					return isPhoneNumber(value) || intl.formatMessage({ id: 'form.error.required' });
				},
			},
		},
		contact_email: {
			validate: {
				isEmail: (value: string) => {
					return isValidEmail(value) || intl.formatMessage({ id: 'form.error.required' });
				},
			},
		},
		address_block: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		address_floor: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		address_flat: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		img_ID: {
			required: {
				value: true,
				message: intl.formatMessage({ id: 'form.error.required' }),
			},
		},
		mobile_trial: {
			pending_activation_date: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			sim: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
		},
		H5GBB_trial: {
			pending_activation_date: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			sim: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
			main_IMEI: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
			mesh_serial_num: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
		},
		HPP_trial: {
			sim: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
			main_IMEI: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
		},
		FBB_trial: {
			installation_date: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			installation_timeslot: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			installation_contact: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 30,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 30 }),
				},
			},
			installation_contact_number: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
				maxLength: {
					value: 20,
					message: intl.formatMessage({ id: 'form.error.maxLength' }, { length: 20 }),
				},
			},
			activation_date: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
		},
		delivery: {
			address_tower: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			address_flat: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			address_floor: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			address_estate: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			address_street: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			address_district: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			contact: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
			contact_number: {
				required: {
					value: true,
					message: intl.formatMessage({ id: 'form.error.required' }),
				},
			},
		},
	};

	return formErrorMsg;
}

export default getFormErrorMsg;
