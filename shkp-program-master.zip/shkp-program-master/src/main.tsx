// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React from 'react';
import ReactDOM from 'react-dom';

// intl
import messages from '@smt/locale/index.js';
import { IntlProvider } from 'react-intl';

import { ThemeProvider as StyledThemeProvider, DefaultTheme } from 'styled-components';
import { flatten } from 'flat';
import ApplicationContext, { ApplicationContextValue, extendDefaultApplicationContext } from '@smt/context/ApplicationContext';
import { Language, Locale, LocaleEN, convertLocale } from '@smt/type/common';
import { ThemeProvider as MuiThemeProvider, ThemeOptions, createTheme } from '@mui/material/styles';

import App from './page/App';
import deepmerge from 'deepmerge';
import { themeOptionsCommon, themeOptionsTc, themeOptionsEn } from '@smt/theme/theme';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';

interface RenderAppProps {
	lang: Locale | Language;
	container: Element;
	theme?: ThemeOptions;
	applicationContext?: ApplicationContextValue;
}
window.renderReactApp = function ({ lang = LocaleEN, container, theme, applicationContext }: RenderAppProps) {
	const locale = convertLocale(lang);
	const applicationContextValue = applicationContext ? applicationContext : {};
	const themeOptions = locale == LocaleEN ? deepmerge(themeOptionsCommon, themeOptionsEn) : deepmerge(themeOptionsCommon, themeOptionsTc);
	const themeValue = theme ? createTheme(deepmerge(themeOptions, theme)) : createTheme(themeOptions);

	ReactDOM.render(
		<MuiThemeProvider theme={themeValue}>
			<StyledThemeProvider theme={themeValue}>
				<LocalizationProvider dateAdapter={AdapterDayjs}>
					<ApplicationContext.Provider value={extendDefaultApplicationContext(applicationContextValue)}>
						<IntlProvider locale={locale} messages={flatten(messages[locale])} textComponent={React.Fragment}>
							<App />
						</IntlProvider>
					</ApplicationContext.Provider>
				</LocalizationProvider>
			</StyledThemeProvider>
		</MuiThemeProvider>,
		container,
	);
};
declare global {
	interface Window {
		renderReactApp: (props: RenderAppProps) => void;
	}
}
