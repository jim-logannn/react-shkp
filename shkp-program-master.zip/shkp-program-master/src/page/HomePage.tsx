// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useCallback, useContext, useEffect, useMemo, useState } from 'react';

// intl

import Container from '@/layout/Container';
import { styled, useTheme } from 'styled-components';
import { Grid, Theme, Typography, useMediaQuery } from '@mui/material';
import Plancard from '@/components/plancard/Plancard';
import Button from '@smt/formElement/Button';
import { ApplyService } from '@/type/Form';
import Img from '@/components/img/Img';
import { useIntl } from 'react-intl';
import AccordionExpandIcon from '@/components/Accordion/AccordionExpandIcon';
import SimpleAccordionExpand from '@/components/Accordion/SimpleAccordionExpand';
import ApplicationContext, { CHANNEL_CLUBHOUSE, CHANNEL_SELF_HELP, Channel } from '@smt/context/ApplicationContext';
import { SLangEN, convertLanguage } from '@smt/type/common';
import HelpIcon from '@mui/icons-material/Help';
import SimpleDialog from '@/components/Dialog/SimpleDialog';
import TncWrapper from '@/components/TncWrapper/TncWrapper';

interface PageHomeProp {
	onChangeService: (service: ApplyService) => void;
	onFormValidated: (isAllow: boolean) => void;
}
const VERSION = "20240326"
const StyledBannerImage = styled.div(({ theme }) => ({}));

const StyledHeadingContainer = styled.div(({ theme }) => ({
	textAlign: 'center',
}));
const StyledHeader = styled.div(({ theme }) => ({
	paddingBottom: theme.spacing(2),
	...theme.typography.h3,
	[theme.breakpoints.down('md')]: {
		...theme.typography.h5,
	},
}));
const StyledHeaderRed = styled.span(({ theme }) => ({
	color: theme.palette.primary.main,
}));
const StyledDesc = styled.div(({ theme }) => ({
	...theme.typography.p3,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p4,
	},
}));
const StyledPlanCardContainer = styled.div(({ theme }) => ({
	display: 'grid',
	gridGap: theme.spacing(4),
	overflowX: 'auto',
	padding: `${theme.spacing(2)} 20px`,
	margin: '0 -20px',
	//gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
	gridTemplateColumns: 'repeat(auto-fill, minmax(30%, 1fr))',
	[theme.breakpoints.down('md')]: {
		gridTemplateColumns: '90% repeat(auto-fill, minmax(90%, 1fr)) 90%',
		gridGap: '20px',
		padding: '20px',
		margin: 0,
	},
}));

const StyledOfferContainer = styled.div(({ theme }) => ({
	marginTop: theme.spacing(2),
	borderRadius: theme.spacing(2),
	background: theme.palette.grey[20],
	...theme.typography.h9,
	textAlign: 'center',
	a: {
		color: theme.palette.primary.main,
	},
}));
const StyledOfferTitle = styled.div(({ theme }) => ({
	minWidth: '50%',
	margin: '0 auto',
	display: 'inline-block',
	position: 'relative',
	padding: `4px ${theme.spacing(2)}`,
	borderBottomLeftRadius: theme.spacing(2),
	borderBottomRightRadius: theme.spacing(2),
	background: theme.palette.grey[50],
}));
const StyledOfferCellContainer = styled.div(({ theme }) => ({
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center',
}));
const StyledOfferCell = styled.div<{ theme: Theme; width: number }>(({ theme, width }) => ({
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center',
	margin: theme.spacing(2),
	flexFlow: 'column',
	width: `${width}%`,
}));
const StyledOfferCellTitle = styled.div(({ theme }) => ({
	color: theme.palette.grey[80],
	...theme.typography.p4,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
const StyledOfferCellData = styled.div(({ theme }) => ({
	...theme.typography.h9,
	color: theme.palette.grey[80],
}));
const StyledOfferCellDataValue = styled.span(({ theme }) => ({
	color: theme.palette.black.main,
	...theme.typography.h6,
}));
const StyledOfferCellDataText = styled.span(({ theme }) => ({
	color: theme.palette.black.main,
	...theme.typography.h9,
}));
const StyledOfferCellInfo = styled.div(({ theme }) => ({
	color: theme.palette.grey[80],
	...theme.typography.p5,
}));
const StyledOfferList = styled.ul(({ theme }) => ({
	color: theme.palette.grey[80],
	...theme.typography.p4,
	paddingInlineStart: theme.spacing(3),
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
const StyledOfferDesc = styled.div(({ theme }) => ({
	paddingTop: theme.spacing(2),
	color: theme.palette.grey[80],
	...theme.typography.p4,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
const StyledButtonPadding = styled.div(({ theme }) => ({
	paddingTop: theme.spacing(4),
	paddingBottom: theme.spacing(2),
	paddingLeft: theme.spacing(3),
	paddingRight: theme.spacing(3),
	textAlign: 'center',
	opacity: 0,
	...theme.typography.p4,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
const StyledButtonContainer = styled.div(({ theme }) => ({
	position: 'absolute',
	bottom: theme.spacing(3),
	left: '50%',
	transform: 'translate(-50%, 0)',
}));
const StyledLeadInSectionHeader = styled.div(({ theme }) => ({
	marginTop: theme.spacing(10),
	[theme.breakpoints.down('md')]: {
		marginTop: theme.spacing(5),
	},
}));
const StyledPrimarySectionPlan = styled.div(({ theme }) => ({
	marginTop: theme.spacing(15),
	marginBottom: theme.spacing(15),
	[theme.breakpoints.down('md')]: {
		marginTop: theme.spacing(10),
		marginBottom: theme.spacing(10),
	},
}));
const StyledOfferSectionPlan = styled.div(({ theme }) => ({
	margin: `${theme.spacing(3)} -20px 0`,
	background: 'url(/SHKP/Silicon_Hill/images/common/plan_bg.jpg) no-repeat',
	backgroundSize: '100% 90%',
	backgroundPosition: 'center',
	padding: '0 20px',
	[theme.breakpoints.down('md')]: {
		padding: 0,
	},
}));
const StyledOfferTipsDesc = styled.div(({ theme }) => ({
	color: theme.palette.black.main,
	...theme.typography.p4,
	paddingLeft: theme.spacing(2),
	paddingRight: theme.spacing(2),
	textAlign: 'left',
	[theme.breakpoints.down('md')]: {
		...theme.typography.p5,
	},
}));
const StyledOfferTipsContainer = styled.div(({ theme }) => ({
	display: 'flex',
	alignItems: 'center',
}));
const StyledHeaderIcon = styled.img(({ theme }) => ({
	width: '62px',
	paddingBottom: theme.spacing(2),
	[theme.breakpoints.down('md')]: {
		width: '40px',
	},
}));
const StyledOfferTipsIcon = styled.img(({ theme }) => ({
	width: '30px',
	height: '30px',
}));
const StyledOfferTipsArrow = styled.img(({ theme }) => ({
	width: '16px',
	height: '16px',
	flex: '1 0 auto',
}));
const StyledOfferImg = styled.img(({ theme }) => ({
	width: '100%',
	maxWidth: '274px',
	margin: '0 auto',
	display: 'flex',
}));
const StyledHeadingDescContainer = styled.div(({ theme }) => ({
	paddingTop: theme.spacing(2),
}));
const StyledRemarkContainer = styled.div(({ theme }) => ({
	paddingBottom: theme.spacing(4),
}));
const StyledRemarkHeader = styled.div(({ theme }) => ({
	color: theme.palette.black.main,
	...theme.typography.h6,
	textAlign: 'center',
}));
const StyledRemarkContentLi = styled.li(({ theme }) => ({
	...theme.typography.p3,
}));
const StyledRemarkContent = styled.div(({ theme }) => ({
	...theme.typography.p3,
	paddingTop: theme.spacing(2),
}));
const StyledHomeWrapper = styled.div(({ theme }) => ({
	//padding: `0 ${theme.spacing(2)}`,
	padding: '0 20px',
}));

//
function HomePage({ onChangeService, onFormValidated }: PageHomeProp) {
	const theme = useTheme();
	const intl = useIntl();
	const lang = convertLanguage(intl.locale);
	const langSEO = lang == SLangEN ? 'en' : 'tc';
	const isDesktop = useMediaQuery(`${theme.breakpoints.up('md')}`);
	const disable = true;

	const [appliedService, setAppliedService] = useState<ApplyService>({
		mobile: false,
		H5GBB: false,
		FBB: false,
	});

	const [dialog1Open, setDialog1Open] = useState(false);
	const [dialog2Open, setDialog2Open] = useState(false);

	const applicationContext = useContext(ApplicationContext);
	const channel: Channel = applicationContext?.channel == CHANNEL_CLUBHOUSE ? CHANNEL_CLUBHOUSE : CHANNEL_SELF_HELP;
	const callBackFunction = applicationContext?.callback;

	const selectMobileService = () => {
		const service = {
			mobile: appliedService.mobile ? false : true,
			H5GBB: appliedService.H5GBB,
			FBB: appliedService.FBB,
		};
		setAppliedService(service);
	};

	const selectH5GBBService = () => {
		const service = {
			mobile: appliedService.mobile,
			H5GBB: appliedService.H5GBB ? false : true,
			FBB: appliedService.FBB,
		};
		setAppliedService(service);
	};

	const selectFBBService = () => {
		const service = {
			mobile: appliedService.mobile,
			H5GBB: appliedService.H5GBB,
			FBB: appliedService.FBB ? false : true,
		};
		setAppliedService(service);
	};

	const onClickRemark = () => {};

	useEffect(() => {
		if (appliedService) {
			const isValid: boolean = appliedService.mobile || appliedService.H5GBB || appliedService.FBB || false;
			onChangeService(appliedService);
			onFormValidated(isValid);
		}
	}, [appliedService]);

	const onClickWhatsapp = () => {
		if (applicationContext?.callback) {
			applicationContext.callback({ event: 'SiliconWhatsapp' });
		}
	};
	const onClickHotline = () => {
		if (applicationContext?.callback) {
			applicationContext.callback({ event: 'SiliconHotline' });
		}
	};
	//
	//console.log('DEBUG lang|' + lang);

	return (
		<>
			<StyledBannerImage>
				<Img src={'/IMG_V4/Best_Router_Placement_Tips/top_banner/SHKP_Club_New_Estates_Promotion_' + (isDesktop ? '' : 'mob') + langSEO.toUpperCase() + '.jpg'} style={{ width: '100%', maxWidth: 'inherit' }} />
			</StyledBannerImage>
			<StyledHomeWrapper>
				<StyledLeadInSectionHeader>
					<Container>
						<StyledHeadingContainer>
							<StyledHeaderIcon src={'/SHKP/Silicon_Hill/images/common/icon_gift.png'} />
							<StyledHeader>
								{intl.formatMessage({ id: 'homepage.lead-in.header' }, { red: <StyledHeaderRed>{intl.formatMessage({ id: 'homepage.lead-in.header-highlight' })}</StyledHeaderRed> })}
							</StyledHeader>
							<StyledDesc>{intl.formatMessage({ id: 'homepage.lead-in.desc' })}</StyledDesc>
						</StyledHeadingContainer>
					</Container>
				</StyledLeadInSectionHeader>
				<StyledOfferSectionPlan>
					<Container>
						<StyledPlanCardContainer>
							<Plancard>
								<StyledOfferImg src={intl.formatMessage({ id: 'homepage.plan-card.mobile.icon' })} />
								<StyledOfferDesc>{intl.formatMessage({ id: 'homepage.plan-card.mobile.desc' })}</StyledOfferDesc>
								<StyledOfferContainer>
									<StyledOfferTitle>{intl.formatMessage({ id: 'homepage.plan-card.mobile.offer-title' })}</StyledOfferTitle>
									<StyledOfferCellContainer>
										<StyledOfferCell width={50}>
											<StyledOfferCellTitle>{intl.formatMessage({ id: 'homepage.plan-card.mobile.data-title' })}</StyledOfferCellTitle>
											<StyledOfferCellData>
												<StyledOfferCellDataValue>{intl.formatMessage({ id: 'homepage.plan-card.mobile.data-value' })}</StyledOfferCellDataValue>{' '}
												<StyledOfferCellDataText>{intl.formatMessage({ id: 'homepage.plan-card.mobile.data-text' })}</StyledOfferCellDataText>{' '}
												{intl.formatMessage({ id: 'homepage.plan-card.mobile.data-month' })}
											</StyledOfferCellData>
											<StyledOfferCellInfo>{intl.formatMessage({ id: 'homepage.plan-card.mobile.data-info' })}</StyledOfferCellInfo>
										</StyledOfferCell>
										<StyledOfferCell width={50}>
											<StyledOfferCellTitle>{intl.formatMessage({ id: 'homepage.plan-card.mobile.voice-title' })}</StyledOfferCellTitle>
											<StyledOfferCellData>
												<StyledOfferCellDataValue>{intl.formatMessage({ id: 'homepage.plan-card.mobile.voice-value' })}</StyledOfferCellDataValue>{' '}
												<StyledOfferCellDataText>{intl.formatMessage({ id: 'homepage.plan-card.mobile.voice-text' })}</StyledOfferCellDataText>{' '}
												{intl.formatMessage({ id: 'homepage.plan-card.mobile.voice-month' })}
											</StyledOfferCellData>
											<StyledOfferCellInfo>{intl.formatMessage({ id: 'homepage.plan-card.mobile.voice-info' })}</StyledOfferCellInfo>
										</StyledOfferCell>
									</StyledOfferCellContainer>
								</StyledOfferContainer>
								<StyledOfferContainer>
									<StyledOfferTitle>{intl.formatMessage({ id: 'homepage.plan-card.mobile.roaming-title' })}</StyledOfferTitle>
									<StyledOfferCellContainer>
										<StyledOfferCell width={100}>
											<StyledOfferCellData>
												<StyledOfferCellDataValue>{intl.formatMessage({ id: 'homepage.plan-card.mobile.roaming-value' })}</StyledOfferCellDataValue>{' '}
												<StyledOfferCellDataText>{intl.formatMessage({ id: 'homepage.plan-card.mobile.roaming-text' })}</StyledOfferCellDataText>{' '}
												{intl.formatMessage({ id: 'homepage.plan-card.mobile.roaming-month' })}
											</StyledOfferCellData>
											<StyledOfferCellInfo>{intl.formatMessage({ id: 'homepage.plan-card.mobile.roaming-info' })}</StyledOfferCellInfo>
										</StyledOfferCell>
									</StyledOfferCellContainer>
								</StyledOfferContainer>
								{channel == CHANNEL_CLUBHOUSE || disable ? null : (
									<>
										<StyledButtonPadding>{intl.formatMessage({ id: 'homepage.plan-card.select' })}</StyledButtonPadding>
										<StyledButtonContainer>
											<Button
												fixedWidth={200}
												disabled={false}
												variant={appliedService.mobile ? 'contained' : 'outlined'}
												color={appliedService.mobile ? 'success' : 'secondary'}
												onClick={selectMobileService}
											>
												{intl.formatMessage({ id: 'homepage.plan-card.select' })}
											</Button>
										</StyledButtonContainer>
									</>
								)}
							</Plancard>

							<Plancard>
								<StyledOfferImg src={intl.formatMessage({ id: 'homepage.plan-card.h5gbb.icon' })} />
								<HelpIcon
									sx={{ color: theme.palette.grey[60], width: '2.5rem', height: '2.5rem', position: 'absolute', right: '18px', top: '18px', cursor: 'pointer' }}
									onClick={() => setDialog1Open(true)}
								/>
								<StyledOfferList>
									<li>{intl.formatMessage({ id: 'homepage.plan-card.h5gbb.desc-3' })}</li>
									<li>{intl.formatMessage({ id: 'homepage.plan-card.h5gbb.desc-1' })}</li>
									<li>{intl.formatMessage({ id: 'homepage.plan-card.h5gbb.desc-2' })}</li>
								</StyledOfferList>
								<StyledOfferContainer>
									<StyledOfferCellContainer>
										<StyledOfferCell width={100}>
											<StyledOfferTipsContainer>
												<StyledOfferTipsIcon src={'/SHKP/Silicon_Hill/images/common/icon_tips.png'} />
												<StyledOfferTipsDesc>
													{intl.formatMessage(
														{ id: 'homepage.plan-card.h5gbb.tips-desc' },
														{
															link: (
																<a href={intl.formatMessage({ id: 'homepage.plan-card.h5gbb.tips-link' })} target="_blank" style={{ display: 'block' }}>
																	{intl.formatMessage({ id: 'homepage.plan-card.h5gbb.tips-link-text' })}
																</a>
															),
														},
													)}
												</StyledOfferTipsDesc>
											</StyledOfferTipsContainer>
										</StyledOfferCell>
									</StyledOfferCellContainer>
								</StyledOfferContainer>
								{channel == CHANNEL_CLUBHOUSE || disable ? null : (
									<>
										<StyledButtonPadding>{intl.formatMessage({ id: 'homepage.plan-card.select' })}</StyledButtonPadding>
										<StyledButtonContainer>
											<Button
												fixedWidth={200}
												disabled={false}
												variant={appliedService.H5GBB ? 'contained' : 'outlined'}
												color={appliedService.H5GBB ? 'success' : 'secondary'}
												onClick={selectH5GBBService}
											>
												{intl.formatMessage({ id: 'homepage.plan-card.select' })}
											</Button>
										</StyledButtonContainer>
									</>
								)}
							</Plancard>

							<Plancard>
								<StyledOfferImg src={intl.formatMessage({ id: 'homepage.plan-card.fbb.icon' })+"?v="+VERSION} />
								<StyledOfferDesc style={{ opacity: 0 }}>{intl.formatMessage({ id: 'homepage.plan-card.mobile.desc' })}</StyledOfferDesc>
								<HelpIcon
									sx={{ color: theme.palette.grey[60], width: '2.5rem', height: '2.5rem', position: 'absolute', right: '18px', top: '18px', cursor: 'pointer' }}
									onClick={() => setDialog2Open(true)}
								/>
								<StyledOfferContainer>
									<StyledOfferTitle>{intl.formatMessage({ id: 'homepage.plan-card.fbb.data-title' })}</StyledOfferTitle>
									<StyledOfferCellContainer>
										<StyledOfferCell width={100}>
											<StyledOfferCellData>
												<StyledOfferCellDataText>{intl.formatMessage({ id: 'homepage.plan-card.fbb.data-value' })}</StyledOfferCellDataText>
												<StyledOfferCellDataValue>{intl.formatMessage({ id: 'homepage.plan-card.fbb.data-text' })}</StyledOfferCellDataValue>{' '}
												{intl.formatMessage({ id: 'homepage.plan-card.fbb.data-month' })}
											</StyledOfferCellData>
											<StyledOfferCellInfo>{intl.formatMessage({ id: 'homepage.plan-card.fbb.data-info' })}</StyledOfferCellInfo>
										</StyledOfferCell>
									</StyledOfferCellContainer>
								</StyledOfferContainer>
								{channel == CHANNEL_CLUBHOUSE || disable ? null : (
									<>
										<StyledButtonPadding>{intl.formatMessage({ id: 'homepage.plan-card.select' })}</StyledButtonPadding>
										<StyledButtonContainer>
											<Button
												fixedWidth={200}
												disabled={false}
												variant={appliedService.FBB ? 'contained' : 'outlined'}
												color={appliedService.FBB ? 'success' : 'secondary'}
												onClick={selectFBBService}
											>
												{intl.formatMessage({ id: 'homepage.plan-card.select' })}
											</Button>
										</StyledButtonContainer>
									</>
								)}
							</Plancard>
						</StyledPlanCardContainer>
					</Container>
				</StyledOfferSectionPlan>
				<StyledPrimarySectionPlan>
					<Container>
						<StyledHeadingContainer>
							<StyledHeader>
								{intl.formatMessage({ id: 'homepage.exclusive-offer.title' }, { red: <StyledHeaderRed>{intl.formatMessage({ id: 'homepage.exclusive-offer.title-highlight' })}</StyledHeaderRed> })}
							</StyledHeader>
							<StyledDesc>{intl.formatMessage({ id: 'homepage.exclusive-offer.desc' })}</StyledDesc>
							<StyledDesc>{intl.formatMessage({ id: 'homepage.exclusive-offer.desc2' })}</StyledDesc>
						</StyledHeadingContainer>
					</Container>
				</StyledPrimarySectionPlan>
				<StyledPrimarySectionPlan>
					<Container>
						<StyledHeadingContainer>
							<StyledHeader>{intl.formatMessage({ id: 'homepage.pickup.title' }, { red: <StyledHeaderRed>{intl.formatMessage({ id: 'homepage.pickup.title-highlight' })}</StyledHeaderRed> })}</StyledHeader>
							<StyledDesc>{intl.formatMessage({ id: 'homepage.pickup.desc' })}</StyledDesc>
						</StyledHeadingContainer>
						<StyledHeadingDescContainer>
							<Grid sx={{ flexGrow: 1 }} container spacing={0}>
								<Grid item xs={12}>
									<Grid container justifyContent="center" alignItems="center" spacing={2}>
										<Grid item>
											<Img style={{ maxWidth: isDesktop ? '80px' : '60px', width: '100%' }} src="/SHKP/Silicon_Hill/images/common/icon_booth.png" />
										</Grid>
										<Grid item>
											<div>
												<Typography variant={isDesktop ? 'h7' : 'h8'}>{intl.formatMessage({ id: 'homepage.pickup.date-title' })}</Typography>
												<br />
												<Typography variant="h7">{intl.formatMessage({ id: 'homepage.pickup.time-title' })}</Typography>
											</div>
										</Grid>
										<Grid item>
											<div>
												<Typography variant={isDesktop ? 'p3' : 'p4'}>{intl.formatMessage({ id: 'homepage.pickup.date' })}</Typography>
												<br />
												<Typography variant="p3">{intl.formatMessage({ id: 'homepage.pickup.time' })}</Typography>
											</div>
										</Grid>
									</Grid>
								</Grid>
							</Grid>
						</StyledHeadingDescContainer>
					</Container>
				</StyledPrimarySectionPlan>
				<StyledPrimarySectionPlan>
					<Container>
						<StyledHeadingContainer>
							<StyledHeader>{intl.formatMessage({ id: 'homepage.hotline.title' })}</StyledHeader>
							<StyledDesc>{intl.formatMessage({ id: 'homepage.hotline.desc' })}</StyledDesc>
						</StyledHeadingContainer>
						<StyledHeadingDescContainer>
							<Grid container spacing={0}>
								<Grid container justifyContent="center" alignItems="center" spacing={2}>
									<Grid item>
										<Button
											fixedWidth={250}
											startIcon={<Img style={{ maxWidth: '21px', width: '100%' }} src={'/SHKP/Silicon_Hill/images/common/icon_whatsapp.png'} />}
											variant={'contained'}
											color={'green'}
											onClick={onClickWhatsapp}
										>
											{intl.formatMessage({ id: 'homepage.hotline.whatsapp' })}
										</Button>
									</Grid>
									<Grid item>
										<Button fixedWidth={250} variant={isDesktop ? 'outlined' : 'contained'} color={isDesktop ? 'secondary' : 'primary'} onClick={onClickHotline}>
											{intl.formatMessage({ id: 'homepage.hotline.phone' })}
										</Button>
									</Grid>
								</Grid>
							</Grid>
						</StyledHeadingDescContainer>
					</Container>
				</StyledPrimarySectionPlan>
				<StyledPrimarySectionPlan>
					<Container>
						<StyledHeadingContainer>
							<StyledHeader style={{ padding: 0 }}>{intl.formatMessage({ id: 'homepage.faq.title' })}</StyledHeader>
						</StyledHeadingContainer>
						<AccordionExpandIcon index={0} title={intl.formatMessage({ id: 'homepage.faq.question-1' })}>
							{lang == 'tchinese' && (
								<TncWrapper>
									<Typography variant="h9">1) 如何領取入伙禮遇？</Typography>

									<p>住戶可於服務時間內 (星期一至日及公眾假期：上午10時至下午6時) 前往屋苑內的SmarTone服務站領取入伙禮遇或掃描宣傳單張上的QR code 查詢/登記。</p>

									<Typography variant="h9">2) 入伙禮遇的推廣期是什麼時候？</Typography>

									<p>推廣期由即日起至2024年6月30日。</p>

									<Typography variant="h9">3) 每個單位可享多少次優惠？</Typography>

									<p>每個單位只可享各優惠一次。優惠包括免費12個月5G SIM卡連漫遊數據、免費3個月Home 5G寬頻及「家+電話」服務、光纖寛頻免費安裝。</p>

									<Typography variant="h9">4) 我申請了免費試用服務，甚麼時候會收到SIM卡、路由器及「家+電話」？</Typography>

									<p>於服務站登記服務後，會即時收到服務SIM卡、路由器及「家+電話」 (視乎登記服務而定)。</p>

									<Typography variant="h9">5) 我未入伙，最遲可於甚麼日子啟用免費試用服務？</Typography>

									<p>
										客戶須於推廣期內 (2024年6月30日前) 登記服務，服務會於登記後翌日下午6時後啟用。客戶可於使用日期前到屋苑內的SmarTone服務站或掃描宣傳單張上的QR code登記。 Home
										5G寬頻及「家+電話」服務生效後可享3個月免費試用。5G SIM卡連漫遊數據可享12個月免費試用。
									</p>

									<Typography variant="h9">6) 如何退還免費試用服務的租借裝置？</Typography>

									<p>
										客戶須親臨任何 SmarTone門市(按
										<a target="_blank" href="https://www.smartone.com/tc/privileges_and_support/contact_us/store_location.jsp">
											此
										</a>
										)歸還所有租借裝置及完整包裝，包括5G路由器、Mesh 路由器及家居電話 (如適用)連同SIM 卡。
									</p>

									<Typography variant="h9">7) 未能成功兌換優惠，該怎麼辦？</Typography>

									<p>每個單位只可享各優惠一次。請向 SmarTone服務站同事提供有效住戶證或住址證明或收樓信以作身份核實及個案跟進之用。我們的客戶服務員會於稍後時間儘快回覆客人。</p>

									<Typography variant="h9">8) 如何得知有關智能家居和入牆式Wi-Fi 6 無線上網系統的資料？</Typography>

									<p>如住戶對以上服務有任何問題，請參閱收樓日收到的服務說明書。你亦可向屋苑內SmarTone服務站 或 致電2793 6353 查詢。</p>
								</TncWrapper>
							)}
							{lang == 'english' && (
								<TncWrapper>
									<Typography variant="h9">1) How can I apply for the Housewarming Privilege?</Typography>

									<p>
										Residents can visit the SmarTone service station within service hours (Monday to Sunday and public holidays: 10:00 AM to 6:00 PM) to apply for the housewarming privilege or scan
										the QR code on the promotion leaflet for enquiries / registration.
									</p>

									<Typography variant="h9">2) What is the duration of the promotion period?</Typography>

									<p>The promotion period runs from now until June 30, 2024.</p>

									<Typography variant="h9">3) What is the maximum number of offers that each unit can get?</Typography>

									<p>
										Each unit is eligible for each offer only once. The offer includes free 12 months of 5G SIM with roaming data, free 3 months of Home 5G Broadband and HomePhone+ service and fiber
										broadband installation fee waiver.
									</p>

									<Typography variant="h9">4) I&rsquo;ve applied for the free trial service. When will I receive SIM card, router and HomePhone+ device?</Typography>

									<p>After registering the service at the service station, you will receive the service SIM card, router, and HomePhone+ device (subject to the type of service registered).</p>

									<Typography variant="h9">5) I haven&rsquo;t yet moved into the apartment. What is the latest date by which I can activate the free trial services?</Typography>

									<p>
										Customer is required to register for the service during the promotional period (before June 30, 2024). The service will be activated on the day following registration after 6:00
										PM. Customers can either visit the SmarTone service station within the estate or scan the QR code on the promotional leaflet to register before the usage date. Upon activation,
										they can enjoy a 3-month free trial of Home 5G Broadband and HomePhone+ service. And enjoy 12-month free trial of 5G SIM with roaming data.
									</p>

									<Typography variant="h9">6) How do I return the rental devices of the Free Trial Services?</Typography>

									<p>
										Customer is required to return the whole set of device(s) with SIM card and complete packaging, including the 5G router, mesh router and HomePhone+ (if applicable) with SIM card to
										SmarTone&rsquo;s stores (click{' '}
										<a target="_blank" href="https://www.smartone.com/en/privileges_and_support/contact_us/store_location.jsp">
											here
										</a>
										).
									</p>

									<Typography variant="h9">7) In case I am unable to redeem the offer, what should I do?</Typography>

									<p>
										Each unit can only enjoy each offer once. Please provide a valid resident card, address proof or a possession letter to the service station colleagues for identity verification and
										follow up. Our customer service team will respond to you as soon as possible.
									</p>

									<Typography variant="h9">8) How can I obtain information about smart home and in-wall Wi-Fi 6 internet systems?</Typography>

									<p>
										For any inquiries related to the services, please refer to the service manual received on the handover day. You can also visit SmarTone service station or call 2793 6353 for more
										details.
									</p>
								</TncWrapper>
							)}
						</AccordionExpandIcon>
						<AccordionExpandIcon index={1} title={intl.formatMessage({ id: 'homepage.faq.question-2' })}>
							{lang == 'tchinese' && (
								<TncWrapper>
									<Typography variant="h9">1) 免費試用服務的試用期是？</Typography>

									<p>免費試用服務的試用期是啟用日起計為12個月。</p>

									<Typography variant="h9">2) 免費試用服務包括有什麼服務？</Typography>

									<p>客戶可享每月5GB本地數據，每月500本地通話分鐘及每月1GB亞太地區漫遊數據。</p>

									<Typography variant="h9">3) 免費試用服務不用收費嗎？</Typography>

									<p>免費試用服務在試用期期間為月費$0；如客戶於試用期後欲繼續使用此服務， 可以優惠月費$98繼續使用5G無合約月費計劃，並享每月5GB本地數據及每月500本地通話分鐘。</p>

									<Typography variant="h9">4) 免費試用服務可否揀選號碼?</Typography>

									<p>免費試用服務之新號碼將會隨機發放，新號碼可參閱SIM卡背後。</p>

									<Typography variant="h9">5) 如果不想繼續使用免費試用服務，要做什麼？</Typography>

									<p>客戶可於計劃試用期限終止前30日內致電通知本公司取消試用計劃。</p>

									<Typography variant="h9">6) 在試用期間，可以加購增值服務/漫遊服務嗎？</Typography>

									<p>
										客戶可以到門市或CARE App 加購增值服務/漫遊服務，增值服務/ 漫遊服務詳情可參閱：&nbsp;{' '}
										<a target="_blank" href="https://www.smartone.com/tc/home/mobile-service-plans/valueAddedServices#travel">
											https://www.smartone.com/tc/home/mobile-service-plans/valueAddedServices#travel
										</a>
									</p>

									<Typography variant="h9">7) 在試用期間，可增購本地數據嗎？</Typography>

									<p>
										可以。當每月5GB本地數據用完後可增購本地數據 $20/1GB 或 $40/ 5GB，
										並將以「先通知，後購買」收費機制收費。當客戶本地數據每月用量快將用完時，我們會以SMS通知客戶。客戶可回覆SMS確認購買增值數據，增值數據有效期將直至當月截數日。如用戶不購買任何增值數據，當所有每月用量用完時數據服務便會暫停，直至下個賬單月首天。
									</p>

									<Typography variant="h9">8) 如何可以查閱自己的用量詳情？</Typography>

									<p>可以登入CARE App查看每月本地通話分鐘和本地及亞太地區數據用量。</p>

									<Typography variant="h9">9) 本地及亞太地區數據可以累積使用嗎？</Typography>

									<p>客戶可享每月5GB本地數據及每月1GB亞太地區漫遊數據，只限當月使用。如有需要，客戶可以到門市或CARE App 加購其他漫遊數據服務。</p>

									<Typography variant="h9">10) 在試用期內，可以轉台到SmarTone嗎？</Typography>

									<p>試用期內你可以上任何流動電話合約計劃，我們已預留專屬限時上台/轉台優惠，詳情可WhatsApp 6013 2054向SmarTone專員查詢。</p>

									<Typography variant="h9">11) 每月1GB亞太地區漫遊數據適用於哪些地區？</Typography>

									<p>「亞太區漫遊數據組合」適用於指定亞太地區，包括： 內地/澳門、台灣、澳洲、孟加拉、柬埔寨、印尼、日本、馬來西亞、紐西蘭、菲律賓、新加坡、南韓、泰國、越南及支援航空漫遊。</p>

									<Typography variant="h9">12) 當每月1GB亞太地區漫遊數據用完時，我可以繼續使用數據嗎？</Typography>

									<p>
										可以。如客戶身處指定亞太地區時，數據用量超過「亞太區漫遊數據組合」之每月數據用量及(如適用)已購買的「亞太區漫遊數據組合」增值數據用量，其後的漫遊數據將自動以$30/GB收費。當「亞太區漫遊數據組合」客戶身處指定亞太地區以外的海外地區時，當日所使用的數據用量將按客戶所選用的「漫遊數據全日通」收取。
									</p>
								</TncWrapper>
							)}
							{lang == 'english' && (
								<TncWrapper>
									<Typography variant="h9">1) What is the trial period of the free trial service?</Typography>

									<p>The trial period of the free trial service is valid for 12 months after SIM activation.</p>

									<Typography variant="h9">2) What services are included in the free trial service?</Typography>

									<p>Customer can enjoy 5GB local data per month, 500 local voice minutes per month and 1GB APAC roaming data per month during the trial period.</p>

									<Typography variant="h9">3) What is the charge for the 5G free trial service?</Typography>

									<p>
										The free trial service monthly fee is $0 during the trial period. Customer will be charged the original monthly fee of $98 for the 5G No Contract Plan with 5GB local data per month
										and 500 local voice minutes per month if the customer continues to use the service after the trial period.
									</p>

									<Typography variant="h9">4) Can I choose my own number for the 5G free trial service?</Typography>

									<p>The number for the 5G free trial service will be assigned randomly, you can find the new number on the back of the SIM card.</p>

									<Typography variant="h9">5) What should I do if I don&rsquo;t want to continue using the free trial service?</Typography>

									<p>Customer is required to call the Company to cancel the service plan 30 days before the expiration of the trial period.</p>

									<Typography variant="h9">6) Can value-added services be purchased during the trial period?</Typography>

									<p>
										Customers can purchase the value-added services/ roaming services in stores or CARE App; for more details, please visit:{' '}
										<a target="_blank" href="https://www.smartone.com/en/home/mobile-service-plans/valueAddedServices#travel">
											https://www.smartone.com/en/home/mobile-service-plans/valueAddedServices#travel
										</a>
									</p>

									<Typography variant="h9">7) Can I purchase additional local data during the trial period?</Typography>

									<p>
										Yes, a local data top-up fee of $20/1GB or $40/5GB will be charged on an &#39;Advise and Consent&#39; basis. When the local data usage nearly reaches the monthly allowance, an SMS
										notification will be sent to the customer. The customer may purchase top-up data by replying to the SMS, top-up data is valid until the cut-off date of that billing month. If the
										customer does not purchase any top-up data, the data service will be suspended when the monthly allowance is used up, until the beginning of the next billing month.
									</p>

									<Typography variant="h9">8) Can I check my usage records?</Typography>

									<p>You can view your local call, local data and roaming data monthly usage in CARE App.</p>

									<Typography variant="h9">9) Can I carry forward unused local data and APAC roaming data?</Typography>

									<p>
										Customer can enjoy 5GB local data per month and 1GB APAC roaming data per month during the trial period, which can only be used in the current month. Customer can purchase other
										roaming data services in stores or CARE App if necessary.
									</p>

									<Typography variant="h9">10) Can I port in my mobile number during the trial period?</Typography>

									<p>
										We have reserved an exclusive limited-time offer for any contracted mobile service plan subscription during the trial period. For details, please WhatsApp SmarTone staff at 6013
										2054.
									</p>

									<Typography variant="h9">11) Where can I use the 1GB APAC Roaming Data?</Typography>

									<p>
										&quot;APAC Roaming Data Pack&quot; available in designated APAC destinations includes: Mainland / Macau, Taiwan, Australia, Bangladesh, Cambodia, Indonesia, Japan, Malaysia, New
										Zealand, Philippines, Singapore, South Korea, Thailand, Vietnam and In-flight Roaming.
									</p>

									<Typography variant="h9">12) Can I continue to use the roaming data after using up the 1GB monthly roaming data allowance?</Typography>

									<p>
										Yes. When the Customer is within the location of designated APAC destinations and if the Customer&#39;s accumulated &quot;APAC Roaming Data Pack&quot; usage exceeds monthly roaming
										data allowance, any thereafter data usage will be automatically charged at $30 per GB.When the Customer is within the location of any of the overseas destinations other than
										designated APAC destinations, the daily roaming data usage will be charged with the original day plan price of Data Roaming Day Pass subscribed by the customer and according to the
										destination(s).
									</p>
								</TncWrapper>
							)}
						</AccordionExpandIcon>
						<AccordionExpandIcon index={2} title={intl.formatMessage({ id: 'homepage.faq.question-3' })}>
							{lang == 'tchinese' && (
								<TncWrapper>
									<Typography variant="h9">1) 免費試用服務可否使用自己的無線路由器？</Typography>

									<p>我們已為客人提供5G無線路由器，確保帶來最佳的使用體驗。</p>

									<Typography variant="h9">2) 如何使用我的Home 5G寬頻？</Typography>

									<p>
										請參閱Home 5G寬頻快速使用指南 (按
										<a target="_blank" href="https://www.smartone.com/IMG_V4/Best_Router_Placement_Tips/common/SHKP_H5GBB_quick_start_guide_TC.jpg">
											此
										</a>
										)。如要了解路由器最佳擺放位置，請參閱網址
										<a target="_blank" href="https://smartone.com/tc/SHKP/Best_Router_Placement_Tips">
											https://smartone.com/tc/SHKP/Best_Router_Placement_Tips
										</a>{' '}
										。
									</p>

									<Typography variant="h9">3) Mesh路由器應放在哪裡？</Typography>

									<p>
										你可依照5G路由器包裝盒內的說明書設定及配對Mesh 路由器，成功配對後可將Mesh路由器放於家中需要加強Wi-Fi覆蓋的地方使用，例如你可將路由器放於客廳，再把Mesh
										Router放於房間就可以加強全屋Wi-Fi覆蓋。你可掃描5G路由器上的QR code或按
										<a target="_blank" href="https://www.smartone.com/tc/SHKP/Best_Router_Placement_Tips">
											此
										</a>
										參考路由器的最佳擺放位置。
									</p>

									<Typography variant="h9">4) 免費試用服務會否產生額外收費？</Typography>

									<p>不會。你可於服務生效日起計享3個月免費試用。</p>

									<Typography variant="h9">5) 如上網速度慢，可以怎樣處理？</Typography>

									<p>請掃描路由器上的WhatsApp QR code或致電熱線2793 6353，我們將有專人與你跟進。</p>

									<Typography variant="h9">6) 免費試用期後希望繼續使用有關服務，該怎麼辦？</Typography>

									<p>
										我們已為你預留專屬Home 5G寬頻服務優惠，優惠月費只需$118連5G 路由器租用。在試用期內，你可以隨時WhatsApp 6013
										2054了解詳情並登記服務。成功登記優惠月費計劃後，你便可在免費試用期結束後繼續使用服務。
									</p>

									<Typography variant="h9">7) 免費試用期後，如何退還租借裝置？</Typography>

									<p>
										在免費試用期後，客戶須於14日內親臨任何 SmarTone門市歸還所有租借裝置連同完整包裝，包括5G路由器連SIM卡及Mesh
										路由器(如適用)。不歸還租借裝置，或租借裝置於交還時有損壞（如：人為損壞/意外/使用不當等）以致需要維修，本公司將按現行收費向客戶額外收取所有維修費用（詳情
										<a target="_blank" href="https://www.smartone.com/other/tchinese/smartonejetfaq.pdf">
											https://www.smartone.com/other/tchinese/smartonejetfaq.pdf
										</a>
										）。
									</p>

									<Typography variant="h9">8) 客戶實際上網體驗會受哪些因素影響？</Typography>

									<p>
										客戶實際上網體驗會受不同因素影響，如用戶與發射站的相對位置、網站伺服器資源及互聯網流量狀態、用戶數量、用戶所使用之裝置及其他因素。想進一步提升上網體驗，建議擺放路由器在靠近窗口、空曠或較高的位置，以接收更佳的5G訊號。
									</p>

									<Typography variant="h9">9) Wi-Fi 覆蓋會受哪些因素影響？</Typography>

									<p>Wi-Fi覆蓋視乎單位面積、間隔、建築材料及其他外在因素而定。客戶亦可以按需要租用Mesh 路由器，加強全屋Wi-Fi覆蓋。</p>
								</TncWrapper>
							)}
							{lang == 'english' && (
								<TncWrapper>
									<Typography variant="h9">1) Can I use my own router during the free trial period?</Typography>

									<p>We have already provided customers with a 5G wireless router to ensure the best user experience.</p>

									<Typography variant="h9">2) How do I use my Home 5G broadband?</Typography>

									<p>
										For information on setting up your Home 5G broadband, please refer to the Home 5G broadband quick start guide (click{' '}
										<a target="_blank" href="https://www.smartone.com/IMG_V4/Best_Router_Placement_Tips/common/SHKP_H5GBB_quick_start_guide_EN.jpg">
											here
										</a>
										). To learn about the optimal placement of 5G router, please visit{' '}
										<a target="_blank" href="https://smartone.com/en/SHKP/Best_Router_Placement_Tips">
											https://smartone.com/en/SHKP/Best_Router_Placement_Tips
										</a>
									</p>

									<Typography variant="h9">3) Where should I place the Mesh Router?</Typography>

									<p>
										You can follow the instructions in the 5G router packaging to set up and pair the Mesh router. Upon successful pairing, place the Mesh router in areas of your home where you need
										to enhance Wi-Fi coverage. For example, you can place the router in the living room and the Mesh router in a bedroom to improve whole house&rsquo;s Wi-Fi coverage. You can scan the
										QR code on the 5G router or refer to this{' '}
										<a target="_blank" href="https://smartone.com/en/SHKP/Best_Router_Placement_Tips">
											link
										</a>{' '}
										for optimal router placement.
									</p>

									<Typography variant="h9">4) Will the free trial service incur additional charges?</Typography>

									<p>No, you can enjoy 3 months of free trial service starting from the effective date.</p>

									<Typography variant="h9">5) What should I do if the internet speed is slow?</Typography>

									<p>Please scan the WhatsApp QR code on the router or call the hotline at 2793 6353, and our team will help you.</p>

									<Typography variant="h9">6) What should I do if I want to continue using the service after the free trial period?</Typography>

									<p>
										We have reserved an exclusive Home 5G broadband service offer for you. The discounted monthly fee is only $118, including the 5G router rental. During the trial period, you can
										enquire via WhatsApp at 6013 2054 and register for the service anytime. After successfully registering for the discounted monthly plan, you can continue using the service after the
										free trial period.
									</p>

									<Typography variant="h9">7) How do I return the devices after trial period?</Typography>

									<p>
										Customer is required to return the whole set of device(s) with SIM card and full packaging to SmarTone stores no later than 14 days after expiration of the trial period. If the
										Customer fails to return the device(s) or any part thereof is damaged (due to human damage /accident / improper usage) upon return, the Company will charge the Customer a
										maintenance fee at the current rate (Please click{' '}
										<a target="_blank" href="https://www.smartone.com/other/english/smartonejetfaq.pdf">
											https://www.smartone.com/other/english/smartonejetfaq.pdf
										</a>
										).
									</p>

									<Typography variant="h9">8) What are the factors that influence user experience?</Typography>

									<p>
										Internet experience can vary due to factors such as the relative position between the user and the base station, the download server resources and internet traffic conditions, the
										number of users, users&rsquo; devices and other factors that may arise. To enhance the internet experience, it is recommended to place the router by the windows, or in
										unobstructed/higher locations to improve 5G signal reception.
									</p>

									<Typography variant="h9">9) What are the factors that influence user experience on Wi-Fi coverage?</Typography>

									<p>
										Wi-Fi coverage depends on factors such as area &amp; layout of the premises, construction materials, and other extraneous factors. Customer may rent a mesh router to extend home
										Wi-Fi coverage if needed.
									</p>
								</TncWrapper>
							)}
						</AccordionExpandIcon>
						<AccordionExpandIcon index={3} title={intl.formatMessage({ id: 'homepage.faq.question-4' })}>
							{lang == 'tchinese' && (
								<TncWrapper>
									<Typography variant="h9">1) 如果我使用「家+電話」服務，是否仍可繼續使用現有的電話號碼？</Typography>

									<p>
										免費試用服務期只適用於新電話號碼登記。如你需要攜號轉台，請前往屋苑內SmarTone服務站或任何門市登記優惠月費計劃。如果資料齊全，你現有的電話號碼會於最快7日後（早上9時至早上11時）自動轉台，新簽訂之月費計劃亦會於免費試用期後自動生效。
									</p>

									<Typography variant="h9">2) 免費試用服務可否使用自己現有的家居電話？</Typography>

									<p>「家+電話」服務只適用於SmarTone提供的電話設備。</p>

									<Typography variant="h9">3) 此服務支援「平安鐘」服務嗎？</Typography>

									<p>此服務於電力故障情況下將不能運作，並不支援「平安鐘」服務。</p>

									<Typography variant="h9">4) 如何安裝我的家居電話？</Typography>

									<p>只要將 SIM 卡插入我們提供的家居電話，就可使用「家+電話」服務。插電即用，毋須安排師傅上門拉線安裝，十分方便！</p>

									<Typography variant="h9">5) 免費試用期後希望繼續使用有關服務，該怎麼辦？</Typography>

									<p>我們已為你預留專屬「家+電話」服務優惠。在試用期內，你可以隨時WhatsApp 6013 2054了解詳情並登記服務。成功登記優惠月費計劃後，你便可在免費試用期結束後繼續使用服務。</p>

									<Typography variant="h9">6) 免費試用期後，如何退還租借裝置？</Typography>

									<p>
										在免費試用期後，客戶須於14日內親臨任何
										SmarTone門市歸還所有租借裝置連同完整包裝，包括「家+電話」及SIM卡。不歸還租借裝置，或租借裝置於交還時有損壞（如：人為損壞/意外/使用不當等）以致需要維修，本公司將按現行收費向客戶額外收取所有維修費用（i.
										遺失/損壞「家+電話」- $780; ii. 遺失/損壞 USB充電器 - $40; iii. 遺失/損壞 USB 充電火牛 - $40; 遺失/損壞主機電池 - $65）。）
									</p>

									<Typography variant="h9">7) 如何使用各項通話管理服務？</Typography>

									<p>
										請查閱
										<a target="_blank" href="https://www.smartone.com/IMG_V4/Best_Router_Placement_Tips/common/SHKP_HPP_quick_start_guide_TC.jpg">
											快速使用指南
										</a>
										瀏覽各項通話管理服務的使用方法
									</p>

									<Typography variant="h9">8) 我可以於其他地方使用「家+電話」服務嗎？</Typography>

									<p>
										此免費試用服務只適用於Silicon Hill固定家居地址使用。如你於其他地方使用，服務將會自動暫停。如你想於其他地方繼續使用服務，請於免費試用期結束後WhatsApp 6013
										2054聯絡SmarTone專員或親臨門市辦理搬遷服務。
									</p>

									<Typography variant="h9">9) 免費試用服務會否產生額外收費？</Typography>

									<p>除非客戶使用須付費的增值服務，如IDD長途電話服務，則須按使用量支付有關費用。</p>

									<Typography variant="h9">10) 我的電話未能連接，我該怎麼辦？</Typography>

									<p>請檢查「家+電話」服務的SIM卡是否正確插入「家+電話」的SIM卡插槽。你亦可嘗試重新啟動「家+電話」。如仍未能解決問題，請致電服務專線 27936353。</p>
								</TncWrapper>
							)}
							{lang == 'english' && (
								<TncWrapper>
									<Typography variant="h9">1) Can I carry over my existing telephone number to HomePhone+ Service?</Typography>

									<p>
										The free trial service period only applies to new phone number registrations. If you need to port your existing number, please visit the SmarTone service station or any SmarTone
										store to register for the monthly plan. If all the information is complete, your number can be successfully carried over in as early as 7 working days (from 9am to 11am) under
										normal circumstances.
									</p>

									<Typography variant="h9">2) Can I use my own home phone for HomePhone+ service?</Typography>

									<p>HomePhone+ service is only applicable to the designated phone devices provided by SmarTone.</p>

									<Typography variant="h9">3) Does HomePhone+ service support Care-on-Call service?</Typography>

									<p>HomePhone+ service cannot function during any power failure and does not support Care-on-Call service or devices with medical alert system.</p>

									<Typography variant="h9">4) How do I install my HomePhone+?</Typography>

									<p>Please insert the SIM card into the home phone. It&#39;s a simple plug-and-play process, eliminating installation time.</p>

									<Typography variant="h9">5) What should I do if I want to continue using the service after the free trial period?</Typography>

									<p>
										We’ve reserved an exclusive offer for you on the “Home Phone” service. During the trial period, you can enquire via WhatsApp at 6013 2054 and register for the service anytime.
										After successfully registering for the discounted monthly plan, you can continue using the service after the free trial period.
									</p>

									<Typography variant="h9">6) How to return the devices after trial period?</Typography>

									<p>
										Customer is required to return the whole set of device(s) with SIM card and full packaging to SmarTone stores no later than 14 days after expiration of the trial period. The
										customer must return the device(s) to the company in the same condition as when it was delivered to the customer, except for normal wear and tear. If the customer fails to return
										the Device or any part thereof is damaged (due to human-damage /accident / improper usage) upon return, the Company will charge the customer a maintenance fee at the current rate
										(i. Loss/ Damage of HomePhone+ Main unit - HK$780; ii. Loss/ Damage of Charging Cradle - HK$40; iii. Loss/ Damage of USB Charger - HK$40; Loss/ Damage of Li-ion Battery - HK$65).
									</p>

									<Typography variant="h9">7) How to use the call management services?</Typography>

									<p>
										Please refer to the{' '}
										<a target="_blank" href="https://www.smartone.com/IMG_V4/Best_Router_Placement_Tips/common/SHKP_HPP_quick_start_guide_EN.jpg">
											Quick Start Guide
										</a>{' '}
										for details.
									</p>

									<Typography variant="h9">8) Can I use the Home Phone service elsewhere?</Typography>

									<p>
										This free trial service is only applicable to designated Silicon Hill home addresses. If you use the service elsewhere, the free trial service will be automatically suspended. If
										you wish to continue using the service elsewhere by subscribing to a monthly plan, contact SmarTone via WhatsApp at 6013 2054 or visit a store after the free trial period.
									</p>

									<Typography variant="h9">9) Will the free trial service incur additional charges?</Typography>

									<p>Unless you use value-added services that require payment, such as IDD calls, there won&rsquo;t be any additional fees.</p>

									<Typography variant="h9">10) My HomePhone+ cannot be connected, what should I do?</Typography>

									<p>
										Please check if the HomePhone+ Service&rsquo;s SIM card has been inserted into the SIM card slot of the device. You can also try restarting the HomePhone+. If the problem persists,
										please call our service hotline 27936353.
									</p>
								</TncWrapper>
							)}
						</AccordionExpandIcon>
						<AccordionExpandIcon index={4} title={intl.formatMessage({ id: 'homepage.faq.question-5' })}>
							{lang == 'tchinese' && (
								<TncWrapper>
									<Typography variant="h9">1) 甚麼時候可安裝光纖寬頻？</Typography>

									<p>根據你的需要，我們可以安排於星期一至星期日 (時間:11:00 &ndash; 22:00) 安裝，但需視乎安裝團隊的人手安排。若計劃合適，我們會即時為你查看安裝時間及預約安裝。</p>

									<Typography variant="h9">2) 我正在使用你們的光纖寬頻，可以搬遷到Silicon Hill使用嗎？</Typography>

									<p>可以，我們會視乎網絡覆蓋收取相關搬遷費，另需要按新地址 (Silicon Hill) 之當時的服務計劃重新簽訂銷售及服務合約。</p>

									<Typography variant="h9">3) 如何更改安裝時間?</Typography>

									<p>如需更改安裝時間，請於安裝前最少一個工作天致電客戶服務專線2793 6353通知我們。</p>

									<Typography variant="h9">4) 我知道單位內有入牆式Wi-Fi 6 無線上網，師傅是否會幫手安裝？</Typography>

									<p>師傅會於完成光纖寬頻安裝及測試後，幫忙將光纖網絡終端機連接Wi-Fi 6 無線上網終端機。</p>

									<Typography variant="h9">5) 如對光纖寬頻有疑問，該怎麼辦？</Typography>

									<p>你可以隨時致電客戶服務專線2793 6353或透過WhatsApp 9680 7632查詢。</p>
								</TncWrapper>
							)}
							{lang == 'english' && (
								<TncWrapper>
									<Typography variant="h9">1) When can the installation be scheduled?</Typography>

									<p>
										We can schedule the installation any day of the week from Monday to Sunday (time: 11:00 &ndash; 22:00) based on your requirements. However, it will be subjected to the availability
										of our technical team. If the plan is suitable, we can check the available installation timeslots and make a reservation accordingly.
									</p>

									<Typography variant="h9">2) I am currently using your optical fiber broadband. Can I transfer it to Silicon Hill?</Typography>

									<p>
										Yes, we will charge a relocation fee depending on the network coverage, and you have to sign a new Sales and Services Agreement at the prevailing service plan price for the new
										address (Silicon Hill).
									</p>

									<Typography variant="h9">3) How do I reschedule the installation time?</Typography>

									<p>If you wish to reschedule the installation time, please notify us at our service hotline 2793 6353 at least one working day in advance.</p>

									<Typography variant="h9">4) There is an in-wall Wi-Fi 6 network service in the unit. Will the technician assist with the installation during the fiber broadband setup?</Typography>

									<p>Our technician will help to connect the Optical Network Terminals with Wi-Fi 6 Router after completing the installation of Fibre Broadband service and performance testing.</p>

									<Typography variant="h9">5) What should I do if I encounter issues with the fiber broadband?</Typography>

									<p>You can contact our customer service hotline at 2793 6353 or enquire via WhatsApp at 9680 7632 anytime.</p>
								</TncWrapper>
							)}
						</AccordionExpandIcon>
					</Container>
				</StyledPrimarySectionPlan>
				<StyledPrimarySectionPlan>
					<Container>
						<SimpleAccordionExpand index={0} title={intl.formatMessage({ id: 'homepage.terms.title' })}>
							{lang == 'tchinese' && (
								<TncWrapper>
									<p>
										「SmarTone 5G於Silicon Hill室內室外接收最強」基於SmarTone於2024年第一季進行之測試结果，相比3間電訊商的5G覆蓋，測試包括Silicon
										Hill內主要街道、行車路徑、住宅單位、會所、停車場及升降機。5G覆蓋定義為訊號接收強度不小於-85dBm。
									</p>

									<p>「消費者No.1首選5G 網絡」 基於SmarTone 委託NuanceTree市場研究公司於2022年1月至12月透過網上及街頭訪問3,942位後付流動服務用戶之調查結果。</p>

									<p>「全港覆蓋至廣」基於本公司於2023年7月21日進行之路測結果。路測包括全港主要公路、幹線、行車隧道及行車天橋。5G覆蓋定義為訊號接收強度不小於-95dBm。</p>

									<p>
										「No.1港鐵5G網絡」基於本公司於2022年4月進行之網速測試結果。與本港其他3間5G服務供應商比較，統計90個港鐵車站的5G下載速度，SmarTone 擁有最多下載速度最快的港鐵車站。有關測試以Samsung
										Galaxy S20 或 iPhone 12手機，於繁忙時間 (18:00-19:30) 進行，測試結果是在車站月台上的三次測試平均數值。
									</p>

									<p>
										「人均頻譜資源全港最多」SmarTone及本港其他3間5G服務供應商之客戶數目是參考2021
										年6月25日所發佈之新聞稿，以及6月30日所發佈之最新業績報告。人均可用頻譜是根據各網絡商頻譜總量除以客戶總數而得。
									</p>

									<p>「全港最多低頻段頻譜」2022年6月30日後，SmarTone 共擁有45 MHz低於1GHz的低頻段頻譜，本港其他3間網絡供應商只擁有40 MHz或以下低於1GHz的低頻段頻譜。</p>

									<Typography variant="h9">一般條款及細則</Typography>

									<ul>
										<li>優惠推廣期為即日起至另行通知，詳情請參閱入伙禮遇邀請卡。</li>
										<li>此優惠只適用於指定新地住宅物業單位，每個單位只可享各優惠一次。</li>
										<li>客戶須於推廣期內於屋苑內SmarTone服務站兌換優惠。</li>
										<li>此優惠不能兌換現金、其他產品、服務、折扣或優惠，亦不可轉讓予其他人及不可與其他推廣優惠、折扣或優惠券同時使用。</li>
										<li>本公司保留對優惠及任何爭議之最終決定權，並可更改優惠之條款及細則而不作另行通知。</li>
									</ul>

									<Typography variant="h9">5G流動電話數據SIM卡免費試用服務:</Typography>

									<ul>
										<li>優惠只適用新流動電話號碼，並不適用於攜號轉台之流動電話號碼。</li>
										<li>
											5G 試用計劃原價月費$0，可於試用期限內(啟用日起計為12個月)享每月5GB本地數據，每月500本地通話分鐘及每月1GB亞太地區漫遊數據。客戶須於計劃試用期限終止前30日內致電指定熱線 2793
											6353通知本公司取消試用計劃，如客戶於試用期後繼續使用此服務，本公司將按照5G無合約月費計劃原價月費$98收費，可享每月5GB本地數據及每月500本地通話分鐘。
										</li>
										<li>
											增購本地數據 $20/1GB 或 $40/ 5GB
											將以「先通知，後購買」收費機制收費。當客戶本地數據每月用量快將用完時，我們會以SMS通知客戶。客戶可回覆SMS確認購買增值數據，增值數據有效期將直至當月截數日。如用戶不購買任何增值數據，當所有每月用量用完時數據服務便會暫停，直至下個賬單月首天。
										</li>
										<li>客戶須在登記5G 試用計劃後翌日啟用服務。</li>
										<li>本公司保留對優惠及任何爭議之最終決定權，並可更改此優惠之條款及細則而不作另行通知</li>
										<li>
											優惠及服務受有關條款及細則約束。詳情請參閱
											<a target="_blank" href="https://www.smartone.com/other/tchinese/tc_T376_c.pdf">
												T&amp;C-T376
											</a>
											。
										</li>
										<li>
											「亞太區漫遊數據組合」:
											<ol>
												<li>客戶選用「亞太區漫遊數據組合」，每月此服務計劃數據用量可共用於指定亞太地區。</li>
												<li>指定亞太地區包括: 內地/澳門、台灣、澳洲、孟加拉、柬埔寨、印尼、日本、馬來西亞、紐西蘭、菲律賓、新加坡、南韓、泰國及越南。</li>
												<li>客戶選用 「亞太區漫遊數據組合」，須同時啟動「漫遊數據全日通」。</li>
												<li>外遊前請確保你的帳戶已開啟漫遊服務。</li>
												<li>於指定亞太地區外遊時請開啟手機設定上的數據漫遊以享用「亞太區漫遊數據組合」。</li>
												<li>
													當「亞太區漫遊數據組合」客戶身處指定亞太地區時，如數據用量超過「亞太區漫遊數據組合」之每月數據用量，後續所產生的數據漫遊用量數據服務將按SMS 通知所列明的收費自動收取。
												</li>
												<li>當「亞太區漫遊數據組合」客戶身處指定亞太地區時，「漫遊數據全日通」或「漫遊數據多日通」將不能被使用。</li>
												<li>
													當「亞太區漫遊數據組合」客戶身處指定亞太地區以外的海外地區時，當日所使用的數據用量將按客戶所選用的「漫遊數據全日通」收取。有關「漫遊數據全日通」之詳情、費用、條款及細則請瀏覽{' '}
													<a target="_blank" href="http://smartone.com/other/tchinese/tc_I025_c.pdf">
														smartone.com/T&amp;CI025C
													</a>{' '}
													。
												</li>
												<li>
													根據客戶有關之服務計劃，如客戶之「亞太區漫遊數據組合」數據用量快將達到指定指定數據用量 ，本公司會發出 SMS 通知客戶。後續所產生的數據漫遊用量將會以$30/GB的收費自動收取。
												</li>
												<li>若「亞太區漫遊數據組合」之每月數據用量及已購買增值數據用量仍有餘額，未使用的數據用量會在結算月底自動取消。</li>
												<li>
													航空漫遊只適用於指定航班，有關詳情請瀏覽
													<a target="_blank" href="https://www.aeromobile.net/airlines/">
														https://www.aeromobile.net/airlines/
													</a>
													。
												</li>
												<li>
													(如適用) 當客人已選用其他漫遊數據服務，扣除漫遊數據用量先後次序如下:
													<ol>
														<li>指定之「內地及澳門漫遊數據組合」之漫遊數據用量；</li>
														<li>「亞太地區漫遊數據通」-漫遊數據用量；</li>
														<li>「漫遊數據靈活通」亞太地區之漫遊數據用量；</li>
														<li>「環球地區漫遊數據通」漫遊數據用量；</li>
														<li>「漫遊數據靈活通」環球地區之漫遊數據用量；</li>
														<li>「亞太區漫遊數據組合」-漫遊數據用量；</li>
														<li>&nbsp;漫遊數據多日通 / 漫遊數據全日通 (以日數計算)；</li>
													</ol>
												</li>
												<li>「亞太區漫遊數據組合」服務計劃只限指定服務計劃同時申請，有關指定服務計劃將不時變更而毋須作事先通知。</li>
												<li>
													另受有關條款及細則約束。詳情請參閱
													<a target="_blank" href="https://www.smartone.com/other/tchinese/tc_I050_c.pdf">
														T&amp;C-I050
													</a>{' '}
													。
												</li>
											</ol>
										</li>
									</ul>

									<Typography variant="h9">購買指定手機優惠折扣:</Typography>

									<ul>
										<li>客戶可於即日起至2024年5月31日憑5G 試用SIM卡套以優惠折扣購買指定手機一部。</li>
										<li>優惠只適用於門市。</li>
										<li>客戶憑每個5G 試用SIM卡套只可享優惠一次。</li>
										<li>此優惠不可兌換其他商品或現金。</li>
										<li>優惠視乎供應情況而定，名額有限，先到先得，售完即止，並不會預先另行通知。</li>
										<li>優惠受條款及細則約束，詳情請向店員查詢。</li>
										<li>如有任何爭論，本公司擁最終決定權。</li>
									</ul>

									<Typography variant="h9">Home 5G寬頻免費3個月:</Typography>

									<ul>
										<li>客戶須在登記Home 5G寬頻免費試用服務後翌日啟用服務，並可於服務生效日期起計免費試用Home 5G 寬頻服務連指定5G 寬頻裝置3個月。</li>
										<li>
											Home 5G寬頻免費試用服務計劃月費乃根據 Home 5G寬頻原價月費HK$238及指定5G寬頻裝置租借原價月費HK$65 (5G路由器) / HK$93 (5G 路由器連Mesh 路由器)
											，於3個月合約期內扣除指定月費回贈HK$238及 HK$65 / HK$93計算。客戶於免費試用期內終止合約，適用之優惠亦會同時於沒有任何補償的情況下終止。
										</li>
										<li>此服務計劃之 SIM 卡並不提供通話及漫遊服務，並只適用於配合指定&nbsp; Home 5G 寬頻路由器使用。</li>
										<li>
											此服務計劃包括無限5G數據。FUP（公平使用政策）適用，詳情瀏覽
											<a target="_blank" href="https://www.smartone.com/other/tchinese/TC_WB007A.pdf">
												T&amp;C WB007A
											</a>
										</li>
										<li>客戶可於服務期内享有免費維修租借設備，如因指定情況（人為損壞/意外/使用不當）以致需要維修例外，本公司將按現行費率向客戶額外收取本條項下的所有維修費用。</li>
										<li>免費試用期限屆滿後，服務會被自動終止。如客戶繼續使用此服務，請WhatsApp 6013 2054 聯絡SmarTone專員。</li>
										<li>
											在服務終止後，客戶須並於十四（14）日內親臨任何一間SmarTone門市歸還所有Home 5G寬頻租借裝置連SIM卡及完整包裝。客戶須自行承擔風險及費用將Home 5G寬頻租借設備按交付予客戶之
											時的相同狀況交還本公司，但正常損耗除外。不歸還Home 5G寬頻租借裝置，或Home
											5G寬頻租借裝置於交還時有損壞（人為損壞/意外/使用不當等）以致需要維修，本公司將按現行收費向客戶額外收取所有維修費用，詳情請參閱{' '}
											<a target="_blank" href="https://www.smartone.com/other/tchinese/smartonejetfaq.pdf">
												https://www.smartone.com/other/tchinese/smartonejetfaq.pdf
											</a>{' '}
											。
										</li>
										<li>
											客戶實際上網體驗會受不同因素影響，如用戶與發射站的 相對位置、 網站伺服器資源及互聯網流量狀態、用戶數量、用戶所使用之裝置及其他因素而有所影 響。裝置提供之 Wi-Fi
											覆蓋視乎單位面積、間隔、建築材料及其他外在因素而定。
										</li>
										<li>本公司保留對優惠及任何爭議之最終決定權，並可更改優惠之條款及細則而不作另行通知。</li>
									</ul>

									<Typography variant="h9">家+電話免費3個月:</Typography>

									<ul>
										<li>客戶須在登記家+電話免費試用服務後翌日啟用服務，並可於服務生效日期起計免費試用家+電話服務連指定電話設備3個月。</li>
										<li>優惠只適用本公司分配的新家居電話號碼，並不適用於攜號轉台之家居電話號碼。</li>
										<li>家+電話服務只適用於指定電話設備，及未有支援平安鐘服務。</li>
										<li>家+電話服務只適用於指定住宅地區之客戶。</li>
										<li>此免費試用服務計劃月費乃根據家+電話原價月費HK$68，於3個月合約期內扣除指定月費回贈HK$68計算。客戶於免費試用期內終止合約，適用之優惠亦會同時於沒有任何補償的情況下終止。</li>
										<li>
											此服務計劃包括須付費的IDD長途電話服務及其他增值服務，客戶須按使用量/按月支付有關費用。IDD長途電話服務詳情請按&nbsp;
											<a target="_blank" href="https://www.smartone.com/tc/mobile_and_price_plans/roaming_idd/idd/001idd.jsp">
												001 IDD
											</a>
											&nbsp;及&nbsp;
											<a target="_blank" href="https://www.smartone.com/tc/mobile_and_price_plans/roaming_idd/idd/1638idd.jsp">
												1638 IDD
											</a>
											。
										</li>
										<li>免費試用期限屆滿後，服務會被自動終止。如客戶繼續使用此服務，請WhatsApp 6013 2054 聯絡SmarTone專員。</li>
										<li>
											在服務終止後，客戶須於十四（14）日內親臨任何一間SmarTone 門市歸還所有家+電話租借裝置連SIM卡及完整包裝。客戶須自行承擔風險及費用將家+電話租借設備按交付予客戶之
											時的相同狀況交還本公司，但正常損耗除外。不歸還家+電話租借裝置，或家+電話租借裝置於交還時有損壞（如：人為損壞/意外/使用不當等）以致需要維修，本公司將按現行收費向客戶額外收取所有維修費用
											(i. 遺失/損壞家+電話 - HK$780; ii. 遺失/損壞 USB充電器 - HK$40; iii. 遺失/損壞 USB 充電火牛 - HK$40; 遺失/損壞主機電池 - HK$65)。
										</li>
										<li>
											另受有關條款及細則約束。詳情請參閱
											<a target="_blank" href="https://www.smartone.com/other/tchinese/TCH01.pdf">
												T&amp;C-H01
											</a>
											。
										</li>
									</ul>

									<Typography variant="h9">光纖寛頻服務</Typography>

									<ul>
										<li>
											寬頻速度制式:
											家居光纖1000表示連線到本地網站之上/下載速度最高分別可達1000Mbps，頻寬速度乃是由客戶單位之牆身插座至本公司第一台網絡器材之連線規格。客戶實際可享用之速度或會受客戶之軟件硬件、路由器規格、網站負載、連線內容及其他環境因素所影響而低於以上速度。連線到海外網站之速度除受以上之因素影響外，亦或會因當地網絡而低於本地可得之速度。
										</li>
										<li>優惠只適用於指定住宅地址成功申請光纖寬頻服務計劃並於申請日起計45天內完成安裝之客戶，須簽約指定合約期限。</li>
										<li>光纖寬頻月費回贈將於此計劃的合約期內按月分期回贈客戶。</li>
										<li>首次基本安裝費可獲豁免，如客戶於指定合約期內，不論任何原因終止本服務，本公司將保留收取其訂定之基本安裝費的權利。</li>
										<li>客戶須以現金 (免按金) 作為付款方式。</li>
										<li>期限合約屆滿後，如客戶繼續使用此服務，本公司將按照當時同等服務計劃之月費收費。</li>
										<li>不論任何原因，所有回贈不能轉讓他人、兌換現金、找贖或退款。</li>
										<li>若客戶於合約期限內要求搬遷到仍得到本公司網絡覆蓋的另一新住宅地址，客戶必須按新地址之當時的服務計劃重新簽訂銷售及服務合約。另本公司會視乎網絡覆蓋收取相關搬遷費。</li>
										<li>
											於終止服務後的 14 天內，客戶必須親臨任何一間 SmarTone 門市歸還所有租用設備。若客戶不歸還設備，或設備已遺失或損壞，客戶須支付 (i) HK$1,500 每個光纖網絡終端機 及/或 (ii) HK$100
											每個變壓器；或(iii)按照本公司不時訂定之收費費用。(適用於家居寬頻200或部分家居寬頻100服務計劃) 若客戶不歸還設備，或設備已遺失或損壞，客戶須支付 (i) HK$500 寬頻網絡終端機 及/或
											(ii) HK$100 變壓器；或(ⅲ) 按照本公司不時訂定之收費費用。
										</li>
										<li>若客戶於服務生效日起計12個月內終止服務，將要支付HK$680手續費及指定算定損害賠償。</li>
										<li>SmarTone 保留對優惠及任何爭議之最終決定權，並可更改優惠之條款及細則而不作另行通知。</li>
										<li>
											受有關條款及細則約束。詳情請參閱銷售及服務合約及
											<a target="_blank" href="https://www.smartone.com/other/tchinese/TC_N003DB_c.pdf">
												T&amp;C-N003DB
											</a>
											。
										</li>
									</ul>
								</TncWrapper>
							)}
							{lang == 'english' && (
								<TncWrapper>
									<p>
										&quot;SmarTone 5G is the best indoor and outdoor network in Silicon Hill&quot; is based on results obtained from SmarTone&#39;s test conducted in Q1 2024 compared to Hong
										Kong&rsquo;s 3 other 5G service providers. The route of the road test covers the main walkways, roads, residential units, clubhouses, carparks and elevators within Silicon Hill. 5G
										coverage is defined as spot with received 5G radio signal level not weaker than -85dBm.
									</p>

									<p>
										&ldquo;Consumers&rsquo; No.1 Best Preferred 5G Network&rdquo; Based on results obtained from study conducted by market research company NuanceTree, as commissioned by SmarTone.
										3,942 post-paid SIM card users were interviewed via online survey and street interviews between January and December 2022.
									</p>

									<p>
										&nbsp;&ldquo;The Widest Coverage in HK&rdquo; is based on results obtained from SmarTone&#39;s road test conducted on 21 July 2023. The route of the road test covers major roads
										including expressways, trunk roads, tunnels and bridges. 5G coverage is defined as spot with received 5G radio signal level not weaker than -95dBm.
									</p>

									<p>
										&ldquo;No.1 MTR 5G Network&rdquo; is based on results obtained from SmarTone&rsquo;s network speed test conducted in Apr 2022.&nbsp; SmarTone compared 5G download speed in 90 MTR
										stations with Hong Kong&rsquo;s 3 other 5G service providers and result found that SmarTone has the best network in terms of the numbers of stations having faster download speed
										when compared to the 3 other 5G service providers. The test&nbsp;used Samsung Galaxy S20 or iPhone 12 and was conducted&nbsp;during busy hours (18:00 &ndash; 19:30) . The test
										result is based on the average figures of 3 times test at the station.
									</p>

									<p>
										&ldquo;Most Spectrum Resources per Customer in HK&rdquo; The customer number of SmarTone and Hong Kong&rsquo;s 3 other 5G service providers are obtained from press release dated 25
										June and latest performance reports dated 30 June 2021. Spectrum per customer is calculated by dividing available spectrum to each network provider by their number of customers.
									</p>

									<p>
										&ldquo;The Most Low-band Spectrums in HK&rdquo; After 30 June 2022, SmarTone has 45MHz of sub-1 GHz spectrum. The other 3 network service providers in Hong Kong only have 40MHz or
										less of sub-1 GHz spectrum.
									</p>

									<Typography variant="h9">General Terms &amp; Conditions:</Typography>

									<ul>
										<li>The promotional period for the offers are from now until further notice. Please refer to the Housewarming Privilege Invitation Card for details (“Promotional Period”).</li>
										<li>The offers are only applicable to units of designated SHKP residential properties. Each eligible unit can enjoy the offers once.</li>
										<li>Each customer can only redeem the offers through SmarTone service booth at the property during Promotion Period.</li>
										<li>
											Offers cannot be exchanged for cash, other products, services, discounts or other offers, nor be transferred or used in conjunction with other special promotions, discounts or
											promotional coupons.
										</li>
										<li>Our Company reserves the right of final decision relating to the promotions and any dispute thereof, and may change the terms and conditions without prior notice.</li>
									</ul>

									<Typography variant="h9">5G Mobile Phone Data SIM Card Free Trial Service:</Typography>

									<ul>
										<li>The offer is only applicable to new mobile number and is not applicable to mobile number ported-in from other operators.</li>
										<li>
											Customer can enjoy 5GB local data per month, 500 local voice minutes per month and 1GB APAC roaming data per month at $0 monthly fee during the trial period (valid for 12
											months after SIM activation). Customer is required to call the Company the designated hotline 2793 6353 to cancel the services plan 30 days before the expiry of the trial
											period. The customer will be charged at the original monthly fee $98 of 5G No Contract Plan with 5GB local data per month and 500 local voice minutes per month if the customer
											continues to use the service after the expiry of free trial period.
										</li>
										<li>
											Local data top-up fee $20/1GB or $40/5GB will be charged on &#39;Advise and Consent&#39; basis. When the local data usage nearly reaches the monthly allowance, a SMS
											notification will be sent to the customer. The customer may purchase top-up data by replying to the SMS, top-up data is valid until the cut-off date of that bill month. If the
											customer does not purchase any top-up data, the data service will be suspended when the monthly allowance is used up, until the beginning of the next bill month.
										</li>
										<li>Customer is required to activate the services plan the day after the registration of 5G Free Trial SIM.</li>
										<li>The Company reserves the right of final decision relating to the promotions and any dispute thereof, and may change the terms and conditions without prior notice.</li>
										<li>
											Subject to relevant terms and conditions. Please refer to{' '}
											<a target="_blank" href="https://www.smartone.com/other/english/tc_T376_e.pdf">
												T&amp;C-T376
											</a>{' '}
											for details.
										</li>
										<li>
											For 1GB/month APAC Roaming Data Pack (&ldquo;APAC Roaming Data Pack&rdquo;):
											<ol>
												<li>
													On subscription of the &quot;APAC Roaming Data Pack&quot;, monthly data allowance and top-up purchased under the &quot;APAC Roaming Data Pack&quot; can be shared in
													designated APAC destinations.
												</li>
												<li>
													The designated APAC destinations include Mainland / Macau, Taiwan, Australia, Bangladesh, Cambodia, Indonesia, Japan, Malaysia, New Zealand, Philippines, Singapore,
													South Korea, Thailand and Vietnam.
												</li>
												<li>The Customer who subscribes &quot;APAC Roaming Data Pack&quot; should also activate &quot;Data Roaming Day Pass&quot; at the same time.</li>
												<li>Before traveling abroad, please ensure roaming service is enabled on your account.</li>
												<li>
													To use the APAC Roaming Data Pack when travelling in designated APAC destinations, the Customer should turn on data roaming via &#39;Settings&#39; on his/her
													phone.&nbsp;
												</li>
												<li>
													When the Customer is within the location of designated APAC destinations and if the Customer&rsquo;s accumulated data usage exceeds the monthly data allowance, any
													subsequent data roaming usage will be automatically charged at the rates specified in the SMS notification.
												</li>
												<li>
													When the Customer is within the location of designated APAC destinations, &quot;Data Roaming Day Pass&quot; and &quot;Multi-Day Roaming Data Pack&quot; are not
													applicable.
												</li>
												<li>
													When the Customer is within the location of any of the overseas destinations other than designated APAC destinations, the daily roaming data usage will be charged by
													&quot;Data Roaming Day Pass&quot; subscribed by the Customer. For details of &quot;Data Roaming Day Pass&quot;, service fee, terms and conditions, please visit{' '}
													<a target="_blank" href="http://smartone.com/other/english/tc_I025_e.pdf">
														smartone.com/T&amp;CI025E
													</a>
													.&nbsp;
												</li>
												<li>
													Whenever the &quot;APAC Roaming Data Pack&quot; data usage of the Customer under the Specified Service Plan nearly reaches the specified data usage, the Company will
													notify the Customer by SMS.&nbsp;Any subsequent data roaming usage will be automatically charged at $30 per GB.
												</li>
												<li>Any unused monthly data entitlement allowance and top-up data of &quot;APAC Roaming Data Pack&quot; will be forfeited at the end of billing month.</li>
												<li>
													In-flight roaming is only applicable to selected flights. For details, please visit{' '}
													<a target="_blank" href="https://www.aeromobile.net/airlines/">
														https://www.aeromobile.net/airlines/
													</a>
													.
												</li>
												<li>
													(If applicable) If the customer purchased more than one Roaming Data service, deduction on usage of roaming data shall follow the following deduction sequence:
													<ol>
														<li>Designated Mainland &amp; Macau Roaming Data Pack data allowance;</li>
														<li>APAC Roaming Data Pack data allowance;</li>
														<li>RoamFlex Data Pass &ndash; APAC data allowance;</li>
														<li>Worldwide Roaming Data Pack data allowance;</li>
														<li>RoamFlex Data Pass &ndash; Worldwide data allowance;</li>
														<li>1GB/month APAC Roaming Data Pack data allowance;</li>
														<li>Multi-Day Roaming Data Pack / Data Roaming Day Pass (by daily);</li>
													</ol>
												</li>
												<li>
													&quot;APAC Roaming Data Pack&quot; can only be subscribed in conjunction with designated service plans. Please note that the designated service plans that are
													compatible with the &quot;APAC Roaming Data Pack&quot; may undergo periodic changes without prior notice.
												</li>
												<li>
													Terms &amp; Conditions apply, please refer to{' '}
													<a target="_blank" href="https://www.smartone.com/other/english/tc_I050_e.pdf">
														T&amp;C-I050
													</a>{' '}
													.
												</li>
											</ol>
										</li>
									</ul>

									<p>Designated Handset Discount Offer:</p>

									<ul>
										<li>From now until 31 May 2024, customers are entitled to purchase a designated handset with discount price by presenting the 5G Free Trial SIM jacket. &nbsp;</li>
										<li>The discount offer is only available in-store.</li>
										<li>Each 5G Free Trial SIM jacket is entitled to the offer once only.</li>
										<li>The offer cannot be exchanged for other goods or cash.</li>
										<li>
											The offer is subject to stock availability with limited quota and are on a first-come-first-served basis only. The Offer will be terminated accordingly without prior notice.
										</li>
										<li>The offer is subject to terms and conditions. Please contact our staff for details.</li>
										<li>In case of any dispute, the decision of SmarTone is final.</li>
									</ul>

									<Typography variant="h9">Free 3-month Home 5G Broadband Service:</Typography>

									<ul>
										<li>
											Customer is required to activate the service the day after the registration of Home 5G Broadband Free Trial Service with designated home 5G broadband device(s). Once activated,
											registered customers will be entitled to a free 3-month trial of the Home 5G Broadband service with designated home 5G broadband device(s), starting from the date of service
											activation.
										</li>
										<li>
											This Home 5G Broadband Free Trial Service plan fee is calculated on the basis of the original service plan monthly fee $238 and designated 5G broadband device rental service
											$65 (a 5G router)/ $93 (a 5G router and a mesh router), after deduction of designated monthly rebate of $238 and $65/ 93 during 3-month contract period. No compensation in
											whatever form will be given if the customer terminates the contract during the free trial period.
										</li>
										<li>Voice and roaming service is not available for the SIM used for Home 5G Broadband Monthly Plan. The SIM must be used with designated Home 5G Broadband device(s).</li>
										<li>
											This plan includes unlimited 5G data. Subjected to FUP (Fair Usage Policy). For details, please visit{' '}
											<a target="_blank" href="https://www.smartone.com/other/english/TC_WB007A.pdf">
												T&amp;C WB007A
											</a>
											.
										</li>
										<li>
											Customer can enjoy free maintenance of the leased equipment during the service period. If maintenance is required due to specified circumstances (human-damage /accident /
											improper usage), the company will charge customers additional maintenance fees under this clause at the current rate.
										</li>
										<li>This service will be terminated after the end of the trial, please contact our SmarTone staff via WhatsApp at 6013 2054 if the customer wish to continue using the service.</li>
										<li>
											Customer is required to return the whole set Home 5G Broadband device(s) with SIM card and full packing to SmarTone&rsquo;s stores within 14 days after expiration of the trial
											period. The Customer must return the Home 5G Broadband device(s) to the company in the same condition as when it was delivered to the customer, except for normal wear and tear.
											If the Customer fails to return the Home 5G Broadband device(s) or any part thereof is damaged (due to human-damage /accident / improper usage) upon return, the Company will
											charge Customer maintenance fee at current rate. For details, please visit{' '}
											<a target="_blank" href="https://www.smartone.com/other/english/smartonejetfaq.pdf">
												https://www.smartone.com/other/english/smartonejetfaq.pdf
											</a>
											.
										</li>
										<li>
											Internet experience can vary due to factors such as the relative position between user and the base stations, the download server resources, Internet traffic conditions, the
											number of users, users&rsquo; devices and other factors that may arise. Wi-Fi coverage depends on factors such as area &amp; layout of the premises, construction materials, and
											other extraneous factors.
										</li>
										<li>Our Company reserves the right of final decision relating to the promotion and any dispute thereof, and may change the Terms and Conditions without prior notice.</li>
									</ul>

									<Typography variant="h9">Free 3-month HomePhone+ Service:</Typography>

									<ul>
										<li>
											Customer is required to activate the service the day after the registration of free HomePhone+ service with designated device. Once activated, registered customers will be
											entitled to a 3-month free trial of the HomePhone+ service with designated device, starting from the date of service activation.
										</li>
										<li>This HomePhone+ Free Trial Service is only applicable to new home telephone number allocated by the company and not applicable to number ported-in from other operators.</li>
										<li>HomePhone+ service is applicable to designated devices and does not support Care-on-Call service.</li>
										<li>HomePhone+ service is only applicable to the customer whose residential address for using the service is located in designated residential area.</li>
										<li>
											This free trial HomePhone+ service plan fee is calculated on the basis of the original service plan monthly fee $68, after giving monthly rebate of $68 during 3-month contract
											period. No compensation will be given if the customer terminates the contract during the free trial period. The contract will be terminated automatically after expiry of free
											trial period.
										</li>
										<li>
											IDD calling service and other VAS are available for use and subject to charges. Customer is required to pay Pay-as-you-go charges caused by IDD calling service / monthly caused
											by related VAS. Please click{' '}
											<a target="_blank" href="https://www.smartone.com/en/mobile_and_price_plans/roaming_idd/idd/001idd.jsp">
												001IDD
											</a>
											<a target="_blank" href="https://www.smartone.com/en/mobile_and_price_plans/roaming_idd/idd/1638idd.jsp">
												1638 IDD
											</a>{' '}
											for more details of IDD calling service.
										</li>
										<li>The service will be terminated after the end of the trial, please contact our SmarTone staff via WhatsApp at 6013 2054 if the customer wish to continue using the service.</li>
										<li>
											Customer is required to return the whole set HomePhone+ device(s) with SIM card and full packing to SmarTone&rsquo;s stores not later than 14 days after expiration of the trial
											period. The customer must return the HomePhone+ device(s) to the company in the same condition as when it was delivered to the customer, except for normal wear and tear. If the
											customer fails to return the Device or any part thereof is damaged (due to human-damage /accident / improper usage) upon return, the Company will charge customer maintenance
											fee at current rate (i. Loss/ Damage of HomePhone+ Main unit - $780; ii. Loss/ Damage of Charging Cradle - $40; iii. Loss/ Damage of USB Charger - $40; Loss/ Damage of Li-ion
											Battery - $65).
										</li>
										<li>Our Company reserves the right of final decision relating to the promotion and any dispute thereof, and may change the Terms and Conditions without prior notice.</li>
									</ul>

									<Typography variant="h9">Fibre Broadband Service</Typography>

									<ul>
										<li>
											Speed Specification : Specifications of Home Fibre1000 are based on internet connection from the wallplate at Customer&#39;s premises to the first piece of the Company&rsquo;s
											network equipment. Maximum upload/download speed to local site could be up to 1000Mbps respectively. The actual bandwidth that the Customer can enjoy may be affected by the
											Customer&rsquo;s hardware / software, router specification, site traffic loading, type of content being accessed and other environmental factors; and hence is normally less
											than the above speed. The bandwidth to overseas sites will also be subjected to the conditions of local network there, and therefore the bandwidth might be even less.
										</li>

										<li>
											Offer applies to customers who successfully register the fibre broadband service and complete installation within 45 day from service application at a designated resident
											address with designated contract term.
										</li>

										<li>The rebate of monthly fee of Fibre broadband service will be credited to the customer account over the contract period of the Service Plan.</li>
										<li>
											The first time basic installation fee will be waived. If the Service is terminated within the designated contract term for whatever reasons, the Company shall have the right to
											charge the Customer the basic installation fee for the Service subscribed.
										</li>
										<li>Customer is required to choose cash with no deposit as payment method.</li>
										<li>At the end of the contract, the customer will be charged at the prevailing plan price if the customer continues to use the service.</li>
										<li>All rebate amount cannot be transferred to any third party or exchanged to cash for whatever reason.</li>
										<li>
											During the contract period of the Service, Customer may request relocation of the Service to another residential address which is within the service network of the Company
											provided that relocation of the Service shall be subject to signing of new Sales and Services Agreement with the Company at the prevailing service plan price for the new
											address and payment of the relocation fee charged by the Company.
										</li>
										<li>
											Upon termination of the Service, the Customer must return all equipment (if applicable) provided by the Company to SmarTone&rsquo;s stores within fourteen (14) days. If the
											Customer does not return the equipment or the equipment is lost or damaged upon return, the Company will charge the Customer (i) HK$1,500 for each Optical Network Terminal
											and/or (ii) HK$100 for each Adaptor; or (iii)such other charges at such rates as specified by the Company from time to time. (Applicable to designated Home Broadband 100 or
											Home Broadband 200) If the Customer does not return the equipment or the equipment is lost or damaged upon return, the Company will charge the Customer (i) HK$500 for each
											Broadband Network Terminal and/or (ii) HK$100 for each Adaptor ; or (iii)such other charges at such rates as specified by the Company from time to time.
										</li>
										<li>If the Customer terminates the Service during the first 12 months, the Customer shall pay a $680 handling charge.</li>
										<li>SmarTone reserves the right of final decision relating to the promotion and any dispute thereof, and may change the Terms and Conditions without prior notice.</li>
										<li>
											Subject to relevant terms and conditions. Please refer to Sales and Services Agreement and&nbsp;
											<a target="_blank" href="https://www.smartone.com/other/english/TC_N003DB_e.pdf">
												T&amp;C-N003DB
											</a>{' '}
											for details.
										</li>
									</ul>
								</TncWrapper>
							)}
						</SimpleAccordionExpand>
					</Container>
				</StyledPrimarySectionPlan>
				<SimpleDialog isOpen={dialog1Open} onClose={() => setDialog1Open(false)}>
					<StyledRemarkContainer>
						<StyledRemarkHeader>{intl.formatMessage({ id: 'homepage.remark.h5gbb.header-title' })}</StyledRemarkHeader>
						<ul>
							<StyledRemarkContentLi>{intl.formatMessage({ id: 'homepage.remark.h5gbb.content-1' })}</StyledRemarkContentLi>
							<StyledRemarkContentLi>{intl.formatMessage({ id: 'homepage.remark.h5gbb.content-2' })}</StyledRemarkContentLi>
							<StyledRemarkContentLi>{intl.formatMessage({ id: 'homepage.remark.h5gbb.content-3' })}</StyledRemarkContentLi>
						</ul>
					</StyledRemarkContainer>
					<StyledRemarkContainer>
						<StyledRemarkHeader>{intl.formatMessage({ id: 'homepage.remark.hpp.header-title' })}</StyledRemarkHeader>
						<ul>
							<StyledRemarkContentLi>{intl.formatMessage({ id: 'homepage.remark.hpp.content-1' })}</StyledRemarkContentLi>
							<StyledRemarkContentLi>{intl.formatMessage({ id: 'homepage.remark.hpp.content-2' })}</StyledRemarkContentLi>
						</ul>
					</StyledRemarkContainer>
				</SimpleDialog>
				<SimpleDialog isOpen={dialog2Open} onClose={() => setDialog2Open(false)}>
					<StyledRemarkContainer>
						<StyledRemarkHeader>{intl.formatMessage({ id: 'homepage.remark.fbb.header-title' })}</StyledRemarkHeader>
						<StyledRemarkContent>{intl.formatMessage({ id: 'homepage.remark.fbb.content-1' })}</StyledRemarkContent>
					</StyledRemarkContainer>
				</SimpleDialog>
			</StyledHomeWrapper>
		</>
	);
}

export default HomePage;
