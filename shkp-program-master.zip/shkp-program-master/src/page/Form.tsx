// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useCallback, useContext, useMemo, useState } from 'react';

// intl
import Container from '@/layout/Container';
import TextField from '@smt/formElement/TextField';
import { styled, useTheme } from 'styled-components';
import { Box, FormControl, FormControlLabel, FormGroup, Grid, List, ListItem, ListItemIcon, MenuItem, SelectChangeEvent, Typography } from '@mui/material';
import SectionTitle from '@/components/FormSectionTitle';
import { StyledSectionTitleIcon } from '../components/FormSectionTitle/index';
import DoneIcon from '@mui/icons-material/Done';
import { useEffect } from 'react';
import Checkbox from '@smt/formElement/Checkbox';
import Selectbox from '@smt/formElement/Selectbox';
import Radio from '@smt/formElement/Radio';
import RadioGroup from '@smt/formElement/RadioGroup';
import SelectDate from '@smt/formElement/SelectDate';
import Button from '@smt/formElement/Button';

import { useForm, Controller, SubmitHandler, useFormState, useWatch, ControllerRenderProps, RegisterOptions, UseControllerProps } from 'react-hook-form';
import { DevTool } from '@hookform/devtools';
import { useIntl } from 'react-intl';
import UploadImage from '../components/UploadImage/UploadImage';
import IDField from '@smt/formElement/IDField';
import CheckboxGroup from '@smt/formElement/CheckboxGroup';
import ApplicationContext, { Channel } from '@smt/context/ApplicationContext';
import ServiceInfoCard from '@/components/ServiceInfoCard/ServiceInfoCard';
import { ApplyService, FormValues } from '@/type/Form';
import Img from '@/components/img/Img';
import getFormErrorMsg from '@/context/FormErrorMsgRules';
import dayjs from 'dayjs';
import Scancode from '@smt/formElement/Scancode';
import {
	PreValidationAddressQuota,
	PreValidationIMEIResponse,
	PreValidationProps,
	PreValidationResponse,
	PreValidationSerialResponse,
	PreValidationSimResponse,
	usePreValidation,
} from '@/hook/preValidation/usePreValidation';
import deepmerge from 'deepmerge';
import { useLoading } from './../hook/loading/useLoading';
import FormHelperText from '@smt/formElement/FormHelperText';
import Popup from '@smt/formElement/Popup';

const StyledFormWrapper = styled.div(({ theme }) => ({
	paddingLeft: theme.spacing(2),
	paddingRight: theme.spacing(2),
	paddingTop: theme.spacing(5),
	paddingBottom: theme.spacing(5),
}));

const StyledSection = styled.div(({ theme }) => ({
	width: '100%',
	marginBottom: theme.spacing(4),
	'&:last-child': {
		marginBottom: 0,
	},
}));

const StyledList = styled(List)(({ theme }) => ({
	'&.MuiList-root': {
		listStyleType: 'disc',
		listStylePosition: 'inside',
	},
}));

const StyledListItem = styled(ListItem)(({ theme }) => ({
	'&.MuiListItem-root': {
		display: 'list-item',
		padding: 0,
		marginBottom: theme.spacing(1),
	},
}));

interface PageFormProp {
	appliedService: ApplyService;
	setAppliedService: (data: ApplyService) => void;
	formData: FormValues;
	setFormData: (data: FormValues) => void;
	onFormValidated: (isAllow: boolean) => void;
	extraValidate: string;
	setExtraValidate: (result: string) => void;
}
interface meshAddressGroup {
	select: string[];
	selectedValue: unknown;
	isDisable: boolean;
}

function checkAllowApplyService(data?: PreValidationAddressQuota) {
	if (!data) {
		return false;
	}

	const totalSubmit = data.total_submit;
	const maxQuota = data.quota.quota;
	const quotaBalance = data.quota.quota_balance;
	const quotaWarning = data.quota.warning_lower_limit;
	const quotaLimit = data.quota.lower_limit;

	// 1) if quota balance = warning_lower_limit,就要有個alert box "you have reach the limit"
	// 2) if quota balance = lower_limit, hide the service
	// 3) if all service reach the lower_limit, hide all services and show "no more service"

	if (quotaBalance == quotaLimit) {
		//all quota used
		return 'noQuota';
	}
	if (quotaBalance == quotaWarning) {
		//allow staff to submit one more time to fix error
		return 'warning';
	}

	return 'allow';
}

function checkStatus({ list, type, service }: { list?: any[]; type: 'sim' | 'serial' | 'IMEI'; service: keyof ApplyService }) {
	let result = '';

	if (!Array.isArray(list) || list == null || list == undefined) {
		return result;
	}

	list.map((v) => {
		if (v?.[type] != undefined && v?.[type] != '') {
			if (type == 'serial') {
				if (v.status == 'ok') {
					result = 'ok';
				} else {
					result = v.error;
				}
			} else {
				if (v.service == service) {
					if (v.status == 'ok') {
						result = 'ok';
					} else {
						result = v.error;
					}
				}
			}
		} else {
			result = '';
		}
	});

	return result;
}

function checkPreValidationResult(data?: PreValidationResponse) {
	const mobileAddressQuota = data?.address?.address_quota?.mobile;
	const H5GBBAddressQuota = data?.address?.address_quota?.H5GBB;
	const FBBAddressQuota = data?.address?.address_quota?.FBB;

	const mobileApplyServiceStatus = checkAllowApplyService(mobileAddressQuota);
	const H5GBBApplyServiceStatus = checkAllowApplyService(H5GBBAddressQuota);
	const FBBApplyServiceStatus = checkAllowApplyService(FBBAddressQuota);
	const mobileSimStatus = checkStatus({ list: data?.sim_list, type: 'sim', service: 'mobile' });
	const H5GBBSimStatus = checkStatus({ list: data?.sim_list, type: 'sim', service: 'H5GBB' });
	const HPPSimStatus = checkStatus({ list: data?.sim_list, type: 'sim', service: 'HPP' });
	const H5GBBIMEIStatus = checkStatus({ list: data?.IMEI_list, type: 'IMEI', service: 'H5GBB' });
	const HPPIMEIStatus = checkStatus({ list: data?.IMEI_list, type: 'IMEI', service: 'HPP' });
	const H5GBBSerialStatus = checkStatus({ list: data?.serial_list, type: 'serial', service: 'H5GBB' });

	return {
		mobile: {
			status: mobileApplyServiceStatus,
			simStatus: mobileSimStatus,
		},
		H5GBB: {
			status: H5GBBApplyServiceStatus,
			simStatus: H5GBBSimStatus,
			IMEIStatus: H5GBBIMEIStatus,
			serialStatus: H5GBBSerialStatus,
		},
		HPP: {
			simStatus: HPPSimStatus,
			IMEIStatus: HPPIMEIStatus,
		},
		FBB: {
			status: FBBApplyServiceStatus,
		},
	};
}

function Form({ appliedService, setAppliedService, formData, setFormData, onFormValidated, extraValidate, setExtraValidate }: PageFormProp) {
	const theme = useTheme();
	const intl = useIntl();
	const applicationContext = useContext(ApplicationContext);
	const { preValidation, result: preValidationResult } = usePreValidation();
	const { showLoading, hideLoading, LoadingScreen } = useLoading({ fullScreen: true });

	//get data from app context
	const channel: Channel = applicationContext?.channel == 'clubhouse' ? 'clubhouse' : 'self-help';
	const meshRouterAddress = useMemo(() => {
		let blockGroup = applicationContext?.meshRouterAddress?.block_group;
		let floorGroup = applicationContext?.meshRouterAddress?.floor_group;
		let flatGroup = applicationContext?.meshRouterAddress?.flat_group;

		blockGroup = blockGroup?.sort((a: any, b: any) => a - b);
		floorGroup = floorGroup?.sort((a: any, b: any) => a - b);
		flatGroup = flatGroup?.sort();

		return {
			block_group: blockGroup,
			floor_group: floorGroup,
			flat_group: flatGroup,
			list: applicationContext?.meshRouterAddress?.list,
		};
	}, [applicationContext?.meshRouterAddress]);
	const mobileWorkingDay = useMemo(() => {
		return applicationContext?.mobileWorkingDay || [];
	}, [applicationContext?.mobileWorkingDay]);
	const h5gbbWorkingDay = useMemo(() => {
		return applicationContext?.h5gbbWorkingDay || [];
	}, [applicationContext?.h5gbbWorkingDay]);
	const fbbInstallWorkingDay = useMemo(() => {
		let fbbInstallWorkingDay = applicationContext?.fbbInstallWorkingDay || [];
		const isNow2Pm = dayjs().hour() >= 14;
		if (isNow2Pm && fbbInstallWorkingDay.length > 0) {
			fbbInstallWorkingDay.shift();
		}
		return fbbInstallWorkingDay;
	}, [applicationContext?.fbbInstallWorkingDay]);
	const fbbWorkingTime = useMemo(() => {
		return applicationContext?.fbbWorkingTime || [];
	}, [applicationContext?.fbbWorkingTime]);

	//react hook form control
	const { control, register, setValue, getValues, handleSubmit, setError, trigger } = useForm<FormValues>({
		defaultValues: {
			...formData,
		},
		mode: 'onChange',
	});
	const { isValid: isFormValid, isValidating, errors } = useFormState({ control });
	const watchForm = useWatch({ control: control });
	const formErrorMsgRules: any = getFormErrorMsg();

	//page var
	const isClubhouse = channel == 'clubhouse';
	const ageBiggerThan18 = dayjs().subtract(18, 'year');
	const [meshRouterTotal, setMeshRouterTotal] = useState<number>(parseInt(getValues('H5GBB_trial.0.mesh_total')));
	const [isAllowToSubmitService, setIsAllowToSubmitService] = useState(isClubhouse ? false : true);
	const [errorPopup, setErrorPopup] = useState('');

	//address control
	const [blockGroup, setBlockGroup] = useState<meshAddressGroup>({
		select: meshRouterAddress.block_group || [],
		selectedValue: getValues('address_block'),
		isDisable: true,
	});
	const [floorGroup, setFloorGroup] = useState<meshAddressGroup>({
		select: meshRouterAddress.floor_group || [],
		selectedValue: getValues('address_floor'),
		isDisable: true,
	});
	const [flatGroup, setFlatGroup] = useState<meshAddressGroup>({
		select: meshRouterAddress.flat_group || [],
		selectedValue: getValues('address_flat'),
		isDisable: true,
	});
	const filterMeshAddress = useCallback(
		(value: string, name: 'address_block' | 'address_floor' | 'address_flat') => {
			if (name == 'address_block') {
				let filteredAddressList = meshRouterAddress.list?.filter((listObj) => {
					return listObj.block == value;
				});
				let filteredFloor: string[] = [];
				filteredAddressList?.map((listObj) => {
					let isFindFloor = filteredFloor.find((floor) => {
						return listObj.floor == floor;
					});
					!isFindFloor ? filteredFloor.push(listObj.floor) : '';
				});
				return filteredFloor;
			}
			if (name == 'address_floor') {
				const filteredAddressList = meshRouterAddress.list?.filter((listObj) => {
					return listObj.block == blockGroup.selectedValue && listObj.floor == value;
				});

				let filteredFlat: string[] = [];
				filteredAddressList?.map((listObj) => {
					let isFindFlat = filteredFlat.find((flat) => {
						return listObj.flat == flat;
					});
					!isFindFlat ? filteredFlat.push(listObj.flat) : '';
				});

				return filteredFlat;
			}
			if (name == 'address_flat') {
				return [];
			}

			return [];
		},
		[blockGroup, floorGroup, flatGroup, meshRouterAddress],
	);
	const onMeshAddressChange = (value: unknown, name: 'address_block' | 'address_floor' | 'address_flat') => {
		const fileredSelect = filterMeshAddress(value as string, name);

		switch (name) {
			case 'address_block':
				{
					setBlockGroup((prev) => {
						return {
							...prev,
							selectedValue: value,
						};
					});
					setFloorGroup({
						select: fileredSelect,
						selectedValue: '',
						isDisable: false,
					});
					setValue('address_floor', '');
					setFlatGroup({
						select: meshRouterAddress.flat_group || [],
						selectedValue: '',
						isDisable: true,
					});
					setValue('address_flat', '');
				}
				break;
			case 'address_floor':
				{
					setFloorGroup((prev) => {
						return {
							...prev,
							selectedValue: value,
						};
					});
					setFlatGroup({
						select: fileredSelect,
						selectedValue: '',
						isDisable: false,
					});
					setValue('address_flat', '');
				}
				break;
			case 'address_flat':
				{
					const filteredAddressList = meshRouterAddress.list?.filter((listObj) => {
						return listObj.block == blockGroup.selectedValue && listObj.floor == floorGroup.selectedValue && listObj.flat == value;
					});

					//should be only one item
					setMeshRouterTotal(filteredAddressList?.[0]?.total || 0);
					setValue('H5GBB_trial.0.mesh_total', filteredAddressList?.[0]?.total.toString() || '0');
					setFlatGroup((prev) => {
						return {
							...prev,
							selectedValue: value,
						};
					});

					if (isClubhouse) {
						preValidation({
							step: 'isCheckingAddress',
							staff_ID: getValues('staff_ID') || '',
							channel: channel,
							address: {
								block: filteredAddressList?.[0]?.block || '',
								floor: filteredAddressList?.[0]?.floor || '',
								flat: filteredAddressList?.[0]?.flat || '',
							},
						});
					}
				}
				break;
			default:
				null;
		}
	};
	const resetAddressChange = () => {
		setBlockGroup((prev) => {
			return {
				...prev,
				selectedValue: '',
				isDisable: true,
			};
		});
		setValue('address_block', '');
		setFloorGroup((prev) => {
			return {
				...prev,
				selectedValue: '',
				isDisable: true,
			};
		});
		setValue('address_floor', '');
		setFlatGroup((prev) => {
			return {
				...prev,
				selectedValue: '',
				isDisable: true,
			};
		});
		setValue('address_flat', '');
		setValue('address_in_one_line', '');
	};

	//popup contorl
	const onCloseErrorPopup = () => {
		setErrorPopup('');
	};

	//section title
	const sectionIconObject = {
		staff: <StyledSectionTitleIcon color={theme.palette.primary.main}>0</StyledSectionTitleIcon>,
		applierInfo: <StyledSectionTitleIcon color={theme.palette.primary.main}>1</StyledSectionTitleIcon>,
		serviceInfo: <StyledSectionTitleIcon color={theme.palette.primary.main}>2</StyledSectionTitleIcon>,
		deliveryInfo: <StyledSectionTitleIcon color={theme.palette.primary.main}>3</StyledSectionTitleIcon>,
		done: (
			<StyledSectionTitleIcon color={theme.palette.green.main}>
				<DoneIcon />
			</StyledSectionTitleIcon>
		),
	};

	useEffect(() => {
		if (getValues('address_block') != '') {
			setFloorGroup((prev) => {
				return {
					...prev,
					select: filterMeshAddress(getValues('address_block'), 'address_block'),
					isDisable: false,
				};
			});
		}
		if (getValues('address_floor') != '') {
			setFlatGroup((prev) => {
				return {
					...prev,
					select: filterMeshAddress(getValues('address_floor'), 'address_floor'),
					isDisable: false,
				};
			});
		}

		if (isClubhouse) {
			if (getValues('staff_ID') != '' && getValues('address_block') != '' && getValues('address_floor') != '' && getValues('address_flat') != '') {
				setBlockGroup((prev) => {
					return {
						...prev,
						isDisable: false,
					};
				});
				preValidation({
					step: 'isCheckingAddress',
					staff_ID: getValues('staff_ID') || '',
					channel: channel,
					address: {
						block: getValues('address_block'),
						floor: getValues('address_floor'),
						flat: getValues('address_flat'),
					},
				});
			}
		}
	}, []);

	useEffect(() => {
		if (!isValidating) {
			if (isFormValid) {
				handleSubmit((data) => {
					setFormData(data);
				})();
			}
			onFormValidated(isFormValid);
		}
	}, [isValidating, isFormValid, watchForm]);

	useEffect(() => {
		if (isClubhouse) {
			if (watchForm.address_floor == '' || watchForm.staff_ID == '') {
				setIsAllowToSubmitService(false);
			}
			if (watchForm?.mobile_trial?.[0]?.is_disabled && watchForm?.H5GBB_trial?.[0]?.is_disabled && watchForm?.FBB_trial?.[0]?.is_disabled && watchForm?.at_least_one_service) {
				setValue('at_least_one_service', false);
			} else if ((!watchForm?.mobile_trial?.[0]?.is_disabled || !watchForm?.H5GBB_trial?.[0]?.is_disabled || !watchForm?.FBB_trial?.[0]?.is_disabled) && !watchForm?.at_least_one_service) {
				setValue('at_least_one_service', true);
			}
		}
	}, [watchForm]);

	useEffect(() => {
		if (preValidationResult?.status == 'fetching') {
			//add loading here
			showLoading();
		} else if (preValidationResult?.status == 'ok') {
			if (preValidationResult.result?.status == 'ok') {
				let convertedResult = checkPreValidationResult(preValidationResult.result?.result);
				const condition = convertedResult.mobile.status !== 'noQuota' || convertedResult.H5GBB.status !== 'noQuota' || convertedResult.FBB.status !== 'noQuota';
				setIsAllowToSubmitService(condition);
				let isError = false;
				let errorStr = '';

				if (convertedResult.mobile.status == 'warning') {
					errorStr += 'mobile warning: Service reach Limited<br/>';
				}
				if (convertedResult.H5GBB.status == 'warning') {
					errorStr += 'h5gbb warning: Service reach Limited<br/>';
				}
				if (convertedResult.FBB.status == 'warning') {
					errorStr += 'fbb warning: Service reach Limited<br/>';
				}

				if (errorStr != '') {
					setErrorPopup(errorStr);
				}

				setAppliedService({
					mobile: convertedResult.mobile.status !== 'noQuota',
					H5GBB: convertedResult.H5GBB.status !== 'noQuota',
					FBB: convertedResult.FBB.status !== 'noQuota',
				});
				if (isClubhouse) {
					if (convertedResult.mobile.simStatus != 'ok' && convertedResult.mobile.simStatus != '') {
						isError = true;
						setError('mobile_trial.0.sim', {
							type: 'pre_validate',
							message: convertedResult.mobile.simStatus,
						});
					}
					if (convertedResult.H5GBB.simStatus != 'ok' && convertedResult.H5GBB.simStatus != '') {
						isError = true;
						setError('H5GBB_trial.0.sim', {
							type: 'pre_validate',
							message: convertedResult.H5GBB.simStatus,
						});
					}
					if (convertedResult.H5GBB.IMEIStatus != 'ok' && convertedResult.H5GBB.IMEIStatus != '') {
						isError = true;
						setError('H5GBB_trial.0.main_IMEI', {
							type: 'pre_validate',
							message: convertedResult.H5GBB.IMEIStatus,
						});
					}
					if (convertedResult.H5GBB.serialStatus != 'ok' && convertedResult.H5GBB.serialStatus != '') {
						isError = true;
						setError('H5GBB_trial.0.mesh_serial_num', {
							type: 'pre_validate',
							message: convertedResult.H5GBB.serialStatus,
						});
					}
					if (convertedResult.HPP.simStatus != 'ok' && convertedResult.HPP.simStatus != '') {
						isError = true;
						setError('HPP_trial.0.sim', {
							type: 'pre_validate',
							message: convertedResult.HPP.simStatus,
						});
					}
					if (convertedResult.HPP.IMEIStatus != 'ok' && convertedResult.HPP.IMEIStatus != '') {
						isError = true;
						setError('HPP_trial.0.main_IMEI', {
							type: 'pre_validate',
							message: convertedResult.HPP.IMEIStatus,
						});
					}
				}

				if (condition == false) {
					setValue('api_error', 'No service' || 'api_error');
					setError('api_error', {
						type: 'no service',
						message: 'No More Service',
					});
				}

				if (extraValidate == 'startValidate' || extraValidate == 'fail') {
					if (isError) {
						setExtraValidate('fail');
					} else {
						setExtraValidate('validated');
					}
				}
			} else if (preValidationResult.result?.status == 'fail') {
				setIsAllowToSubmitService(false);
				setAppliedService({
					mobile: false,
					H5GBB: false,
					FBB: false,
				});
				setValue('api_error', preValidationResult.result?.err_msg || 'api_error');
				setError('api_error', {
					type: 'api error',
					message: preValidationResult.result?.err_msg,
				});
			}
			hideLoading();
		}
	}, [preValidationResult]);

	useEffect(() => {
		if (extraValidate == 'startValidate') {
			let submitData: PreValidationProps = {
				step: 'isCheckingFullform',
				staff_ID: getValues('staff_ID') || '',
				channel: channel,
				address: {
					block: getValues('address_block'),
					floor: getValues('address_floor'),
					flat: getValues('address_flat'),
				},
			};
			if (isClubhouse) {
				if (appliedService.mobile && getValues('mobile_trial.0.is_disabled') == false) {
					if (!Array.isArray(submitData.sim_list)) {
						submitData.sim_list = [];
					}
					submitData.sim_list.push({
						sim: getValues('mobile_trial.0.sim'),
						service: 'mobile',
					});
				}
				if (appliedService.H5GBB && getValues('H5GBB_trial.0.is_disabled') == false) {
					if (!Array.isArray(submitData.sim_list)) {
						submitData.sim_list = [];
					}
					if (!Array.isArray(submitData.IMEI_list)) {
						submitData.IMEI_list = [];
					}
					submitData.sim_list.push({
						sim: getValues('H5GBB_trial.0.sim'),
						service: 'H5GBB',
					});
					submitData.IMEI_list.push({
						IMEI: getValues('H5GBB_trial.0.main_IMEI'),
						service: 'H5GBB',
					});
					if (getValues('H5GBB_trial.0.mesh_required') == 'yes') {
						if (!Array.isArray(submitData.serial_list)) {
							submitData.serial_list = [];
						}
						submitData.serial_list.push({
							serial: getValues('H5GBB_trial.0.mesh_serial_num'),
						});
					}
					if (getValues('HPP_trial.0.hpp_required') == 'yes') {
						submitData.sim_list.push({
							sim: getValues('HPP_trial.0.sim'),
							service: 'HPP',
						});
						submitData.IMEI_list.push({
							IMEI: getValues('HPP_trial.0.main_IMEI'),
							service: 'HPP',
						});
					}
				}
				//temp
				if (getValues('FBB_trial.0.same_as_applier') == 'yes') {
					setValue('FBB_trial.0.installation_contact', getValues('english_first_name') + ' ' + getValues('english_last_name'));
					setValue('FBB_trial.0.installation_contact_number', getValues('contact_number'));
				}

				setValue(
					'address_in_one_line',
					'Flat ' +
						getValues('address_flat') +
						', Floor ' +
						getValues('address_floor') +
						', Block ' +
						getValues('address_block') +
						', ' +
						getValues('address_estate') +
						', ' +
						getValues('address_street') +
						', ' +
						getValues('address_district'),
				);
			}
			preValidation(submitData);
		}
	}, [extraValidate]);

	return (
		<StyledFormWrapper>
			<Container>
				<input type="hidden" {...register('api_error')} />

				<Popup open={errorPopup != ''} dialogTitle={'Service reach Limited'} dialogAction={<Button onClick={onCloseErrorPopup}>OK</Button>} onClose={onCloseErrorPopup}>
					<Typography variant="p4">
						<div dangerouslySetInnerHTML={{ __html: errorPopup }}></div>
					</Typography>
				</Popup>

				{isClubhouse && (
					<StyledSection>
						<SectionTitle sectionIcon={sectionIconObject.staff} title="職員專用" />
						<Grid container spacing={2}>
							<Grid item xs={12}>
								<Controller
									name="staff_ID"
									control={control}
									render={({ field, fieldState }) => (
										<TextField
											label={'員工編號'}
											fullWidth={true}
											helperText={''}
											value={field.value}
											onChange={(event) => {
												field.onChange(event?.target.value);

												if (event?.target.value != '') {
													setBlockGroup((prev) => {
														return {
															...prev,
															isDisable: false,
														};
													});
												} else {
													resetAddressChange();
												}
											}}
										/>
									)}
								/>
							</Grid>
							<Grid item container xs={12} spacing={1}>
								<Grid item xs={12}>
									<Typography variant="h7">單位地址</Typography>
								</Grid>
								<Grid item xs={12}>
									<Typography variant="p4">大埔優景里63號 Silicon Hill</Typography>
								</Grid>
							</Grid>
							<Grid item xs={6} sm={4}>
								<Controller
									name="address_block"
									control={control}
									rules={formErrorMsgRules.address_block || {}}
									render={({ field, fieldState }) => (
										<Selectbox
											label={'單位座數'}
											labelId="address_block"
											placeholder={'請選擇'}
											fullWidth={true}
											defaultValue=""
											value={field.value}
											onChange={(event) => {
												field.onChange(event?.target.value);
												onMeshAddressChange(event?.target.value, field.name);
											}}
											disabled={blockGroup.isDisable}
										>
											{blockGroup.select.map((value, index) => {
												return (
													<MenuItem value={value} key={index}>
														{value}
													</MenuItem>
												);
											})}
										</Selectbox>
									)}
								/>
							</Grid>
							<Grid item xs={6} sm={4}>
								<Controller
									name="address_floor"
									control={control}
									rules={formErrorMsgRules.address_floor || {}}
									render={({ field, fieldState }) => (
										<Selectbox
											label={'單位樓層'}
											labelId="address_floor"
											placeholder={'請選擇'}
											fullWidth={true}
											defaultValue=""
											value={field.value}
											onChange={(event) => {
												field.onChange(event?.target.value);
												onMeshAddressChange(event?.target.value, field.name);
											}}
											disabled={floorGroup.isDisable}
										>
											{floorGroup.select.map((value, index) => {
												return (
													<MenuItem value={value} key={index}>
														{value}
													</MenuItem>
												);
											})}
										</Selectbox>
									)}
								/>
							</Grid>
							<Grid item xs={6} sm={4}>
								<Controller
									name="address_flat"
									control={control}
									rules={formErrorMsgRules.address_flat || {}}
									render={({ field, fieldState }) => (
										<Selectbox
											label={'單位室號'}
											labelId="address_flat"
											placeholder={'請選擇'}
											fullWidth={true}
											defaultValue=""
											value={field.value}
											onChange={(event) => {
												field.onChange(event?.target.value);
												onMeshAddressChange(event?.target.value, field.name);
											}}
											disabled={flatGroup.isDisable}
										>
											{flatGroup.select.map((value, index) => {
												return (
													<MenuItem value={value} key={index}>
														{value}
													</MenuItem>
												);
											})}
										</Selectbox>
									)}
								/>
							</Grid>
							<Grid item xs={12}>
								<Typography variant="p4">將會設置為帳單地址及家+電話服務使用地址(如適用) </Typography>
							</Grid>
						</Grid>
					</StyledSection>
				)}

				{isAllowToSubmitService && (
					<>
						<StyledSection>
							<SectionTitle sectionIcon={sectionIconObject.applierInfo} title="申請人資料" />

							<Grid container spacing={2}>
								<Grid item xs={12} sm={6}>
									<Controller
										name="english_last_name"
										control={control}
										rules={formErrorMsgRules.english_last_name}
										render={({ field, fieldState }) => (
											<TextField label={'英文姓氏'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="english_first_name"
										control={control}
										rules={formErrorMsgRules.english_first_name}
										render={({ field, fieldState }) => (
											<TextField label={'英文名字'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="chinese_last_name"
										control={control}
										rules={formErrorMsgRules.chinese_last_name || {}}
										disabled={getValues('is_no_chinese_name')}
										render={({ field, fieldState }) => (
											<TextField label={'中文姓氏'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} disabled={field.disabled} />
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="chinese_first_name"
										control={control}
										rules={formErrorMsgRules.chinese_first_name || {}}
										disabled={getValues('is_no_chinese_name')}
										render={({ field, fieldState }) => (
											<TextField label={'中文名字'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} disabled={field.disabled} />
										)}
									/>
								</Grid>
								<Grid item xs={12}>
									<Controller
										name="is_no_chinese_name"
										control={control}
										render={({ field, fieldState }) => (
											<CheckboxGroup label="" labelId="" onChange={field.onChange}>
												<FormControlLabel checked={field.value} control={<Checkbox />} label="沒有中文姓名" />
											</CheckboxGroup>
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="ID_type"
										control={control}
										rules={formErrorMsgRules.ID_type || {}}
										render={({ field, fieldState }) => (
											<Selectbox label={'證件類別'} labelId="ID_type" placeholder={'testing'} fullWidth={true} value={field.value} onChange={field.onChange}>
												<MenuItem value={'HKID'}>香港身份證</MenuItem>
												<MenuItem value={'Macau Passport'}>澳門身份證 / 護照</MenuItem>
												<MenuItem value={'Other Passport'}>非中國/澳門護照</MenuItem>
												<MenuItem value={'Exit-Entry Permit'}>往來港澳通行證</MenuItem>
												<MenuItem value={'Chinese Passport'}>中國護照</MenuItem>
											</Selectbox>
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="ID_number"
										control={control}
										rules={formErrorMsgRules[getValues('ID_type')] || {}}
										render={({ field, fieldState }) => <IDField type={getValues('ID_type')} fullWidth={true} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="date_of_birth"
										control={control}
										rules={formErrorMsgRules.date_of_birth || {}}
										render={({ field, fieldState }) => (
											<SelectDate
												label={'出生日期'}
												labelId={'birth'}
												fullWidth={true}
												disableFuture={true}
												errMsg={fieldState.error?.message}
												maxDate={ageBiggerThan18}
												value={dayjs(field.value)}
												onChange={(value, context) => {
													let dateString = null;
													if (value) {
														dateString = value.format('YYYY-MM-DD');
													}
													field.onChange(dateString);
												}}
											/>
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="title"
										control={control}
										rules={formErrorMsgRules.title || {}}
										render={({ field, fieldState }) => (
											<RadioGroup label={'稱謂'} labelId="gender" row={true} value={field.value} onChange={field.onChange}>
												<FormControlLabel control={<Radio />} value="Mr." label="先生" />
												<FormControlLabel control={<Radio />} value="Mrs." label="女士" />
												<FormControlLabel control={<Radio />} value="Ms." label="小姐" />
											</RadioGroup>
										)}
									/>
								</Grid>

								<Grid item xs={12} sm={6}>
									<Controller
										name="contact_number"
										control={control}
										rules={formErrorMsgRules.contact_number || {}}
										render={({ field, fieldState }) => (
											<TextField type="tel" label={'聯絡電話'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="contact_email"
										control={control}
										rules={formErrorMsgRules.contact_email || {}}
										render={({ field, fieldState }) => (
											<TextField type="email" label={'電郵地址'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
										)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<Controller
										name="language"
										control={control}
										render={({ field, fieldState }) => (
											<RadioGroup label={'聯絡語言'} labelId="Contact Lang" row={true} value={field.value} onChange={field.onChange}>
												<FormControlLabel control={<Radio />} value="english" label="英語" />
												<FormControlLabel control={<Radio />} value="tchinese" label="中文" />
											</RadioGroup>
										)}
									/>
								</Grid>
								{/* <Grid item xs={12} sm={6}>
							<Controller name="SHKP_membership" control={control} render={({ field, fieldState }) => <TextField label={'新地會會員號碼'} fullWidth={true} helperText={''} {...field} />} />
						</Grid> */}

								{/* <Grid item container xs={12} spacing={1}>
									<Grid item xs={12}>
										<Typography variant="h7">單位地址</Typography>
									</Grid>
									<Grid item xs={12}>
										<Typography variant="p4">大埔優景里63號 Silicon Hill</Typography>
									</Grid>
								</Grid>
								<Grid item xs={6} sm={4}>
									<Controller
										name="address_tower"
										control={control}
										rules={formErrorMsgRules.address_tower || {}}
										render={({ field, fieldState }) => (
											<Selectbox
												label={'單位座數'}
												labelId="address_tower"
												placeholder={'請選擇'}
												fullWidth={true}
												defaultValue=""
												value={field.value}
												onChange={(event) => {
													field.onChange(event?.target.value);
													onMeshAddressChange(event?.target.value, field.name);
												}}
												disabled={towerGroup.isDisable}
											>
												{towerGroup.select.map((value, index) => {
													return (
														<MenuItem value={value} key={index}>
															{value}
														</MenuItem>
													);
												})}
											</Selectbox>
										)}
									/>
								</Grid>
								<Grid item xs={6} sm={4}>
									<Controller
										name="address_floor"
										control={control}
										rules={formErrorMsgRules.address_floor || {}}
										render={({ field, fieldState }) => (
											<Selectbox
												label={'單位樓層'}
												labelId="address_floor"
												placeholder={'請選擇'}
												fullWidth={true}
												defaultValue=""
												value={field.value}
												onChange={(event) => {
													field.onChange(event?.target.value);
													onMeshAddressChange(event?.target.value, field.name);
												}}
												disabled={floorGroup.isDisable}
											>
												{floorGroup.select.map((value, index) => {
													return (
														<MenuItem value={value} key={index}>
															{value}
														</MenuItem>
													);
												})}
											</Selectbox>
										)}
									/>
								</Grid>
								<Grid item xs={6} sm={4}>
									<Controller
										name="address_flat"
										control={control}
										rules={formErrorMsgRules.address_flat || {}}
										render={({ field, fieldState }) => (
											<Selectbox
												label={'單位室號'}
												labelId="address_flat"
												placeholder={'請選擇'}
												fullWidth={true}
												defaultValue=""
												value={field.value}
												onChange={(event) => {
													field.onChange(event?.target.value);
													onMeshAddressChange(event?.target.value, field.name);
												}}
												disabled={flatGroup.isDisable}
											>
												{flatGroup.select.map((value, index) => {
													return (
														<MenuItem value={value} key={index}>
															{value}
														</MenuItem>
													);
												})}
											</Selectbox>
										)}
									/>
								</Grid> 
								<Grid item xs={12}>
									<Typography variant="p4">將會設置為帳單地址及家+電話服務使用地址(如適用) </Typography>
								</Grid>*/}
								<Grid item container xs={12} spacing={1}>
									<Grid item xs={12}>
										<Typography variant="h7">上傳身份證</Typography>
									</Grid>
									<Grid item xs={12}>
										<Controller
											name="img_ID"
											control={control}
											rules={formErrorMsgRules.img_ID || {}}
											render={({ field, fieldState }) => (
												<UploadImage
													value={field.value}
													onUploadSuccess={(value) => {
														field.onChange(value);
													}}
												/>
											)}
										/>
									</Grid>
								</Grid>
							</Grid>
						</StyledSection>
						<StyledSection>
							<SectionTitle sectionIcon={sectionIconObject.serviceInfo} title="服務資料" />
							<Grid container spacing={5}>
								<input type="hidden" {...register('at_least_one_service', { required: { value: true, message: 'please select at least one service' } })} />

								{errors.at_least_one_service && (
									<Grid item xs={12} marginBottom={theme.spacing(-5)}>
										<FormHelperText className="Mui-error">{errors.at_least_one_service.message}</FormHelperText>
									</Grid>
								)}

								{appliedService.mobile == true && (
									<Grid item xs={12} md={4}>
										<Box display="flex" flexDirection="column" alignItems="flex-start" height="100%">
											<Controller
												name="mobile_trial.0.is_disabled"
												control={control}
												render={({ field, fieldState }) => (
													<CheckboxGroup label="" labelId="" onChange={field.onChange}>
														<FormControlLabel checked={field.value} control={<Checkbox />} label={<>不登記</>} />
													</CheckboxGroup>
												)}
											/>

											<ServiceInfoCard
												icon={<Img style={{ maxWidth: '165px', width: '100%' }} src={intl.formatMessage({ id: 'form.serviceIcon.mobile' })} />}
												isDisable={getValues('mobile_trial.0.is_disabled')}
											>
												<Grid item container xs={12} spacing={2}>
													<input type="hidden" {...register('mobile_trial.0.offer', { value: '' })} />
													{!isClubhouse && <input type="hidden" {...register('mobile_trial.0.pending_activation', { value: 'yes' })} />}
													<Grid item xs={12}>
														<Controller
															name="mobile_trial.0.pending_activation_date"
															control={control}
															rules={formErrorMsgRules?.mobile_trial?.pending_activation_date || {}}
															disabled={getValues('mobile_trial.0.is_disabled')}
															render={({ field, fieldState }) => (
																<SelectDate
																	label={'服務生效日期'}
																	labelId={'mobile_trial.pending_activation_date'}
																	fullWidth={true}
																	errMsg={fieldState.error?.message}
																	value={dayjs(field.value)}
																	disablePast={true}
																	shouldDisableDate={(date) => {
																		const formatedDate = date.format('YYYY-MM-DD');
																		const found = mobileWorkingDay.findIndex((v) => {
																			return v === formatedDate;
																		});
																		return found == -1;
																	}}
																	onChange={(value, context) => {
																		let dateString = null;
																		if (value) {
																			dateString = value.format('YYYY-MM-DD');
																		}
																		field.onChange(dateString);
																	}}
																/>
															)}
														/>
													</Grid>

													{isClubhouse && (
														<>
															{/* <Grid item xs={12}>
													<Controller
														name="mobile_trial.pending_activation"
														control={control}
														render={({ field, fieldState }) => (
															<CheckboxGroup
																label=""
																labelId=""
																onChange={(e) => {
																	field.onChange((e.target as HTMLInputElement).checked ? 'no' : 'yes');
																}}
															>
																<FormControlLabel checked={field.value == 'no'} control={<Checkbox />} label={<>Active Now?</>} />
															</CheckboxGroup>
														)}
													/>
												</Grid> */}
															<Grid item xs={12}>
																<Controller
																	name="mobile_trial.0.sim"
																	control={control}
																	rules={formErrorMsgRules?.mobile_trial?.sim || {}}
																	disabled={getValues('mobile_trial.0.is_disabled')}
																	render={({ field, fieldState }) => (
																		<Scancode
																			label={'SIM卡號'}
																			fullWidth={true}
																			helperText={''}
																			errMsg={fieldState.error?.message}
																			value={field.value}
																			onScanDone={(value) => {
																				field.onChange(value);
																			}}
																			onChange={field.onChange}
																		/>
																	)}
																/>
															</Grid>
														</>
													)}

													<Grid item xs={12}>
														<Typography variant="p5">手機SIM卡均為實體卡，號碼將會隨機發放</Typography>
													</Grid>
												</Grid>
											</ServiceInfoCard>
										</Box>
									</Grid>
								)}

								{appliedService.H5GBB == true && (
									<Grid item xs={12} md={4}>
										<Box display="flex" flexDirection="column" alignItems="flex-start" height="100%">
											<Controller
												name="H5GBB_trial.0.is_disabled"
												control={control}
												render={({ field, fieldState }) => (
													<CheckboxGroup label="" labelId="" onChange={field.onChange}>
														<FormControlLabel checked={field.value} control={<Checkbox name={'serviceDisable'} />} label={<>不登記</>} />
													</CheckboxGroup>
												)}
											/>
											<ServiceInfoCard
												icon={<Img style={{ maxWidth: '200px', width: '100%' }} src={intl.formatMessage({ id: 'form.serviceIcon.h5gbb' })} />}
												isDisable={getValues('H5GBB_trial.0.is_disabled')}
											>
												<Grid item container xs={12} spacing={2}>
													<input type="hidden" {...register('H5GBB_trial.0.offer', { value: '' })} />
													{!isClubhouse && <input type="hidden" {...register('H5GBB_trial.0.pending_activation', { value: 'yes' })} />}

													{/* <Grid item xs={12}>
											<Controller
												name="H5GBB_trial.promo_code"
												control={control}
												rules={formErrorMsgRules?.H5GBB_trial?.promo_code || {}}
												render={({ field, fieldState }) => (
													<TextField label={'兌惠碼'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
												)}
											/>
										</Grid> */}
													<Grid item xs={12}>
														<Controller
															name="H5GBB_trial.0.pending_activation_date"
															control={control}
															rules={formErrorMsgRules?.H5GBB_trial?.pending_activation_date || {}}
															disabled={getValues('H5GBB_trial.0.is_disabled')}
															render={({ field, fieldState }) => (
																<SelectDate
																	label={'服務生效日期'}
																	labelId={'H5GBB_trial.pending_activation_date'}
																	fullWidth={true}
																	errMsg={fieldState.error?.message}
																	value={dayjs(field.value)}
																	disablePast={true}
																	shouldDisableDate={(date) => {
																		const formatedDate = date.format('YYYY-MM-DD');
																		const found = h5gbbWorkingDay.findIndex((v) => {
																			return v === formatedDate;
																		});
																		return found == -1;
																	}}
																	onChange={(value, context) => {
																		let dateString = null;
																		if (value) {
																			dateString = value.format('YYYY-MM-DD');
																		}
																		field.onChange(dateString);
																		setValue('HPP_trial.0.pending_activation_date', dateString || '');
																	}}
																/>
															)}
														/>
													</Grid>

													{isClubhouse && (
														<>
															{/* <Grid item xs={12}>
													<Controller
														name="H5GBB_trial.pending_activation"
														control={control}
														render={({ field, fieldState }) => (
															<CheckboxGroup
																label=""
																labelId=""
																onChange={(e) => {
																	field.onChange((e.target as HTMLInputElement).checked ? 'no' : 'yes');
																}}
															>
																<FormControlLabel checked={field.value == 'no'} control={<Checkbox />} label={<>Active Now?</>} />
															</CheckboxGroup>
														)}
													/>
												</Grid> */}
															<Grid item xs={12}>
																<Controller
																	name="H5GBB_trial.0.sim"
																	control={control}
																	rules={formErrorMsgRules?.mobile_trial?.sim || {}}
																	disabled={getValues('H5GBB_trial.0.is_disabled')}
																	render={({ field, fieldState }) => (
																		<Scancode
																			label={'SIM卡號'}
																			fullWidth={true}
																			helperText={''}
																			errMsg={fieldState.error?.message}
																			value={field.value}
																			onScanDone={(value) => {
																				field.onChange(value);
																			}}
																			onChange={field.onChange}
																		/>
																	)}
																/>
															</Grid>
															<Grid item xs={12}>
																<Controller
																	name="H5GBB_trial.0.main_IMEI"
																	control={control}
																	rules={formErrorMsgRules?.mobile_trial?.sim || {}}
																	disabled={getValues('H5GBB_trial.0.is_disabled')}
																	render={({ field, fieldState }) => (
																		<Scancode
																			label={'路由器 IMEI'}
																			fullWidth={true}
																			helperText={''}
																			errMsg={fieldState.error?.message}
																			value={field.value}
																			onScanDone={(value) => {
																				field.onChange(value);
																			}}
																			onChange={field.onChange}
																		/>
																	)}
																/>
															</Grid>
														</>
													)}
													<Grid item xs={12}>
														<Typography variant="p6" color={theme.palette.grey[80]}>
															你可同時免費增添以下服務：
															<br />
															(Home 5G寬頻服務及「家+電話」服務須同時生效)
														</Typography>
													</Grid>
													<Grid item xs={12}>
														{meshRouterTotal > 0 && (
															<Grid item container xs={12} spacing={1} marginBottom={getValues('H5GBB_trial.0.mesh_required') == 'yes' ? theme.spacing(2) : 0}>
																<Grid item xs={12}>
																	<Controller
																		name="H5GBB_trial.0.mesh_required"
																		control={control}
																		render={({ field, fieldState }) => (
																			<CheckboxGroup
																				label=""
																				labelId=""
																				onChange={(e) => {
																					field.onChange((e.target as HTMLInputElement).checked ? 'yes' : 'no');
																				}}
																			>
																				<FormControlLabel checked={field.value == 'yes'} control={<Checkbox />} label={<>Mesh Wifi 路由器</>} />
																			</CheckboxGroup>
																		)}
																	/>
																</Grid>
																{getValues('H5GBB_trial.0.mesh_required') == 'yes' && isClubhouse && (
																	<Grid item xs={12}>
																		<Controller
																			name="H5GBB_trial.0.mesh_serial_num"
																			control={control}
																			rules={formErrorMsgRules?.H5GBB_trial?.mesh_serial_num || {}}
																			disabled={getValues('H5GBB_trial.0.is_disabled')}
																			render={({ field, fieldState }) => (
																				<Scancode
																					label={'Mesh Wifi路由器序號'}
																					fullWidth={true}
																					helperText={''}
																					errMsg={fieldState.error?.message}
																					value={field.value}
																					onScanDone={(value) => {
																						field.onChange(value);
																					}}
																					onChange={field.onChange}
																				/>
																			)}
																		/>
																	</Grid>
																)}
															</Grid>
														)}

														<Grid item container xs={12} spacing={1}>
															<Grid item xs={12}>
																<Controller
																	name="HPP_trial.0.hpp_required"
																	control={control}
																	disabled={getValues('H5GBB_trial.0.is_disabled')}
																	render={({ field, fieldState }) => (
																		<CheckboxGroup
																			label=""
																			labelId=""
																			onChange={(e) => {
																				field.onChange((e.target as HTMLInputElement).checked ? 'yes' : 'no');
																			}}
																		>
																			<FormControlLabel
																				checked={field.value == 'yes'}
																				control={<Checkbox />}
																				label={
																					<>
																						「家+電話」服務
																						<br />
																						<Typography variant="p5">將隨機獲得分配一個電話號碼</Typography>
																					</>
																				}
																			/>
																		</CheckboxGroup>
																	)}
																/>
															</Grid>
															{getValues('HPP_trial.0.hpp_required') == 'yes' && !isClubhouse && (
																<>
																	<input type="hidden" {...register('HPP_trial.0.pending_activation', { value: 'yes' })} />
																	<input type="hidden" {...register('HPP_trial.0.pending_activation_date', { value: getValues('H5GBB_trial.0.pending_activation_date') })} />
																</>
															)}

															{getValues('HPP_trial.0.hpp_required') == 'yes' && isClubhouse && (
																<>
																	<Grid item xs={12}>
																		<Controller
																			name="HPP_trial.0.sim"
																			control={control}
																			rules={formErrorMsgRules?.HPP_trial?.sim || {}}
																			disabled={getValues('H5GBB_trial.0.is_disabled')}
																			render={({ field, fieldState }) => (
																				<Scancode
																					label={'家+電話SIM卡號'}
																					fullWidth={true}
																					helperText={''}
																					errMsg={fieldState.error?.message}
																					value={field.value}
																					onScanDone={(value) => {
																						field.onChange(value);
																					}}
																					onChange={field.onChange}
																				/>
																			)}
																		/>
																	</Grid>
																	<Grid item xs={12}>
																		<Controller
																			name="HPP_trial.0.main_IMEI"
																			control={control}
																			rules={formErrorMsgRules?.HPP_trial?.main_IMEI || {}}
																			disabled={getValues('H5GBB_trial.0.is_disabled')}
																			render={({ field, fieldState }) => (
																				<Scancode
																					label={'家+電話 IMEI'}
																					fullWidth={true}
																					helperText={''}
																					errMsg={fieldState.error?.message}
																					value={field.value}
																					onScanDone={(value) => {
																						field.onChange(value);
																					}}
																					onChange={field.onChange}
																				/>
																			)}
																		/>
																	</Grid>
																</>
															)}
														</Grid>
													</Grid>
												</Grid>
											</ServiceInfoCard>
										</Box>
									</Grid>
								)}

								{appliedService.FBB == true && (
									<Grid item xs={12} md={4}>
										<Box display="flex" flexDirection="column" alignItems="flex-start" height="100%">
											<Controller
												name="FBB_trial.0.is_disabled"
												control={control}
												render={({ field, fieldState }) => (
													<CheckboxGroup label="" labelId="" onChange={field.onChange}>
														<FormControlLabel checked={field.value} control={<Checkbox />} label={<>不登記</>} />
													</CheckboxGroup>
												)}
											/>
											<ServiceInfoCard
												icon={<Img style={{ maxWidth: '165px', width: '100%' }} src={intl.formatMessage({ id: 'form.serviceIcon.fbb' })} />}
												isDisable={getValues('FBB_trial.0.is_disabled')}
											>
												<Grid item container xs={12} spacing={2}>
													<input type="hidden" {...register('FBB_trial.0.offer', { value: '' })} />
													<Grid item xs={12}>
														<Controller
															name="FBB_trial.0.installation_date"
															control={control}
															rules={formErrorMsgRules?.FBB_trial?.installation_date || {}}
															disabled={getValues('FBB_trial.0.is_disabled')}
															render={({ field, fieldState }) => (
																<SelectDate
																	label={'首選安裝日期'}
																	labelId={'FBB_trial.installation_date'}
																	fullWidth={true}
																	errMsg={fieldState.error?.message}
																	value={dayjs(field.value)}
																	disablePast={true}
																	shouldDisableDate={(date) => {
																		const formatedDate = date.format('YYYY-MM-DD');
																		const found = fbbInstallWorkingDay.findIndex((v, i) => {
																			return v === formatedDate;
																		});
																		return found == -1;
																	}}
																	onChange={(value, context) => {
																		let dateString = null;
																		if (value) {
																			dateString = value.format('YYYY-MM-DD');
																		}
																		field.onChange(dateString);
																		setValue('FBB_trial.0.activation_date', dateString || '');
																		setValue('FBB_trial.0.installation_timeslot', '');
																	}}
																/>
															)}
														/>
													</Grid>
													<Grid item xs={12}>
														<Controller
															name="FBB_trial.0.installation_timeslot"
															control={control}
															rules={formErrorMsgRules?.FBB_trial?.installation_timeslot || {}}
															disabled={getValues('FBB_trial.0.is_disabled')}
															render={({ field, fieldState }) => (
																<Selectbox
																	onChange={field.onChange}
																	label={'首選安裝時段'}
																	labelId="FBB_trial.installation_timeslot"
																	placeholder={'請選擇'}
																	fullWidth={true}
																	value={getValues('FBB_trial.0.installation_timeslot') || ''}
																>
																	{fbbWorkingTime.map((value, index) => {
																		const isDisable = getValues('FBB_trial.0.installation_date') == fbbInstallWorkingDay[0] && index == 0;

																		if (isDisable) {
																			return '';
																		}
																		return (
																			<MenuItem value={value} key={index}>
																				{value}
																			</MenuItem>
																		);
																	})}
																</Selectbox>
															)}
														/>
													</Grid>
													<Grid item xs={12}>
														<Grid item container xs={12} spacing={1} marginBottom={getValues('FBB_trial.0.same_as_applier') == 'no' ? theme.spacing(2) : 0}>
															<Grid item xs={12}>
																<Controller
																	name="FBB_trial.0.same_as_applier"
																	control={control}
																	disabled={getValues('FBB_trial.0.is_disabled')}
																	render={({ field, fieldState }) => (
																		<CheckboxGroup
																			label=""
																			labelId=""
																			errMsg={''}
																			onChange={(e) => {
																				field.onChange((e.target as HTMLInputElement).checked ? 'yes' : 'no');
																			}}
																		>
																			<FormControlLabel checked={field.value == 'yes'} control={<Checkbox />} label={'安裝時聯絡人與申請人相同'} />
																		</CheckboxGroup>
																	)}
																/>
															</Grid>
															{getValues('FBB_trial.0.same_as_applier') == 'no' && (
																<>
																	<Grid item xs={12}>
																		<Controller
																			name="FBB_trial.0.installation_contact"
																			control={control}
																			rules={formErrorMsgRules?.FBB_trial?.installation_contact || {}}
																			disabled={getValues('FBB_trial.0.is_disabled')}
																			render={({ field, fieldState }) => (
																				<TextField
																					label={'聯絡人姓名'}
																					fullWidth={true}
																					helperText={''}
																					errMsg={fieldState.error?.message}
																					value={field.value}
																					onChange={field.onChange}
																				/>
																			)}
																		/>
																	</Grid>
																	<Grid item xs={12}>
																		<Controller
																			name="FBB_trial.0.installation_contact_number"
																			control={control}
																			rules={formErrorMsgRules?.FBB_trial?.installation_contact_number || {}}
																			disabled={getValues('FBB_trial.0.is_disabled')}
																			render={({ field, fieldState }) => (
																				<TextField
																					label={'聯絡人電話'}
																					fullWidth={true}
																					helperText={''}
																					errMsg={fieldState.error?.message}
																					value={field.value}
																					onChange={field.onChange}
																				/>
																			)}
																		/>
																	</Grid>
																</>
															)}
														</Grid>
														<Grid item container xs={12} spacing={1}>
															<Grid item xs={12}>
																<Controller
																	name="FBB_trial.0.activation_now"
																	control={control}
																	disabled={getValues('FBB_trial.0.is_disabled')}
																	render={({ field, fieldState }) => (
																		<CheckboxGroup
																			label=""
																			labelId=""
																			errMsg={''}
																			onChange={(e) => {
																				field.onChange((e.target as HTMLInputElement).checked ? 'yes' : 'no');
																			}}
																		>
																			<FormControlLabel checked={field.value == 'yes'} control={<Checkbox />} label={'安裝完成後生效服務'} />
																		</CheckboxGroup>
																	)}
																/>
															</Grid>
															{getValues('FBB_trial.0.activation_now') == 'no' && (
																<Grid item xs={12}>
																	<Controller
																		name="FBB_trial.0.activation_date"
																		control={control}
																		rules={formErrorMsgRules?.FBB_trial?.activation_date || {}}
																		disabled={getValues('FBB_trial.0.is_disabled')}
																		render={({ field, fieldState }) => (
																			<SelectDate
																				label={'服務生效日期'}
																				labelId={'FBB_trial.activation_date'}
																				fullWidth={true}
																				errMsg={fieldState.error?.message}
																				value={dayjs(field.value)}
																				disablePast={true}
																				minDate={dayjs(getValues('FBB_trial.0.installation_date'))}
																				shouldDisableDate={(date) => {
																					const formatedDate = date.format('YYYY-MM-DD');
																					const minDate = getValues('FBB_trial.0.installation_date');
																					if (minDate) {
																						const after180D = dayjs(minDate).add(180, 'day').format('YYYY-MM-DD');

																						return dayjs(formatedDate).isBefore(dayjs(minDate)) || dayjs(formatedDate).isAfter(dayjs(after180D));
																					} else {
																						return false;
																					}
																				}}
																				onChange={(value, context) => {
																					let dateString = null;
																					if (value) {
																						dateString = value.format('YYYY-MM-DD');
																					}
																					field.onChange(dateString);
																				}}
																			/>
																		)}
																	/>
																</Grid>
															)}
														</Grid>
													</Grid>
												</Grid>
											</ServiceInfoCard>
										</Box>
									</Grid>
								)}
							</Grid>
						</StyledSection>

						{(appliedService.mobile == true || appliedService.H5GBB == true) && !isClubhouse && (
							<StyledSection>
								<SectionTitle sectionIcon={sectionIconObject.deliveryInfo} title="送貨安排" />
								<Grid item container xs={12} spacing={2}>
									<Grid item xs={12}>
										<Typography variant="h7">送貨物品</Typography>
										<Typography variant="p4">
											<StyledList>
												{appliedService.mobile == true && <StyledListItem>實體SIM卡</StyledListItem>}
												{appliedService.H5GBB == true && getValues('H5GBB_trial.0.mesh_required') == 'yes' && <StyledListItem>Mesh Wifi 路由器</StyledListItem>}
												{appliedService.H5GBB == true && getValues('HPP_trial.0.hpp_required') == 'yes' && <StyledListItem>「家+電話」</StyledListItem>}
											</StyledList>
										</Typography>
									</Grid>
									<Grid item xs={12}>
										<Controller
											name="delivery.not_reg_address"
											control={control}
											render={({ field, fieldState }) => (
												<CheckboxGroup
													label=""
													labelId=""
													onChange={(e) => {
														field.onChange((e.target as HTMLInputElement).checked ? 'no' : 'yes');
													}}
												>
													<FormControlLabel checked={field.value == 'no'} control={<Checkbox />} label={'送貨地址與單位地址相同'} />
												</CheckboxGroup>
											)}
										/>
									</Grid>

									{getValues('delivery.not_reg_address') == 'yes' && (
										<>
											<Grid item xs={6}>
												<Controller
													name="delivery.contact"
													control={control}
													rules={formErrorMsgRules?.delivery?.contact || {}}
													render={({ field, fieldState }) => (
														<TextField label={'收件人英文姓名'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
													)}
												/>
											</Grid>
											<Grid item xs={6}>
												<Controller
													name="delivery.contact_number"
													control={control}
													rules={formErrorMsgRules?.delivery?.contact_number || {}}
													render={({ field, fieldState }) => (
														<TextField type="tel" label={'收件人聯絡電話'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
													)}
												/>
											</Grid>
											<Grid item xs={4}>
												<Controller
													name="delivery.address_tower"
													control={control}
													rules={formErrorMsgRules?.delivery?.address_tower || {}}
													render={({ field, fieldState }) => (
														<TextField label={'單位座數英文'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
													)}
												/>
											</Grid>
											<Grid item xs={4}>
												<Controller
													name="delivery.address_floor"
													control={control}
													rules={formErrorMsgRules?.delivery?.address_floor || {}}
													render={({ field, fieldState }) => (
														<TextField label={'單位樓層英文'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
													)}
												/>
											</Grid>
											<Grid item xs={4}>
												<Controller
													name="delivery.address_flat"
													control={control}
													rules={formErrorMsgRules?.delivery?.address_flat || {}}
													render={({ field, fieldState }) => (
														<TextField label={'單位室號英文'} fullWidth={true} helperText={''} errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
													)}
												/>
											</Grid>
											<Grid item xs={12}>
												<Controller
													name="delivery.address_estate"
													control={control}
													rules={formErrorMsgRules?.delivery?.address_estate || {}}
													render={({ field, fieldState }) => (
														<TextField
															label={'送貨地址英文'}
															fullWidth={true}
															helperText={''}
															placeholder="大廈名稱英文"
															errMsg={fieldState.error?.message}
															value={field.value}
															onChange={field.onChange}
														/>
													)}
												/>
												<Controller
													name="delivery.address_street"
													control={control}
													rules={formErrorMsgRules?.delivery?.address_street || {}}
													render={({ field, fieldState }) => (
														<TextField
															label={''}
															fullWidth={true}
															helperText={''}
															placeholder="屋苑、街道名稱英文"
															errMsg={fieldState.error?.message}
															value={field.value}
															onChange={field.onChange}
														/>
													)}
												/>
												<Controller
													name="delivery.address_district"
													control={control}
													rules={formErrorMsgRules?.delivery?.address_district || {}}
													render={({ field, fieldState }) => (
														<TextField label={''} fullWidth={true} helperText={''} placeholder="地區英文" errMsg={fieldState.error?.message} value={field.value} onChange={field.onChange} />
													)}
												/>
											</Grid>
										</>
									)}
								</Grid>
							</StyledSection>
						)}
					</>
				)}

				{!isAllowToSubmitService && !appliedService.mobile && !appliedService.H5GBB && !appliedService.FBB && (
					<Grid container>
						<Grid item xs={12}>
							<Typography variant="p4" className="Mui-error">
								{errors?.api_error?.message}
							</Typography>
						</Grid>
					</Grid>
				)}
			</Container>

			<LoadingScreen />
			{process.env.NODE_ENV == 'development' && <DevTool control={control} />}
		</StyledFormWrapper>
	);
}

export default Form;
