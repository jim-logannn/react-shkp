// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useCallback, useContext, useEffect, useState } from 'react';

// intl
import { useIntl } from 'react-intl';
import { styled, useTheme } from 'styled-components';
import Container from '@/layout/Container';
import DoneIcon from '@mui/icons-material/Done';
import { FormControlLabel, Grid, Typography } from '@mui/material';
import SectionTitle, { StyledSectionTitleIcon } from '@/components/FormSectionTitle';
import ApplicationContext, { Channel } from '@smt/context/ApplicationContext';
import { ApplyService, FormValues } from '@/type/Form';
import { Controller, useForm, useFormState, useWatch } from 'react-hook-form';
import { DevTool } from '@hookform/devtools';
import Label from '@smt/formElement/Label';
import ReviewField from '@smt/formElement/ReviewField';
import dayjs from 'dayjs';
import Img from '@/components/img/Img';
import ServiceInfoCard from '@/components/ServiceInfoCard/ServiceInfoCard';
import CheckboxGroup from '@smt/formElement/CheckboxGroup';
import Checkbox from '@smt/formElement/Checkbox';
import getFormErrorMsg from '@/context/FormErrorMsgRules';
import { idFieldName } from '@smt/formElement/IDField';

const StyledFormWrapper = styled.div(({ theme }) => ({
	paddingLeft: theme.spacing(2),
	paddingRight: theme.spacing(2),
	paddingTop: theme.spacing(5),
	paddingBottom: theme.spacing(5),
}));

const StyledSection = styled.div(({ theme }) => ({
	width: '100%',
	marginBottom: theme.spacing(4),
	'&:last-child': {
		marginBottom: 0,
	},
}));

interface PageReviewProp {
	formData: FormValues;
	appliedService: ApplyService;
	setFormData: (data: FormValues) => void;
	onFormValidated: (isAllow: boolean) => void;
}

function Review({ formData, appliedService, setFormData, onFormValidated }: PageReviewProp) {
	const theme = useTheme();
	const intl = useIntl();
	const applicationContext = useContext(ApplicationContext);

	//get data from app context
	const channel: Channel = applicationContext?.channel == 'clubhouse' ? 'clubhouse' : 'self-help';

	//page var
	const isClubhouse = channel == 'clubhouse';

	//react hook form control
	const { control, register, setValue, getValues, handleSubmit, setError, trigger } = useForm<FormValues>({
		defaultValues: {
			...formData,
		},
		mode: 'onChange',
	});
	const { isValid: isFormValid, isValidating } = useFormState({ control });
	const watchForm = useWatch({ control: control });
	const formErrorMsgRules: any = getFormErrorMsg();

	//section title
	const sectionIconObject = {
		staff: <StyledSectionTitleIcon color={theme.palette.primary.main}>0</StyledSectionTitleIcon>,
		applierInfo: <StyledSectionTitleIcon color={theme.palette.primary.main}>1</StyledSectionTitleIcon>,
		serviceInfo: <StyledSectionTitleIcon color={theme.palette.primary.main}>2</StyledSectionTitleIcon>,
		deliveryInfo: <StyledSectionTitleIcon color={theme.palette.primary.main}>3</StyledSectionTitleIcon>,
		done: (
			<StyledSectionTitleIcon color={theme.palette.green.main}>
				<DoneIcon />
			</StyledSectionTitleIcon>
		),
	};

	useEffect(() => {
		onFormValidated(getValues('agree_tnc') || false);
	}, []);

	useEffect(() => {
		if (!isValidating) {
			if (isFormValid) {
				handleSubmit((data) => {
					setFormData(data);
				})();
			}
			onFormValidated(isFormValid);
		}
	}, [isValidating, isFormValid, watchForm]);

	return (
		<StyledFormWrapper>
			<Container>
				{channel == 'clubhouse' && (
					<StyledSection>
						<SectionTitle sectionIcon={sectionIconObject.done} title="職員專用" />
						<Grid container marginBottom={theme.spacing(2)}>
							<Grid item xs={12}>
								<ReviewField label={'員工編號'} value={formData.staff_ID} />
							</Grid>
						</Grid>
					</StyledSection>
				)}

				<StyledSection>
					<SectionTitle sectionIcon={sectionIconObject.done} title="申請人資料" />

					<Grid container spacing={2}>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'英文姓氏'} value={formData.english_last_name} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'英文名字'} value={formData.english_first_name} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'中文姓氏'} value={formData.chinese_last_name} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'中文名字'} value={formData.chinese_first_name} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'證件類別'} value={idFieldName(formData.ID_type)} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={idFieldName(formData.ID_type)} value={formData.ID_number} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'出生日期'} value={dayjs(formData.date_of_birth).format('YYYY-MM-DD')} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'稱謂'} value={formData.title} />
						</Grid>

						<Grid item xs={12} sm={6}>
							<ReviewField label={'聯絡電話'} value={formData.contact_number} />
						</Grid>
						<Grid item xs={12} sm={6}>
							<ReviewField label={'電郵地址'} value={formData.contact_email} />
						</Grid>
						{/* <Grid item xs={12} sm={6}>
							<Controller name="SHKP_membership" control={control} render={({ field, fieldState }) => <TextField label={'新地會會員號碼'} fullWidth={true} helperText={''} {...field} />} />
						</Grid> */}

						<Grid item container xs={12} spacing={1}>
							<Grid item xs={12}>
								<Typography variant="h7">單位地址</Typography>
							</Grid>
							<Grid item xs={12}>
								<Typography variant="p4">
									大埔優景里63號 Silicon Hill {formData.address_block}座 {formData.address_floor}樓 {formData.address_flat}室
								</Typography>
							</Grid>
						</Grid>
						{/* <Grid item xs={6} sm={4}>
							<ReviewField label={'單位座數'} value={formData.address_block} />
						</Grid>
						<Grid item xs={6} sm={4}>
							<ReviewField label={'單位樓層'} value={formData.address_floor} />
						</Grid>
						<Grid item xs={6} sm={4}>
							<ReviewField label={'單位室號'} value={formData.address_flat} />
						</Grid> */}
						<Grid item xs={12}>
							<Typography variant="p4">將會設置為帳單地址及家+電話服務使用地址(如適用) </Typography>
						</Grid>
						<Grid item container xs={12} spacing={1}>
							<Grid item xs={12}>
								<Typography variant="h7">身份證</Typography>
							</Grid>
							<Grid item xs={12}>
								<ReviewField label={''}>
									<Img src={formData.img_ID} style={{ width: '100%', maxWidth: '250px' }} />
								</ReviewField>
							</Grid>
						</Grid>
					</Grid>
				</StyledSection>
				<StyledSection>
					<SectionTitle sectionIcon={sectionIconObject.done} title="服務資料" />

					<Grid container spacing={5}>
						{appliedService.mobile == true && !formData?.mobile_trial?.[0].is_disabled && (
							<Grid item xs={12} md={4}>
								<ServiceInfoCard icon={<Img style={{ maxWidth: '165px', width: '100%' }} src={intl.formatMessage({ id: 'form.serviceIcon.mobile' })} />}>
									<Grid item container xs={12} spacing={2}>
										<Grid item xs={12}>
											<ReviewField label={'服務生效日期'} value={dayjs(formData?.mobile_trial?.[0].pending_activation_date).format('YYYY-MM-DD')} />
										</Grid>

										{isClubhouse && (
											<>
												<Grid item xs={12}>
													<ReviewField label={'SIM卡號'} value={formData?.mobile_trial?.[0].sim} />
												</Grid>
											</>
										)}
										<Grid item xs={12}>
											<Typography variant="p5">手機SIM卡均為實體卡，號碼將會隨機發放</Typography>
										</Grid>
									</Grid>
								</ServiceInfoCard>
							</Grid>
						)}

						{appliedService.H5GBB == true && !formData?.H5GBB_trial?.[0].is_disabled && (
							<Grid item xs={12} md={4}>
								<ServiceInfoCard icon={<Img style={{ maxWidth: '200px', width: '100%' }} src={intl.formatMessage({ id: 'form.serviceIcon.h5gbb' })} />}>
									<Grid item container xs={12} spacing={2}>
										<Grid item xs={12}>
											<ReviewField label={'服務生效日期'} value={dayjs(formData?.H5GBB_trial?.[0].pending_activation_date).format('YYYY-MM-DD')} />
										</Grid>

										{isClubhouse && (
											<>
												<Grid item xs={12}>
													<ReviewField label={'SIM卡號'} value={formData?.H5GBB_trial?.[0].sim} />
												</Grid>
												<Grid item xs={12}>
													<ReviewField label={'路由器 IMEI'} value={formData?.H5GBB_trial?.[0].main_IMEI} />
												</Grid>
											</>
										)}
										{/* <Grid item xs={12}>
											<ReviewField label={'Mesh Wifi 路由器'} value={formData?.H5GBB_trial?.[0].mesh_required == 'yes' ? '需要' : '不需要'} />
										</Grid> */}
										{formData?.H5GBB_trial?.[0].mesh_required == 'yes' && isClubhouse && (
											<Grid item xs={12}>
												<ReviewField label={'Mesh Wifi路由器序號'} value={formData?.H5GBB_trial?.[0].mesh_serial_num} />
											</Grid>
										)}
										<Grid item xs={12}>
											<ReviewField label={'「家+電話」服務'} value={formData?.HPP_trial?.[0].hpp_required == 'yes' ? '需要' : '不需要'} />
										</Grid>
										{formData?.HPP_trial?.[0].hpp_required == 'yes' && isClubhouse && (
											<>
												<Grid item xs={12}>
													<ReviewField label={'家+電話SIM卡號'} value={formData?.HPP_trial?.[0].sim} />
												</Grid>
												<Grid item xs={12}>
													<ReviewField label={'家+電話 IMEI'} value={formData?.HPP_trial?.[0].main_IMEI} />
												</Grid>
											</>
										)}
									</Grid>
								</ServiceInfoCard>
							</Grid>
						)}

						{appliedService.FBB == true && !formData?.FBB_trial?.[0].is_disabled && (
							<Grid item xs={12} md={4}>
								<ServiceInfoCard icon={<Img style={{ maxWidth: '165px', width: '100%' }} src={intl.formatMessage({ id: 'form.serviceIcon.fbb' })} />}>
									<Grid item container xs={12} spacing={2}>
										<Grid item xs={12}>
											<ReviewField label={'服務生效日期'} value={dayjs(formData?.FBB_trial?.[0].installation_date).format('YYYY-MM-DD')} />
										</Grid>
										<Grid item xs={12}>
											<ReviewField label={'首選安裝時段'} value={formData?.FBB_trial?.[0].installation_timeslot} />
										</Grid>
										<Grid item xs={12}>
											<ReviewField label={'安裝時聯絡人與申請人相同'} value={formData?.FBB_trial?.[0].same_as_applier == 'yes' ? '是' : '不是'} />
										</Grid>
										<Grid item xs={12}>
											<ReviewField label={'聯絡人姓名'} value={formData?.FBB_trial?.[0].installation_contact} />
										</Grid>
										<Grid item xs={12}>
											<ReviewField label={'聯絡人電話'} value={formData?.FBB_trial?.[0].installation_contact_number} />
										</Grid>
										<Grid item xs={12}>
											<ReviewField label={'安裝完成後生效服務'} value={formData?.FBB_trial?.[0].activation_now == 'yes' ? '是' : '不是'} />
										</Grid>
										<Grid item xs={12}>
											<ReviewField label={'服務生效日期'} value={dayjs(formData?.FBB_trial?.[0].activation_date).format('YYYY-MM-DD')} />
										</Grid>
									</Grid>
								</ServiceInfoCard>
							</Grid>
						)}
					</Grid>
				</StyledSection>

				{(appliedService.mobile == true || appliedService.H5GBB == true) && !isClubhouse && (
					<StyledSection>
						<SectionTitle sectionIcon={sectionIconObject.done} title="送貨安排" />
					</StyledSection>
				)}

				<StyledSection>
					<SectionTitle sectionIcon={''} title="條款及細則" />
					<Grid container spacing={2}>
						<Grid item xs={12}>
							<Controller
								name="agree_tnc"
								control={control}
								rules={formErrorMsgRules.agree_tnc || {}}
								render={({ field, fieldState }) => (
									<CheckboxGroup label="" labelId="" onChange={field.onChange}>
										<FormControlLabel
											checked={field.value}
											control={<Checkbox />}
											label={
												<span
													dangerouslySetInnerHTML={{
														__html: '我已閱讀並同意條款及細則、<a href="/other/tchinese/TC-Move-In-Privileges.pdf" target="_blank">「SmarTone 入伙禮遇」條款及細則</a>(如適用)及<a href="/other/tchinese/PrivacyPolicy.pdf" target="_blank">私隱政策聲明</a>。',
													}}
												></span>
											}
										/>
									</CheckboxGroup>
								)}
							/>
						</Grid>
						<Grid item xs={12}>
							<Typography variant="p4">本人不同意接收來自下列任何有關獎賞及優惠的直接促銷推廣訊息:</Typography>
						</Grid>

						<Grid item xs={12}>
							<Grid container spacing={0}>
								<Grid item xs={12}>
									<Controller
										name="dmflag_consent"
										control={control}
										render={({ field, fieldState }) => (
											<CheckboxGroup
												label=""
												labelId=""
												onChange={(e) => {
													field.onChange((e.target as HTMLInputElement).checked ? 'no' : 'yes');
												}}
											>
												<FormControlLabel checked={field.value == 'no'} control={<Checkbox />} label={'Smartone'} />
											</CheckboxGroup>
										)}
									/>
								</Grid>
								<Grid item xs={12}>
									<Controller
										name="s-reward_consent"
										control={control}
										render={({ field, fieldState }) => (
											<CheckboxGroup
												label=""
												labelId=""
												onChange={(e) => {
													field.onChange((e.target as HTMLInputElement).checked ? 'no' : 'yes');
												}}
											>
												<FormControlLabel checked={field.value == 'no'} control={<Checkbox />} label={'SmarTone Plus'} />
											</CheckboxGroup>
										)}
									/>
								</Grid>
							</Grid>
						</Grid>

						<Grid item xs={12}>
							<Typography variant="p4">SmarTone 及 SmarTone Plus 的私隱政策、條款及細則，請瀏覽 smartone.com 及 s-rewards.hk。</Typography>
						</Grid>
					</Grid>
				</StyledSection>
			</Container>
		</StyledFormWrapper>
	);
}

export default Review;
