// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useCallback, useContext, useState, useReducer } from 'react';

// intl
import { styled } from 'styled-components';
import Container from '@/layout/Container';
import Header from '@/layout/Header';
import Content from '@/layout/Content';
import TextField from '@smt/formElement/TextField';
import Footer from '@/layout/Footer';
import Form from './Form';
import HomePage from './HomePage';
import Review from './Review';
import { Typography } from '@mui/material';
import ReviewFooter from '@/layout/ReviewFooter';
import { STEP_FORM, STEP_HOMEPAGE, STEP_REVIEW, STEP_THANKYOU, Step } from '@/type/Step';
import { ApplyService, FormValues } from '@/type/Form';
import ApplicationContext, { Channel } from '@smt/context/ApplicationContext';
import { useIntl } from 'react-intl';
import { convertLanguage } from '@smt/type/common';
import { useEffect } from 'react';
import { STEP_SUBMIT } from '@/type/Step';
import { useSubmitForm } from '@/hook/submitForm/useSubmitForm';
import deepmerge from 'deepmerge';
import { CHANNEL_SELF_HELP } from '../com/smartone/context/ApplicationContext';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { useLoading } from '@/hook/loading/useLoading';
import Thankyou from './Thankyou';

const StyledAppContainer = styled.div(({ theme }) => ({
	display: 'flex',
	flexDirection: 'column',
	minHeight: '100vh',
	justifyContent: 'space-between',
}));

interface PageIndexProp {}

function App({}: PageIndexProp) {
	const applicationContext = useContext(ApplicationContext);
	const intl = useIntl();
	const lang = convertLanguage(intl.locale);
	const { submitForm: submitAction, result: submitActionResult } = useSubmitForm();
	const { showLoading, hideLoading, LoadingScreen } = useLoading({ fullScreen: true });

	const channel: Channel = applicationContext?.channel == 'clubhouse' ? 'clubhouse' : 'self-help';
	const isClubhouse = channel == 'clubhouse';

	const [appliedService, setAppliedService] = useState<ApplyService>({
		mobile: false,
		H5GBB: false,
		FBB: false,
	});
	const [referenceNo, setReferenceNo] = useState<string>();
	//default value
	const [submitForm, setSubmitForm] = useState<FormValues>({
		channel: applicationContext?.channel || 'self-help',
		english_last_name: '',
		english_first_name: '',
		chinese_last_name: '',
		chinese_first_name: '',
		is_no_chinese_name: false,
		ID_type: 'HKID',
		ID_number: '',
		date_of_birth: '',
		title: '',
		contact_number: '',
		contact_email: '',
		address_block: '',
		address_floor: '',
		address_flat: '',
		address_estate: applicationContext.addressEstate,
		address_street: applicationContext.addressStreet,
		address_district: applicationContext.addressDistrict,
		address_in_one_line: '',
		img_ID: '',
		img_SA: '',
		language: lang,
		agree_tnc: false,
		mobile_trial: [
			{
				is_disabled: false,
				offer: '5GACO',
				sim: '',
				pending_activation: 'yes',
				pending_activation_date: '',
			},
		],
		H5GBB_trial: [
			{
				is_disabled: false,
				offer: 'HBB2H',
				sim: '',
				pending_activation: 'yes',
				pending_activation_date: '',
				main_IMEI: '',
				mesh_required: 'no',
				mesh_total: '',
				mesh_serial_num: '',
			},
		],
		HPP_trial: [
			{
				hpp_required: 'no',
				offer: 'P97LJ',
				sim: '',
				pending_activation: 'yes',
				pending_activation_date: '',
				main_IMEI: '',
			},
		],
		FBB_trial: [
			{
				is_disabled: false,
				offer: 'FHGGA',
				installation_date: '',
				installation_timeslot: '',
				activation_now: 'yes',
				activation_date: '',
				same_as_applier: 'yes',
				installation_contact: '',
				installation_contact_number: '',
			},
		],
		delivery: {
			not_reg_address: 'yes',
			address_tower: '',
			address_flat: '',
			address_floor: '',
			address_estate: '',
			address_street: '',
			address_district: '',
			contact: '',
			contact_number: '',
		},
		api_error: 'noError',
		at_least_one_service: true,
		dmflag_consent: 'yes',
		's-reward_consent': 'yes',
		staff_ID: '',
	} as FormValues);
	const [currentStep, setCurrentStep] = useState<Step>(applicationContext?.channel == CHANNEL_SELF_HELP ? STEP_HOMEPAGE : STEP_FORM);
	const [buttonStatus, setButtonStatus] = useState(false);
	const [formExtraValidate, setFormExtraValidate] = useState<string>('');

	const setFormData = (data: FormValues) => {
		setSubmitForm((prev) => {
			return {
				...prev,
				...data,
			};
		});
	};

	const onSubmitForm = () => {
		setButtonStatus(false);
		setTimeout(() => {
			window.scrollTo(0, 0);

			html2canvas(document.body, {
				imageTimeout: 10000,
				allowTaint: true,
				useCORS: true,
				ignoreElements: (element) => {
					return element.id == 'fixedFooter';
				},
			}).then(function (canvas) {
				showLoading();
				const img = canvas.toDataURL();
				// const doc = new jsPDF({
				// 	unit: 'px',
				// 	format: [canvas.width, canvas.height],
				// 	compress: true,
				// });
				// console.log(img);
				// console.log(canvas.width);
				// console.log(canvas.height);
				// doc.addImage(img, 'png', 10, 10, canvas.width, canvas.height);

				let cleanData: FormValues = deepmerge(submitForm, {});
				cleanData.img_SA = img;

				//remove field
				delete cleanData.is_no_chinese_name;
				delete cleanData.agree_tnc;
				delete cleanData.api_error;
				delete cleanData.at_least_one_service;
				delete cleanData.mobile_trial?.[0].is_disabled;
				delete cleanData.H5GBB_trial?.[0].is_disabled;
				delete cleanData.FBB_trial?.[0].is_disabled;
				delete cleanData.FBB_trial?.[0].same_as_applier;
				delete cleanData.FBB_trial?.[0].activation_now;

				if (!appliedService.mobile || submitForm.mobile_trial?.[0].is_disabled) {
					delete cleanData.mobile_trial;
				}
				if (!appliedService.H5GBB || submitForm.H5GBB_trial?.[0].is_disabled) {
					delete cleanData.H5GBB_trial;
				}
				if (submitForm.HPP_trial?.[0].hpp_required == 'no' || submitForm.H5GBB_trial?.[0].is_disabled) {
					delete cleanData.HPP_trial;
				}
				if (!appliedService.FBB || submitForm.FBB_trial?.[0].is_disabled) {
					delete cleanData.FBB_trial;
				}

				delete cleanData.delivery;
				// if ((!appliedService.mobile || submitForm.mobile_trial?.is_disabled) && (!appliedService.H5GBB || submitForm.H5GBB_trial?.is_disabled) && isClubhouse) {
				// 	delete cleanData.delivery;
				// }
				console.log(cleanData);
				submitAction(cleanData);
			});
		}, 750);
	};

	const onChangeStep = (step: Step, currentStep: Step) => {
		console.log(step);
		console.log(currentStep);

		if (currentStep === STEP_FORM && step === STEP_REVIEW) {
			setFormExtraValidate('startValidate');
		} else if (currentStep === STEP_REVIEW && step === STEP_FORM) {
			setCurrentStep(step);
			setFormExtraValidate('');
		} else if (currentStep === STEP_REVIEW && step === STEP_SUBMIT) {
			onSubmitForm();
		} else {
			setCurrentStep(step);
		}
	};

	useEffect(() => {
		if (formExtraValidate == 'validated') {
			setCurrentStep(STEP_REVIEW);
		}
	}, [formExtraValidate]);

	useEffect(() => {
		if (submitActionResult) {
			if (submitActionResult?.status == 'ok') {
				hideLoading();
				setButtonStatus(true);
				if (submitActionResult.result?.status == 'ok') {
					setReferenceNo(submitActionResult.result?.ref);
					setCurrentStep(STEP_THANKYOU);
				} else {
					alert('submit error|' + submitActionResult.result?.error);
				}
			} else if (submitActionResult?.status == 'failed') {
				hideLoading();
				setButtonStatus(true);
				alert('connection failed|' + submitActionResult.result?.err_code);
			}
		}
	}, [submitActionResult]);

	return (
		<StyledAppContainer>
			<Header currentStep={currentStep} />
			<Content>
				{currentStep == STEP_HOMEPAGE && <HomePage onChangeService={setAppliedService} onFormValidated={setButtonStatus} />}
				{currentStep == STEP_FORM && (
					<Form
						appliedService={appliedService}
						formData={submitForm}
						setFormData={setFormData}
						onFormValidated={setButtonStatus}
						setAppliedService={setAppliedService}
						extraValidate={formExtraValidate}
						setExtraValidate={setFormExtraValidate}
					/>
				)}
				{currentStep == STEP_REVIEW && <Review formData={submitForm} appliedService={appliedService} setFormData={setFormData} onFormValidated={setButtonStatus} />}
				{currentStep == STEP_THANKYOU && <Thankyou referenceNo={referenceNo} />}
			</Content>
			<Footer>
				<ReviewFooter id={'fixedFooter'} currentStep={currentStep} buttonStatus={buttonStatus} appliedService={appliedService} onChangeStep={onChangeStep} />
			</Footer>
			<LoadingScreen />
		</StyledAppContainer>
	);
}

export default App;
