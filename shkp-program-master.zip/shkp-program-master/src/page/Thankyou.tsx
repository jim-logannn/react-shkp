// These must be the first lines
import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';

import React, { useCallback, useContext, useEffect, useMemo, useState } from 'react';

// intl

import Container from '@/layout/Container';
import { styled, useTheme } from 'styled-components';
import { useIntl } from 'react-intl';
import { SLangEN, convertLanguage } from '@smt/type/common';

interface PageHomeProp {
	referenceNo?:string;
}
const StyledThankyouWrapper = styled.div(({ theme }) => ({
    padding: `0 ${theme.spacing(2)}`,
}));	
const StyledLeadInSectionHeader = styled.div(({ theme }) => ({
	marginTop:theme.spacing(10),
	[theme.breakpoints.down('md')]: {
		marginTop:theme.spacing(5),
	}
}));
const StyledHeader = styled.div(({ theme }) => ({	
	paddingBottom: theme.spacing(2),
	...theme.typography.h3,
	[theme.breakpoints.down('md')]: {
		...theme.typography.h5,
	},
}));
const StyledHeaderRed = styled.span(({ theme }) => ({
	color: theme.palette.primary.main,
}));	
const StyledDesc = styled.div(({ theme }) => ({
	...theme.typography.p3,
	[theme.breakpoints.down('md')]: {
		...theme.typography.p4,
	},
}));	
const StyledHeadingContainer = styled.div(({ theme }) => ({	
	textAlign: 'center',
}));
const StyledReferenceTitle = styled.div(({ theme }) => ({	
	...theme.typography.p3,
	color: theme.palette.grey[80],
	[theme.breakpoints.down('md')]: {
		...theme.typography.p4,
	},
}));
const StyledReferenceNo = styled.div(({ theme }) => ({	
	paddingBottom: theme.spacing(2),
	...theme.typography.h4 ,
	[theme.breakpoints.down('md')]: {
		...theme.typography.h6,
	},
}));
//
function Thankyou({referenceNo}: PageHomeProp) {	
	const intl = useIntl();
	
	return (
		<StyledThankyouWrapper>
			<StyledLeadInSectionHeader>
				<Container>
					<StyledHeadingContainer>
						<StyledHeader>{intl.formatMessage({ id: 'thankyou.lead-in.header' }, {red: <StyledHeaderRed>{intl.formatMessage({ id: 'thankyou.lead-in.header-highlight' })}</StyledHeaderRed> })}</StyledHeader>
						<StyledReferenceTitle>{intl.formatMessage({ id: 'thankyou.lead-in.reference-title' })}</StyledReferenceTitle>
						<StyledReferenceNo>{referenceNo}</StyledReferenceNo>
						<StyledDesc>{intl.formatMessage({ id: 'thankyou.lead-in.desc' })}</StyledDesc>
					</StyledHeadingContainer>
				</Container>
			</StyledLeadInSectionHeader>
		</StyledThankyouWrapper>
	);
}

export default Thankyou;
