import { IDType } from '@smt/formElement/IDField';
import { Language } from '@smt/type/common';
import { Dayjs } from 'dayjs';

export interface ApplyService {
	mobile: boolean;
	H5GBB: boolean;
	FBB: boolean;
	HPP?: boolean;
}

export type TrueFalseSelection = 'yes' | 'no' | null;
export type FormValues = {
	channel: 'clubhouse' | 'self-help';
	english_last_name: string;
	english_first_name: string;
	chinese_last_name: string;
	chinese_first_name: string;
	is_no_chinese_name?: boolean;
	agree_tnc?: boolean;
	ID_type: IDType;
	ID_number: string;
	date_of_birth: string;
	title: string;
	contact_number: string;
	contact_email: string;
	SHKP_membership: string;
	address_block: string;
	address_floor: string;
	address_flat: string;
	address_estate: string;
	address_street: string;
	address_district: string;
	address_in_one_line: string;
	img_ID: string;
	img_SA: string;
	mobile_trial?: {
		is_disabled?: boolean;
		offer: string;
		sim: string;
		pending_activation: TrueFalseSelection;
		pending_activation_date: string;
		promo_code: string;
	}[];
	H5GBB_trial?: {
		is_disabled?: boolean;
		offer: string;
		sim: string;
		pending_activation: TrueFalseSelection;
		pending_activation_date: string;
		main_IMEI: string;
		mesh_required: TrueFalseSelection;
		mesh_total: string;
		mesh_serial_num: string;
		promo_code: string;
	}[];
	HPP_trial?: {
		hpp_required?: TrueFalseSelection;
		offer: string;
		sim: string;
		pending_activation: TrueFalseSelection;
		pending_activation_date: string;
		main_IMEI: string;
	}[];
	FBB_trial?: {
		is_disabled?: boolean;
		offer: string;
		installation_date: string;
		installation_timeslot: string;
		activation_now?: TrueFalseSelection;
		activation_date: string;
		same_as_applier?: TrueFalseSelection;
		installation_contact: string;
		installation_contact_number: string;
	}[];
	delivery?: {
		not_reg_address: TrueFalseSelection;
		address_tower: string;
		address_flat: string;
		address_floor: string;
		address_estate: string;
		address_street: string;
		address_district: string;
		contact: string;
		contact_number: string;
	};
	api_error?: string;
	at_least_one_service?: boolean;
	language: Language;
	dmflag_consent: TrueFalseSelection;
	's-reward_consent': TrueFalseSelection;
	staff_ID?: string;
};
