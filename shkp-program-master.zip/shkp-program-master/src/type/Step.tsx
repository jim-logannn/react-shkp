export const STEP_HOMEPAGE = 'homepage';
export const STEP_FORM = 'form';
export const STEP_REVIEW = 'review';
export const STEP_SUBMIT = 'submit';
export const STEP_THANKYOU = 'thankyou';
export type Step = typeof STEP_HOMEPAGE | typeof STEP_FORM | typeof STEP_REVIEW | typeof STEP_SUBMIT | typeof STEP_THANKYOU;
