const test = require('./json/test.json');

const main = {	
	'POST /jsp/test/ajax/test.jsp': (req, res) => {
		setTimeout(()=>{
			return res.json(test);
		}, 1000)
	}
};
module.exports = main;