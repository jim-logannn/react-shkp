const main = require('./main');

const proxy = {
	'POST /jsp/test/ajax/test.jsp': (req, res) => {
		return res.json({
			status: 'ok',
		});
	},
	'POST /jsp/otp/ajax/otp_send.jsp': (req, res) => {
		return res.json({
			status: 'ok',
		});
	},
	'POST /jsp/otp/ajax/otp_verify.jsp': (req, res) => {
		return res.json({
			status: 'ok',
		});
	},
	'POST /jsp/SHK_SiliconHill/SHKPnewpropertyoffer/Internal/API_pre_validation.jsp': (req, res) => {
		return res.json({
			status: 'ok',
			address: {
				flat: 'A1',
				block: '2',
				floor: '5',
				address_quota: {
					H5GBB: {
						quota: {
							warning_lower_limit: 1,
							lower_limit: 0,
							quota: 2,
							quota_balance: 2,
						},
						total_submit: 0,
					},
					FBB: {
						quota: {
							warning_lower_limit: 1,
							lower_limit: 0,
							quota: 2,
							quota_balance: 2,
						},
						total_submit: 0,
					},
					mobile: {
						quota: {
							warning_lower_limit: 1,
							lower_limit: 0,
							quota: 2,
							quota_balance: 2,
						},
						total_submit: 0,
					},
				},
			},
			sim_list: [
				{
					sim: '89852069406290715023',
					service: 'mobile',
					status: 'ok',
				},
				{
					sim: '89852069407040817382',
					service: 'H5GBB',
					status: 'ok',
				},
				{
					sim: '89852061207241200000',
					service: 'HPP',
					status: 'ok',
				},
			],
			serial_list: [
				{
					serial: '111222333',
					status: 'ok',
				},
			],
			IMEI_list: [
				{
					service: 'H5GBB',
					IMEI: '863671040335832',
					status: 'ok',
				},
				{
					service: 'HPP',
					IMEI: '860730040687817',
					status: 'ok',
				},
			],
		});
	},
	'POST /jsp/SHK_SiliconHill/SHKPnewpropertyoffer/Internal/API_submit_action.jsp': (req, res) => {
		return res.json({
			status: 'ok',
			ref: 'SHK-SH1-80619761',
		});
	},
};

module.exports = Object.assign(proxy, main);
