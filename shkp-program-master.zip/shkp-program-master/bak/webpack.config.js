// @ts-nocheck
require('dotenv').config();
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');
const autoprefixer = require('autoprefixer');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

const getSmsTaskPath = function (smstask) {
	if (!smstask) {
		console.log('smstask not found: ' + smstask);
		console.log('use default path: ' + path.resolve(__dirname, 'build'));
		return path.resolve(__dirname, 'build');
	}
	const DRIVE = 'M:';
	const taskPath = path.resolve(DRIVE, smstask);
	const jsPath = path.resolve(taskPath, 'china_travelers_form/js');
	if (!fs.existsSync(taskPath)) {
		console.log('JS path not found: ' + taskPath);
		console.log('use default path: ' + path.resolve(__dirname, 'build'));
		return path.resolve(__dirname, 'build');
	}
	return jsPath;
};

const SMS_TASK = process.env.sms_task;
const OUTPUT_PATH = getSmsTaskPath(SMS_TASK);

module.exports = {
	mode: 'development',
	entry: {
		index: path.resolve(__dirname, './template/App.tsx'),
		thankyou: path.resolve(__dirname, './template/ThankYouPage.tsx'),
	},
	output: {
		path: OUTPUT_PATH,
		filename: '[name].js',
	},
	devServer: {
		hot: true,
		static: {
			directory: path.join(__dirname, 'build'),
		},
		compress: true,
		port: 9000,
		historyApiFallback: true,
		proxy: {
			'/.resources/common/webresources/css/fonts/': {
				target: 'https://www.smartone.com/',
				secure: false,
				changeOrigin: true,
			},
			'/.resources/common/webresources/assets/images/common/': {
				target: 'https://www.smartone.com/',
				secure: false,
				changeOrigin: true,
			},
		},
	},
	resolve: {
		extensions: ['', '.js', '.jsx', '.tsx', '.css'],
	},
	plugins: [
		new MiniCssExtractPlugin(),
		new HtmlWebpackPlugin({
			template: './public/index.html',
			filename: 'index.html',
			chunks: ['index'],
			inject: true,
			minify: true,
		}),
		new HtmlWebpackPlugin({
			template: './public/thankyou.html',
			filename: 'thankyou.html',
			chunks: ['thankyou'],
			inject: true,
			minify: true,
		}),
	],
	module: {
		rules: [
			{
				test: /\.(js|ts)x?$/,
				exclude: /node_modules/,
				use: {
					loader: 'babel-loader',
					options: {
						presets: ['@babel/preset-react', '@babel/preset-env', '@babel/preset-typescript'],
					},
				},
			},
			{
				test: /\.css$/,
				exclude: /node_modules/,
				use: [
					// { loader: 'style-loader' },
					MiniCssExtractPlugin.loader,
					'css-loader',
					{
						loader: 'postcss-loader',
						options: {
							postcssOptions: {
								plugins: [
									'postcss-import',
									'postcss-bem-fix',
									'postcss-apply',
									'postcss-mixins',
									'postcss-extend',
									'postcss-simple-vars',
									'postcss-for',
									['tailwindcss/nesting', 'postcss-nesting'],
									['tailwindcss', { config: './tailwind.config.js' }],
									autoprefixer,
									[
										'postcss-preset-env',
										{
											// Options
										},
									],
								],
							},
						},
					},
				],
			},
		],
	},
};
