// @ts-nocheck
/** @type {import('tailwindcss').Config} */

const spacing = {
	2: '2px',
	4: '4px',
	8: '8px',
	12: '12px',
	20: '20px',
	28: '28px',
	32: '32px',
	40: '40px',
	80: '80px',
};

const colors = {
	red: {
		smt: '#FF0000',
		light: '#FD4433',
		dark: '#CA1100',
	},
	black: '#333333',
	grey: {
		90: '#666666',
		80: '#9C9C9C',
		60: '#C7C7C7',
		50: '#D3D3D3',
		40: '#EBECEE',
		20: '#F6F6F6',
		blue: '#F5F6FA',
	},
	white: '#ffffff',
	green: '#3E9B3C',
	blue: '#009FDC',
	orange: '#F48F4A',
	yellow: '#FFB100',
	purple: '#E73074',
	gold: '#CCA13E',
};

const container = {
	center: true,
	padding: {
		DEFAULT: spacing[12],
		sm: spacing[12],
		lg: spacing[12],
		xl: spacing[20],
		'2xl': spacing[20],
	},
};

const screens = {
	sm: 640,
	md: 768,
	lg: 1024,
	xl: 1280,
	'2xl': 1536,
};

module.exports = {
	content: ['./template/**/*.{html,js,jsx,tsx}'],
	theme: {
		colors,
		spacing,
		container,
		extend: {
			fontFamily: {
				mix: ['titling-gothic-fb-narrow', 'Noto Sans TC', 'sans-serif'],
				enCondensed: ['titling-gothic-fb-condensed', 'sans-serif'],
				enNarrow: ['titling-gothic-fb-narrow', 'sans-serif'],
				tcNotoSans: ['Noto Sans TC', 'sans-serif'],
			},
			fontSize: {
				48: '48px',
				28: '28px',
				20: '20px',
				24: '24px',
				16: '16px',
				14: '14px',
				18: '18px',
				42: '42px',
				12: '12px',
				38: '38px',
				10: '10px',
				15: '15px',
				32: '32px',
				11: '11px',
				13: '13px',
			},
			fontWeight: {
				regular: 400,
				medium: 500,
				bold: 700,
			},
			lineHeight: {
				72: '72px',
				42: '42px',
				30: '30px',
				36: '36px',
				24: '24px',
				21: '21px',
				27: '27px',
				63: '63px',
				18: '18px',
				57: '57px',
				15: '15px',
				23: '23px',
				48: '48px',
				17: '17px',
				20: '20px',
			},
			borderRadius: {
				'4xl': '2rem',
			},
			maxWidth: {
				200: '200px',
				250: '250px',
				400: '400px',
			},
			minWidth: {
				200: '200px',
				250: '250px',
				400: '400px',
			},
		},
	},
	plugins: [],
};

exports.spacing = spacing;
exports.colors = colors;
