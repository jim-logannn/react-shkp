import React from 'react';

export default function Form() {
	return (
		<>
			<div className="fontFamily-notoSansTC">
				<div className="font font-28">form</div>
				<div className="font font-12">
					Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolore expedita, eligendi modi ut sint. Eos, voluptas dolor ratione a quaerat impedit sapiente maxime cumque at doloribus, dicta corporis
					expedita!
				</div>
				<div className="font font-14 font-medium">
					Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit quo recusandae obcaecati quae, similique eaque ducimus enim neque illo? Similique rerum impedit enim totam, vero omnis ipsum
					illo dolores. Itaque.
				</div>
			</div>
			<div className="fontFamily-narrow">
				<div className="font font-28">form</div>
				<div className="font font-12">
					Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolore expedita, eligendi modi ut sint. Eos, voluptas dolor ratione a quaerat impedit sapiente maxime cumque at doloribus, dicta corporis
					expedita!
				</div>
				<div className="font font-14 font-medium">
					Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit quo recusandae obcaecati quae, similique eaque ducimus enim neque illo? Similique rerum impedit enim totam, vero omnis ipsum
					illo dolores. Itaque.
				</div>
			</div>
		</>
	);
}
