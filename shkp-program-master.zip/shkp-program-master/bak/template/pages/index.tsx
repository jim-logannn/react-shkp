import React, { useEffect } from 'react';
import { initButtons } from '../../src/js/components';
import { Link } from 'react-router-dom';
import InputField from '../../src/components/InputField/InputField';
import Button from './../../src/components/Button/Button';
import Header from './../common/Header';

export default function Index() {
	return (
		<>
			<Header />
			Index Page
			<Button className="btn-primary btn-medium">testing</Button>
			<InputField type="text" className="input-medium" />
			<div className="m-8">
				<h1 className="font-28 font-bold">React</h1>
				<div>
					<Link to="form" className="font-28 font-bold font-u">
						Form
					</Link>
				</div>
				<div>
					<Link to="review" className="font-28 font-bold font-u">
						Review
					</Link>
				</div>
			</div>
		</>
	);
}
