import React from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouterProvider, Link } from 'react-router-dom';
import ErrorPage from './ErrorPage';
import './styles.css';
import Form from './pages/form';
import Review from './pages/review';
import Index from './pages';
import ReactDOM from 'react-dom';

const router = createBrowserRouter([
	{
		path: '/',
		element: <Index />,
		errorElement: <ErrorPage />,
	},
	{
		path: '/form',
		element: <Form />,
		errorElement: <ErrorPage />,
	},
	{
		path: '/review',
		element: <Review />,
		errorElement: <ErrorPage />,
	},
]);

window.renderReactApp = function ({ container, ...props }) {
	ReactDOM.render(
		<React.StrictMode>
			<RouterProvider router={router} />
		</React.StrictMode>,
		container,
	);
};

declare global {
	interface Window {
		renderReactApp: ({ container, ...props }) => void;
	}
}
