import React from 'react';
import { createRoot } from 'react-dom/client';
import './styles';
import Thankyou from './pages/thankyou';

const container = document.getElementById('root');

const root = createRoot(container);
root.render(
	<React.StrictMode>
		<Thankyou />
	</React.StrictMode>,
);
