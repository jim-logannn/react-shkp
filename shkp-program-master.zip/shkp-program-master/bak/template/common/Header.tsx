import React, { useEffect } from 'react';

export default function Header() {
	return (
		<header className="pt-40 pb-40 w-full bg-white border-b border-b-grey-60">
			<div className="container flex justify-between">
				<div className="">
					<img src="/.resources/common/webresources/assets/images/common/logo_d.svg" />
				</div>
				<div>step</div>
				<div>lang</div>
			</div>
		</header>
	);
}
