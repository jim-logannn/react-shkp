const iconURL = {
	upload: {
		white: '/IMG_V4/web_style_guideline/001-upload.png',
		red: '/IMG_V4/web_style_guideline/001-upload-1.png',
	},
	tick: {
		green: '/IMG_V4/web_style_guideline/done_green.png',
		red: '/IMG_V4/web_style_guideline/done_red.png',
		white: '/IMG_V4/web_style_guideline/done_white.png',
	},
	mapPin: {
		red: '/IMG_V4/web_style_guideline/Group 284-1.png',
		white: '/IMG_V4/web_style_guideline/Group 284.png',
	},
	idCard: {
		red: '/IMG_V4/web_style_guideline/id_red.png',
		white: '/IMG_V4/web_style_guideline/id_white.png',
	},
	loading: {
		black: '/IMG_V4/web_style_guideline/loading_black.png',
		white: '/IMG_V4/web_style_guideline/loading_white.png',
	},
	circlePlus: {
		red: '/IMG_V4/web_style_guideline/more_red.png',
		white: '/IMG_V4/web_style_guideline/more_white.png',
	},
	rightArrow: {
		black: '/IMG_V4/web_style_guideline/next_black.png',
		white: '/IMG_V4/web_style_guideline/next_white.png',
	},
	magnifyingGlass: {
		red: '/IMG_V4/web_style_guideline/search_red.png',
	},
	star: {
		red: '/IMG_V4/web_style_guideline/star_red.png',
	},
};

export { iconURL };
