// @ts-nocheck
const onClickRippleEffect = (e) => {
	let x = e.clientX - e.target.offsetLeft;
	let y = e.clientY - e.target.offsetTop;

	let ripples = document.createElement('span');
	ripples.style.left = x + 'px';
	ripples.style.top = y + 'px';

	const rippleRoot = e.target.querySelector('.ripple-root');
	rippleRoot.appendChild(ripples);

	setTimeout(() => {
		ripples.remove();
	}, 1000);
};

const initButtons = () => {
	const buttons = document.querySelectorAll('.btn-ripple');

	function handleClick(e) {
		onClickRippleEffect(e);
	}
	buttons.forEach((btn) => {
		btn.addEventListener('click', handleClick);
	});
};

export { initButtons, onClickRippleEffect };
