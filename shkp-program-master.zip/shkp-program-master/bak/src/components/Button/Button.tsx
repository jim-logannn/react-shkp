import React, { ButtonHTMLAttributes, useEffect } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {}

const onClickRippleEffect = (e) => {
	let x = e.clientX - e.target.offsetLeft;
	let y = e.clientY - e.target.offsetTop;

	let ripples = document.createElement('span');
	ripples.style.left = x + 'px';
	ripples.style.top = y + 'px';

	const rippleRoot = e.target.querySelector('.ripple-root');
	rippleRoot.appendChild(ripples);

	setTimeout(() => {
		ripples.remove();
	}, 1000);
};

const initButtons = () => {
	const buttons = document.querySelectorAll('.btn-ripple');

	function handleClick(e) {
		onClickRippleEffect(e);
	}
	buttons.forEach((btn) => {
		btn.addEventListener('click', handleClick);
	});
};

export default function Button(props: ButtonProps) {
	let { className, children, ...rest } = { ...props };
	let appendClass = className ? className : '';

	useEffect(() => {
		initButtons();
	}, []);

	return (
		<button className={'btn btn-ripple ' + appendClass} {...rest}>
			{children}
			<span className="ripple-root"></span>
		</button>
	);
}
export { initButtons, onClickRippleEffect };
