import React, { InputHTMLAttributes } from 'react';

interface InputFieldProps extends InputHTMLAttributes<HTMLInputElement> {}

export default function InputField(props: InputFieldProps) {
	let { className, ...rest } = { ...props };
	let appendClass = className ? className : '';

	return <input className={'input-field ' + appendClass} {...rest} />;
}
