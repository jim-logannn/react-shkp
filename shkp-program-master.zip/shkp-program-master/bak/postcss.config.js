// https://tailwindcss.com/docs/using-with-preprocessors#using-post-css-as-your-preprocessor

// https://www.npmjs.com/package/postcss-bem-fix
module.exports = {
	plugins: {
		'postcss-import': {},
		'postcss-bem-fix': {},
		'postcss-apply': {},
		'postcss-mixins': {},
		'postcss-extend': {},
		'postcss-for': {},
		'postcss-simple-vars': {},
		'tailwindcss/nesting': 'postcss-nesting',
		tailwindcss: { config: './tailwind.config.js' },
		autoprefixer: {},
	},
};
