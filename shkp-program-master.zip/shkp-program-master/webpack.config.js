const fs = require('fs');
const path = require('path');
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin');
require('dotenv').config();

const getSmsTaskPath = function (smstask) {
	if (!smstask) {
		console.log('smstask not found: ' + smstask);
		console.log('use default path: ' + path.resolve(__dirname, 'build'));
		return path.resolve(__dirname, 'build');
	}
	const DRIVE = 'M:';
	const taskPath = path.resolve(DRIVE, smstask);
	const jsPath = path.resolve(taskPath, 'SHKP/Silicon_Hill/js');
	if (!fs.existsSync(taskPath)) {
		console.log('JS path not found: ' + taskPath);
		console.log('use default path: ' + path.resolve(__dirname, 'build'));
		return path.resolve(__dirname, 'build');
	}
	return jsPath;
};

module.exports = function (env, argv) {
	const SMS_TASK = process.env.sms_task;
	const OUTPUT_PATH = getSmsTaskPath(SMS_TASK);
	const transpileOnly = argv.mode != 'production';

	console.log('sms_task        = ' + SMS_TASK);
	console.log('output.path     = ' + OUTPUT_PATH);
	console.log('transpileOnly   = ' + transpileOnly);

	let entry = {
		main: './src/main.tsx',
		vendor: ['react', 'react-dom', 'react-intl', 'styled-components'],
	};

	return {
		entry: entry,
		output: {
			path: OUTPUT_PATH,
		},
		module: {
			rules: [
				{
					test: /\.tsx?$/,
					exclude: /node_modules/,
					loader: 'ts-loader',
					options: {
						// transpileOnly:true => disable type checker, editor can handle type checker
						// this is to speed up development, do not do this for production build
						transpileOnly: transpileOnly,
					},
				},
				{
					test: /\.(js|jsx|mjs)$/,
					exclude: /node_modules/,
					use: {
						loader: 'babel-loader',
						options: {
							presets: ['@babel/preset-env', '@babel/preset-react'],
						},
					},
				},
				{
					test: /\.css$/i,
					use: ['style-loader', 'css-loader', 'postcss-loader'],
				},
			],
		},
		resolve: {
			plugins: [new TsconfigPathsPlugin()],
			modules: [path.resolve(__dirname, 'src'), 'node_modules'],
			extensions: ['.js', '.jsx', '.ts', '.tsx'],
		},
		performance: {
			hints: false,
		},
		optimization: {
			splitChunks: {
				cacheGroups: {
					vendor: {
						chunks: 'initial',
						name: 'vendor',
						test: 'vendor',
						enforce: true,
					},
				},
			},
			runtimeChunk: false,
		},
	};
};
